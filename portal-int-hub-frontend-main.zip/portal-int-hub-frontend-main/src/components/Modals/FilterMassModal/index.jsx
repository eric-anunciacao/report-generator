import React, { memo, useEffect, useState } from 'react'
import {
  CButton,
  CFormLabel,
  CFormTextarea,
  CModal,
  CModalBody,
  CModalFooter,
  CModalHeader,
  CModalTitle,
} from '@coreui/react'
import Select from 'react-select'

function FilterMassModal(props) {

   const [identifierSelected,setIdentifierSelected] = useState("")
   const [data,setData] = useState("")

  return (
    <>
      <CModal visible={props.visible} onClose={props.onCancel}>
        <CModalHeader>
          <CModalTitle>Filtro Avançado</CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CFormLabel className="col-sm-8 col-form-label">Identificador</CFormLabel>
          <Select
            options={props.identifiers}            
            placeholder="Selecione"
            onChange={(value) => {                                     
              setIdentifierSelected(value.value)
            }}
            theme={(theme) => ({
              ...theme,
              borderRadius: 0,
              colors: {
                ...theme.colors,
                text: '#000',
                primary25: '#A6ACBF',
                primary: '#706F80',
                primary50: '#A6ACBF',
              },
            })}
          />         
          <CFormLabel className="col-sm-8 col-form-label">Dado a ser pesquisado</CFormLabel>
          <CFormTextarea
            rows={10}                                      
            placeholder="Informe um registro por linha"                   
            onChange={(e)=>{
              setData(e.target.value)
            }}     
          ></CFormTextarea>
        </CModalBody>
        <CModalFooter>
          <CButton color="light" onClick={()=>{
            props.onCancel()
          }}>
            Cancelar
          </CButton>
          <CButton color="dark" onClick={() => {
            props.onConfirm(identifierSelected,data)
          }}>
            Confirmar
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default memo(FilterMassModal)
