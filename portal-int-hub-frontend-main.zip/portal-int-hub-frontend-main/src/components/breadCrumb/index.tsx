import React, { memo, useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import { CBreadcrumb, CBreadcrumbItem } from '@coreui/react'
import { BREADCRUMB_ROUTES } from 'src/constants'

interface IBreadCrumb {
  pathname: string
  name: string
  active: boolean
}

const AppBreadcrumb = () => {
  const currentLocation = useLocation().pathname
  const [breadcrumbs, setBreadCrumbs] = useState<IBreadCrumb[]>([])

  useEffect(() => {
    handleGenerateBreadCrumbs()
  }, [currentLocation])

  // //validando se o path enviado corresponde a uma rota
  const handleHasRouteName = (pathname: string) => {
    const currentRoute = BREADCRUMB_ROUTES.find((route) => route.path === pathname)
    return currentRoute ? currentRoute.name : false
  }

  const handleGenerateBreadCrumbs = () => {
    const breadcrumbs: IBreadCrumb[] = []
      currentLocation.split('/').reduce((prev, curr, index, array) => {
      const currentPathname = `${prev}/${curr}`      
      const routeName = handleHasRouteName(currentPathname)
      routeName &&
        breadcrumbs.push({
          pathname: currentPathname,
          name: routeName,
          active: index + 1 === array.length,
        })
      return currentPathname
    })
    setBreadCrumbs(breadcrumbs)
  }

  // const breadcrumbs = handleGenerateBreadCrumbs()

  const handleRenderBreadCrumbs = () => {
    return breadcrumbs.map((breadcrumb, index) => {
      return (
        <CBreadcrumbItem
          {...(breadcrumb.active ? { active: true } : { href: breadcrumb.pathname })}
          key={index}
        >
          {breadcrumb.name}
        </CBreadcrumbItem>
      )
    })
  }

  return <CBreadcrumb className="m-0 ms-2">{handleRenderBreadCrumbs()}</CBreadcrumb>
}

export default memo(AppBreadcrumb)
