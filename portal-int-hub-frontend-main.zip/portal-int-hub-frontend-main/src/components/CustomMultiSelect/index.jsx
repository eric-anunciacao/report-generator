import React, { memo, useEffect } from 'react'
import { MultiSelect } from 'react-multi-select-component'

function CustomMultiSelect(props) {
 

  const handleGenerateLabelTextAllItensSelected = () => {
    let teste = props.options.reduce((current, value) => {
      return (current += value.label + ';')
    }, '')

    return teste
  }

  const handleGenerateOverrideStrings = () => {
    return {
      allItemsAreSelected: handleGenerateLabelTextAllItensSelected(),
      clearSearch: 'Limpar',
      search: 'Procurar...',
      selectAll: 'Selecionar Tudo',
      selectAllFiltered: 'Selecionar Tudo',
      selectSomeItems: 'Adicione',
    }
  }

  return (
    <>
      <MultiSelect
        className='w-full'
        labelledBy="Selecione"
        placeholder="Selecione"
        options={props.options}
        overrideStrings={handleGenerateOverrideStrings()}
        value={props.options}
        disabled={props.disabled}
        hasSelectAll={false}
        onChange={(value) => {
          props.handleChangeMassFilter(value)
        }}
      />
    </>
  )
}

export default memo(CustomMultiSelect)
