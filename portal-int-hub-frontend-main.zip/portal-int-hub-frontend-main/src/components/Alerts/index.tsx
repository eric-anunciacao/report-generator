import React,{memo} from 'react'
import { CButton, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle } from '@coreui/react'

interface IAlertProps {
  title: string
  message: string,
  visible:boolean,
  onConfirm: () => void
  onCancel: () => void
}

function Alerts({ title, message, onCancel, onConfirm, visible }: IAlertProps) {
  return (
    <>
      <CModal visible={visible} onClose={onCancel}>
        <CModalHeader>
          <CModalTitle>{title}</CModalTitle>
        </CModalHeader>
        <CModalBody>{message}</CModalBody>
        <CModalFooter>
          <CButton color="light" onClick={onCancel}>
            Cancelar
          </CButton>
          <CButton color="dark" onClick={onConfirm}>
            Confirmar
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default memo(Alerts)
