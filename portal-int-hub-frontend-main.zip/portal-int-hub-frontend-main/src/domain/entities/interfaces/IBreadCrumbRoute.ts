import { ReactNode } from "react";

export interface IBreadCrumbRoute{
    path:string,
    name:string,    
}