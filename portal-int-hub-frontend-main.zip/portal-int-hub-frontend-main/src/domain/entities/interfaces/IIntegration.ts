import { ICluster } from "./ICluster"

export interface IIntegration{
    id:number,
    active:boolean,
    correlationId:string,
    cluster:ICluster,
    dlqTopic:string,
    dlqTopicConsumerStatus:string,
    dtCreate:string,
    dtUpdate:string,
    identifier1:string,
    identifier2:string,
    identifier3:string,
    identifier4:string,
    name:string,
    nameIdentifier1:string,
    nameIdentifier2:string,
    nameIdentifier3:string,
    nameIdentifier4:string,
    reprocessTopic:string,
    successTopic:string,
    successTopicConsumerStatus:string

}