//interface que representa os itens dentro dos selects da app
export interface IItemSelect {
  label: string
  value: string
  disabled?: boolean
}
