export interface IBarChartModel {
    categories: String[],
    successList:String[],
    errorList:String[],
    reprocessedList:String[],
    waitingReprocessingList:String[],
    failedReprocessingList:String[]
  }