import { ICluster } from "./ICluster"

export interface IAutoReprocessing{
    integrationId:number,
    integrationName:string,
    retries:number,
    ignoreAfterDays:number,
    ignoreAfterDaysLabel: string,
    strategy:string,
    strategyDescription:string,
    schedule:string[],
    minutesToReprocess:number,
    configurationLabel:string,
    active:boolean
}
