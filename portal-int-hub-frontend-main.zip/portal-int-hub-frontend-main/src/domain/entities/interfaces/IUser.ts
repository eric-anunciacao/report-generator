export default interface IUser{
    username:string,
    password:string
}