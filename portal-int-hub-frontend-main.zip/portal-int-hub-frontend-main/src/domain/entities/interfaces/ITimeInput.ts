//interface que representa os itens dentro dos selects da app
export interface ITimeInput {
  label: string
  value: string
}
