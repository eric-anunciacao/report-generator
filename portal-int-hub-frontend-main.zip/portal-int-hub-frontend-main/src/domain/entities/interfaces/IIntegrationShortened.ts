import { ICluster } from "./ICluster"

export interface IIntegrationShortened {
    id:number,
    name:string,
    active:boolean
}
