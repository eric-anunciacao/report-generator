export interface ICluster{
    id:any,
    name:string,
    servers:string
}
