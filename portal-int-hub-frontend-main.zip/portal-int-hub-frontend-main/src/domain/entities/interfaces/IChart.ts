import { IIntegration } from "./IIntegration";

export interface IChart{
    id:number,
    integration:IIntegration,
    error:number,
    reprocessed:number,
    success:number,
    waitingReprocessing:number,
    failedReprocessing:number
}