import * as React from 'react';
import * as XLSX from 'xlsx';
import moment from 'moment';
import 'moment/locale/pt-br';
import { CButton, CCol, CFormInput, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle } from '@coreui/react';
import { exportIntegrationToExcel } from '../views/reprocessamento/hooks/reprocessamento';
import save from 'save-file';
import { UtilsString } from './string';

export class ExportXLSX {
    static exportData = (excelData, fileName) => {
        var wb = XLSX.utils.book_new(),
        ws = XLSX.utils.json_to_sheet(excelData);

        XLSX.utils.book_append_sheet(wb, ws, 'file');
        XLSX.writeFile(wb, `${fileName}_${moment().format('DD-MM-YYYY_H:mm:ss')}.xlsx`);
    }

}

const formatLimitCharcter = (character) =>  {
    return character?.length > 32700 ? character?.slice(0, 32700) + '...' : character;
}

const exportData = (queueList, integrationName) => {

    const excelData = queueList?.map( data => {

      return {
        [data.integration.nameIdentifier1] : data.identifier,
        [data.integration.nameIdentifier2 ?? 'Identificador 2'] : data.identifier2,
        [data.integration.nameIdentifier3 ?? 'Identificador 3'] : data.identifier3,
        [data.integration.nameIdentifier4 ?? 'Identificador 4'] : data.identifier4,
        "Status" : data.status,
        "Último Reprocessamento" : UtilsString.isNullOrEmpty(data.lastReprocessing) ? "-" : data.lastReprocessing,
        "Data de Evento" : moment(data?.dtEvent).format('DD/MM/YYYY H:mm:ss'),
        "Data de Alteração" : !UtilsString.isNullOrEmpty(data?.dtUpdate) ? moment(data?.dtUpdate).format('DD/MM/YYYY HH:mm:ss') : 'Sem data de alteração',
        "Causa" : UtilsString.isNullOrEmpty(data?.exceptionCause) ? 'Não foi encontrado nenhum erro' : formatLimitCharcter(data.exceptionCause),
        "Mensagem" : UtilsString.isNullOrEmpty(data?.exceptionMessage) ? 'Não foi encontrado nenhum erro' : formatLimitCharcter(data.exceptionMessage),
        "Payload" : formatLimitCharcter(data?.message)
      }
    });

    ExportXLSX.exportData(excelData, `Mensagens_${integrationName}`);
  }

const ModalExportXLSX = (props) => {

    const [selectedInitialDate, setSelectedInitialDate] = React.useState('');
    const [selectedEndDate, setSelectedEndDate] = React.useState('');

    const shouldExportData = (selectedInitialDate && selectedEndDate);

    const clear = () => {
        setSelectedInitialDate('');
        setSelectedEndDate('');
    }

    const validateDateRange = ()=>{
        if(moment(selectedEndDate).diff(moment(selectedInitialDate),"days") > 31){
            props.setOpen(false);
            props.setError("O Intervalo para geração do relatório é de no máximo 31 dias");
            return;
        }

        handleExport();
    }

    const handleExport = async () => {
        try{
            props.setOpen(false);
            props.setLoading(true);
            props.setLoadingExport(true);
            const requestData = { dtEventBegin: selectedInitialDate , dtEventEnd: selectedEndDate, integrationId: props.integrationId };
            const res = await exportIntegrationToExcel(requestData);
            if(res.ok){
                const json = await res.json();
                exportData(json, props.integrationName);
            } else {
                props.setError('Não foi possível fazer a exportação em massa');
            }
        }
        catch(err){
            props.setError('Não foi possível fazer a exportação em massa');
        }
        props.setLoadingExport(false);
        props.setLoading(false);
    }

    return (
        <>
        <CModal visible={props.open} onClose={() => props.setOpen(false)} size="lg">
        <CModalHeader onClose={() => props.setOpen(false)}>
            <CModalTitle>Exportação da Integração {props.integrationName}</CModalTitle>
        </CModalHeader>
        <CModalBody>
            <div style={{margin: '20px'}}>
                <span> Preencha todos os campos de data para a exportação de dados.</span>
            </div>
            <div  style={{display: 'flex', justifyContent: 'space-between', margin: '10px'}} >
                <div style={{flex: 1, padding: '5px'}}>
                    <CFormInput value={selectedInitialDate} onChange={(e) => setSelectedInitialDate(e.target.value) } label="Data de Evento - Início" placeholder="Data de Evento - Início" type="date" />
                </div>
                <div style={{flex: 1, padding: '5px'}}>
                    <CFormInput value={selectedEndDate} onChange={(e) => setSelectedEndDate(e.target.value)  }  label="Data de Evento - Fim" placeholder="Data de Evento - Fim" type="date" />
                </div>
            </div>
        </CModalBody>
        <CModalFooter>
            <CButton color="secondary" onClick={clear}>Limpar</CButton>
            <CButton onClick={validateDateRange} disabled={!shouldExportData} color="dark">Exportar</CButton>
        </CModalFooter>
        </CModal>
        </>
    )
}

export default ModalExportXLSX;
