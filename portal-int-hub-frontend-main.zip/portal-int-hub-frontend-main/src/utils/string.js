export class UtilsString {

  static isNullOrEmpty(value){
    if(value == null || value == undefined ||
      value == 'null' || value == 'undefined' || value == '' || !value ){
      return true;
    }
    return false;
  }
}
