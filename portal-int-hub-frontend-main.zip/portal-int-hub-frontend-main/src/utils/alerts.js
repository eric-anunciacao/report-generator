import { CAlert } from '@coreui/react'
import * as React from 'react'

export const TopAlertErrorComponent = (props) => {

  setTimeout(() => {
    props.message && props.setError('')
    props.visible && props.setVisible(false)
  }, '3000')

  return (
    <>
      <CAlert
        color="danger"
        dismissible
        onClose={() => {
          props.setError('')
        }}
      >
        {props.message}
      </CAlert>
    </>
  )
}

export const TopAlertWarningComponent = (props) => {
  
  setTimeout(() => {   
    props.visible && props.setVisible(false)
  }, '3000')

  return (
    <>
      {
        props.visible && 
        <CAlert color="warning">{props.message}</CAlert>
      }
    </>
  )
}

export const TopAlertSuccessComponent = (props) => {

  setTimeout(() => {
    props.visible && props.setVisible(false)
  }, '3000')

  return (
    <>
      {
        props.visible &&
        <CAlert color="success" dismissible>
          {props.message}
        </CAlert>
      }
    </>
  )
}
