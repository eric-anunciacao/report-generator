import React from 'react'
import CIcon from '@coreui/icons-react'
import { ROUTES } from './constants'
import {
  cilBarChart,
  cilListFilter,
  cilNotes,
  cilSettings,
  cilSpeedometer,
} from '@coreui/icons'
import { CNavGroup, CNavItem } from '@coreui/react'

const _nav = [
  {
    component: CNavItem,
    name: 'Painel',
    to: ROUTES.HOME,
    icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
  },
  {
    component: CNavItem,
    name: 'Analítico de Mensagens',
    to: ROUTES.MESSAGES,
    icon: <CIcon icon={cilBarChart} customClassName="nav-icon" />,
  },
  {
    component: CNavGroup,
    name: 'Configurações',
    icon: <CIcon icon={cilSettings} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Integração',
        to: ROUTES.INTEGRATION,
      },
      {
        component: CNavItem,
        name: 'Cluster',
        to: ROUTES.CLUSTER,
      },
      {
        component: CNavItem,
        name: 'Reprocessamento Autom.',
        to: ROUTES.AUTOREPROCESSING,
      }
    ],
  },
]

export default _nav
