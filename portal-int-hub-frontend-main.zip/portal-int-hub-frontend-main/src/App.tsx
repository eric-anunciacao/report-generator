import React, { Component } from 'react'
import { Router } from './routes'
import "tailwindcss/tailwind.css";
import './index.css'
import './scss/style.scss'

class App extends Component {
  render() {
    return (
     <Router/>
    )
  }
}
export default App
