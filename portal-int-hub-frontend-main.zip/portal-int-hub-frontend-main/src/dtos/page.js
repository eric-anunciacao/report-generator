export const Page = () => {
    return {
        "content": [],
        "empty":true,
        "first": true,
        "last": true,
        "number": 0,
        "numberOfElements": 0,
        "totalElements": 0,
        "totalPages": 0,
        "size": 0,
        "pageable" : {},
        "sort": {}
      }
}