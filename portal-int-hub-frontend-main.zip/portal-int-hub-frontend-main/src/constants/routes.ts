
export enum ROUTES{
    HOME = "/",
    MESSAGES = "/analitico-mensagens",
    INTEGRATION = "/configuracao/integracao",
    NEW_INTEGRATION = "/configuracao/integracao/new",
    UPDATE_INTEGRATION = "/configuracao/integracao/edit",
    CLUSTER = "/configuracao/cluster",
    NEW_CLUSTER = "/configuracao/cluster/new",
    UPDATE_CLUSTER = "/configuracao/cluster/edit",
    REPROCESSED = "/reprocessados",
    REPROCESSED_PAYLOAD = "/reprocessados/payload",
    ENVIRONMENT_STATUS = "/status-ambiente",
    AUTOREPROCESSING = "/configuracao/autoreprocessamento",
    NEW_AUTOREPROCESSING = "/configuracao/autoreprocessamento/new",
    UPDATE_AUTOREPROCESSING = "/configuracao/autoreprocessamento/edit",
}

