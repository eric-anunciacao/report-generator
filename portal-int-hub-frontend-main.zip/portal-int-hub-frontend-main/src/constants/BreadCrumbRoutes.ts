import { IBreadCrumbRoute } from 'src/domain/entities/interfaces/IBreadCrumbRoute'
import { ROUTES } from './routes'

export const BREADCRUMB_ROUTES: IBreadCrumbRoute[] = [
  {
    path: ROUTES.HOME,
    name: 'Início',
  },
  {
    path: ROUTES.MESSAGES,
    name: 'Analítico de Mensagens',
  },
  {
    path: ROUTES.REPROCESSED,
    name: 'Reprocessados',
  },
  {
    path: ROUTES.REPROCESSED_PAYLOAD,
    name: 'Payload',
  },
  {
    path: ROUTES.ENVIRONMENT_STATUS,
    name: 'Status Ambiente',
  },
  {
    path: ROUTES.INTEGRATION,
    name: 'Lista de Integrações',
  },
  {
    path: ROUTES.UPDATE_INTEGRATION,
    name: 'Editar Integração',
  },
  {
    path: ROUTES.NEW_INTEGRATION,
    name: 'Cadastro de Integração',
  },
  {
    path: ROUTES.CLUSTER,
    name: 'Lista de Clusters',
  },
  {
    path: ROUTES.UPDATE_CLUSTER,
    name: 'Editar Cluster',
  },
  {
    path: ROUTES.NEW_CLUSTER,
    name: 'Cadastro de Cluster',
  },
]
