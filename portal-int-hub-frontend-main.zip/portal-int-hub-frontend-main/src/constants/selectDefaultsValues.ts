import { IItemSelect } from 'src/domain/entities/interfaces/IItemSelect'

export const SELECT_DEFAULTS_VALUES = {
  STATUS_FILTER:[
    { label: 'Sucesso', value: 'Sucesso' },
    { label: 'Erro', value: 'Erro' },
    { label: 'Reprocessado', value: 'Reprocessado' },
    { label: 'Aguardando reprocessamento', value: 'Aguardando reprocessamento' },
    { label: 'Falha no reprocessamento', value: 'Falha no reprocessamento' }
  ],

  TYPE_FILTER:[
    { label: 'Individual', value: 0 },
    { label: 'Filtro em Massa', value: 1 },    
  ]
}
