export const API = process.env.REACT_APP_API;
// export const TIMER_DASHBOARD = 30000;