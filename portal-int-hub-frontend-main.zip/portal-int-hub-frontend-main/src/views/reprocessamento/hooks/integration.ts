import { API } from "src/constants"

export const getIntegrationList = async () => {
  const res = await fetch(`${API}integration-controller`, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}

export const getIntegrationShortList = async () => {
  const res = await fetch(`${API}integrations/short`, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}

export const getIntegrationByClusterList = async (idCluster: string) => {
  const res = await fetch(`${API}integration-controller/findByClusterId/${idCluster}`, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}
export const getIntegration = async (id:string) => {
  const res = await fetch(`${API}integration-controller/${id}`, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}

export const saveIntegration = async (requestData:any) => {
  const requestOptions = {
    method: 'POST',
    body: requestData,
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}integration-controller`, requestOptions)

  return response
}

export const deleteIntegration = async (id:string) => {
  const requestOptions = {
    method: 'DELETE',
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}integration-controller/${id}`, requestOptions)

  return response
}

export const updateIntegration = async (requestData: any) => {
  const requestOptions = {
    method: 'PUT',
    body: requestData,
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}integration-controller`, requestOptions)

  return response
}
