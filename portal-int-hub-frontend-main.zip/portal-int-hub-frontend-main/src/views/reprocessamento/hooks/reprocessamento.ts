import { API } from 'src/constants'
import moment from 'moment'
import 'moment/locale/pt-br'

export const getReprocesamentoList = async (props : any)  => {
  const filter =
    `${API}queue-controller?pageNumber=${props.page}&pageSize=${props.pageSize}&` +
    (props.status ? `status=${props.status}&` : '') +
    (props.identifier ? `identifier=${props.identifier}&` : '') +
    (props.clusterId ? `clusterId=${props.clusterId}&` : '') +
    (props.integrationId ? `integrationId=${props.integrationId}&` : '') +
    (props.dtEventBegin ? `dtEventBegin=${props.dtEventBegin} ${props.initialHour}&` : '') +
    (props.dtEventEnd ? `dtEventEnd=${props.dtEventEnd} ${props.endHour}&` : '')

  const res = await fetch(filter, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}

export const handleGetLogsMessage = async (props : string) => {
  const filter = `${API}queue-controller/getQueueLogsByQueueId?queueId=${props}`
  const res = await fetch(filter, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })
  return res
}

//buscando o payload comple
export const getPayloadFull = async (props: string)=>{
  const filter = `${API}queue-controller/${props}`
  const res = await fetch(filter, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })
  return res
}


export const handleGetReprocessingByMassFilter = async (requestData : any) => {
  const requestOptions = {
    method: 'POST',
    body: JSON.stringify(requestData),
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}queue-controller/filterMass`, requestOptions)

  return response
}

export const getReprocessadosList = async (props : any) => {
  const res = await fetch(
    `${API}getAllQueue/?` +
      (props.status ? `status=${props.status}&` : '') +
      (props.identifier ? `identificador=${props.identifier}&` : '') +
      (props.integrationId ? `integrationId=${props.integrationId}&` : '') +
      (props.dtEventBegin ? `dtEventBegin=${props.dtEventBegin}&` : '') +
      (props.dtEventEnd ? `dtEventEnd=${props.dtEventEnd}&` : ''),
    { headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' } },
  )

  return res
}

export const updateReprocessamento = async (requestData : any) => {
  const requestOptions = {
    method: 'PUT',
    body: requestData,
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}queue-controller`, requestOptions)

  return response
}

export const updateListReprocessamento = async (requestData : any) => {
  const requestOptions = {
    method: 'PUT',
    body: requestData,
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}queue-controller/update-queues`, requestOptions)

  return response
}

export const exportIntegrationToExcel = async (requestData : any) => {
  const url =
    `${API}queue-controller/export/excel?integrationId=${requestData.integrationId}&` +
    (requestData.dtEventBegin ? `dtEventBegin=${requestData.dtEventBegin} 00:00:00&` : '') +
    (requestData.dtEventEnd ? `dtEventEnd=${requestData.dtEventEnd} 23:59:59&` : '')

  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}
