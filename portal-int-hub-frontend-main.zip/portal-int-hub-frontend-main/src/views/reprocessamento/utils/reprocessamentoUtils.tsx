
import { UtilsString } from "../../../utils/string";

export function RenameStatus(oldStatus:string) {
  switch(oldStatus) {

      case 'Pendente':
        return 'Pendente';
      case 'Erro':
        return 'Erro';
      case 'Sucesso':
        return 'Sucesso';
      case 'Autorizado':
        return 'Autorizado';
      case 'Reprocessado':
        return 'Reprocessado';
      case 'Aguardando reprocessamento':
        return 'Aguardando reprocessamento';
      case 'Falha no reprocessamento':
        return 'Falha no reprocessamento';
      default:
        return '';

  }

 }

 export function CollorStatus(oldStatus:string) {
  switch(oldStatus) {

      case 'Pendente':
        return 'Pendente';
      case 'Erro':
        return 'rgba(255, 150, 150, 0.49)';
      case 'Sucesso':
        return 'rgba(157, 255, 118, 0.49)';
      case 'Autorizado':
        return 'Autorizado';
      case 'Reprocessado':
        return 'rgba(10, 150, 255, 0.49)';
      case 'Aguardando reprocessamento':
        return 'rgba(255, 165, 0, 0.49)';
      case 'Falha no reprocessamento':
        return 'rgba(90, 90, 90, 0.49)';
      default:
        return '';

  }

 }

 export function CellClassName(params:any){
  if ( UtilsString.isNullOrEmpty(params.value) ) {
    return '';
  }
  if(params.value === 'Autorizado' || params.value === 'Reprocessado'){
    return 'reprocessado';
  }
  if(params.value === 'Sucesso'){
    return 'sucesso';
  }
  if(params.value === 'Erro'){
    return 'erro';
  }
  if(params.value === 'Pendente'){
    return 'pendente';
  }
  if(params.value === 'Processando'){
    return 'processando';
  }
  if(params.value === 'Reprocessar'){
    return 'reprocessar';
  }
  if(params.value === 'Aguardando reprocessamento'){
    return 'aguardandoreprocess'
  }
  if(params.value === 'Falha no reprocessamento'){
    return 'falhareprocess'
  }

  return '';
}
