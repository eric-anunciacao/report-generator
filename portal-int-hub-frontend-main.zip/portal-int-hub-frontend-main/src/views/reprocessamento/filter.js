import * as React from 'react'
import { CButton, CCol, CFormInput, CFormLabel, CFormSelect, CTooltip } from '@coreui/react'
import { getIntegrationByClusterList, getIntegrationList } from './hooks/integration'
import { getClusterList } from '../cluster/hooks/cluster'
import { MultiSelect } from 'react-multi-select-component'
import CIcon from '@coreui/icons-react'
import * as icon from '@coreui/icons'
import Select from 'react-select'
import AsyncSelect from 'react-select/async'
import { useAsyncDeepState } from 'use-async-effect2'
import CustomMultiSelect from 'src/components/CustomMultiSelect'

export const FilterReprocessamento = (change) => {
  const [integrationList, setIntegrationList] = React.useState([])
  const [selectedOption, setSelectedOption] = React.useState(null)
  const [filterSelected, setFilterSelected] = React.useState(0)

  const [placeholderIdentifier, setPlaceholderIdentifier] = React.useState('')

  const optionsStatus = [
    { label: 'Sucesso', value: 'Sucesso' },
    { label: 'Erro', value: 'Erro' },
    { label: 'Reprocessado', value: 'Reprocessado' },
    { label: 'Aguardando reprocessamento', value: 'Aguardando reprocessamento' },
    { label: 'Falha no reprocessamento', value: 'Falha no reprocessamento' }
  ]



  const customMultSelect = {
    allItemsAreSelected: 'Todos os itens Selecionados.',
    clearSearch: 'Limpar',
    search: 'Procurar...',
    selectAll: 'Selecionar Tudo',
    selectAllFiltered: 'Selecionar Tudo',
    selectSomeItems: 'Selecione',
  }

  const clear = () => {
    change.clean()
    searchIntegration()
    setSelectedOption(null)
  }

  const onChangeIntegration = (currentIntegration) => {
    setSelectedOption(currentIntegration)
    change.setIntegracao(currentIntegration.value)
    const integration = integrationList?.find((i) => i.id == currentIntegration.value)
    change.setSelectedIntegration(integration)
    setPlaceholderIdentifier(buildIdentifierPlaceholder(integration))
    handleGenerateMasFilterIdentifiers(integration)
  }

  //gerando array com os identificadores de acordo com o filtro selecionado e setando no array
  //do modal de filtro em massa
  const handleGenerateMasFilterIdentifiers = (integration) => {    
    try {
      let identifiers = []
      identifiers.push({
        value: "identifier",
        label: integration?.nameIdentifier1,
       
      })

      if (integration?.nameIdentifier2) {
        identifiers.push({
          value: "identifier2",
          label: integration?.nameIdentifier2,
         
        })
      }
      if (integration?.nameIdentifier3) {
        identifiers.push({
          value: "identifier3",
          label: integration?.nameIdentifier3,
          
        })
      }
      if (integration?.nameIdentifier4) {
        identifiers.push({
          value: "identifier",
          label: integration?.nameIdentifier4,
         
        })
      }

      change.setMassFilterIdentifierList(identifiers)
    } catch (error) {
      console.log(error)
    }
  }

  const buildIdentifierPlaceholder = (integration) => {
    let placeholder = integration?.nameIdentifier1 + '; '
    if (integration?.nameIdentifier2) {
      placeholder += integration.nameIdentifier2 + '; '
    }
    if (integration?.nameIdentifier3) {
      placeholder += integration.nameIdentifier3 + '; '
    }
    if (integration?.nameIdentifier4) {
      placeholder += integration.nameIdentifier4 + '; '
    }

    return placeholder
  }

  const mapOptionsToValues = (options) => {
    return options.map((option) => ({
      value: option.id,
      label: option.name,
    }))
  }

  const searchIntegration = async () => {
    try {
      let res
      res = await getIntegrationList()
      const json = await res.json()

      if (res.ok) {
        setIntegrationList(json)
        change.setError('')
      } else {
        change.setError('Erro: Não foi possível exibir a listagem de Integração')
      }
    } catch (e) {
      change.setError('Erro: Não foi possível exibir a listagem de Integração')
    }
  }

  React.useEffect(() => {
    searchIntegration()
  }, [])

  const filterIntegrationName = (inputValue) => {
    return mapOptionsToValues(integrationList).filter((i) =>
      i.label.toLowerCase().includes(inputValue.toLowerCase()),
    )
  }

  const promiseOptions = (inputValue) =>
    new Promise((resolve) => {
      setTimeout(() => {
        resolve(filterIntegrationName(inputValue))
      }, 1000)
    })

  return (
    <div className="flex flex-col">
      {/* line 1 */}
      <div className="flex flex-col lg:flex-row gap-2 items-center">
        <div className="flex flex-col w-full lg:w-1/4">
          <CFormLabel>Integração</CFormLabel>
          <AsyncSelect
            value={selectedOption}
            loadOptions={promiseOptions}
            placeholder="Selecione"
            noOptionsMessage={() => 'Não encontrado'}
            loadingMessage={() => 'Carregando...'}
            defaultOptions={mapOptionsToValues(integrationList)}
            onChange={(e) => {
              onChangeIntegration(e)
            }}
            theme={(theme) => ({
              ...theme,
              colors: {
                ...theme.colors,
                text: '#000',
                primary25: '#A6ACBF',
                primary: '#706F80',
                primary50: '#A6ACBF',
              },
            })}
          />
        </div>

        <div className="flex flex-col w-full lg:w-1/4">
          <CFormInput
          // desabilitando campo caso não exista integração selecionada ou caso existam dados no filtro de massa
            disabled={!change.integracao ? true : change.massFilterList.length ? true : false}
            value={change.identificador}
            label="Identificador"
            onChange={(e) => change.setIdentificador(e.target.value)}
            placeholder={!change.integracao ? 'Identificador' : placeholderIdentifier}
          />
        </div>

        <div className="flex flex-col w-full  lg:w-1/4">
          <CFormLabel>Filtro em massa</CFormLabel>

          <div className="flex w-full  flex-row gap-2">
            <div className='flex w-4/5'>
              <CustomMultiSelect
                options={change.massFilterList}
                value={change.massFilterList}
                handleChangeMassFilter={change.handleChangeMassFilter}
                // desabilitando campo caso não exista integração selecionada ou caso existam dados no filtro individual
                disabled={!change.integracao ? true : change.identificador ? true : false}
              />
            </div>
            <div className='flex w-1/5 items-center justify-center'>
              <CButton
                onClick={()=>{                  
                  change.addMassFilter(true)
                }}
                color="dark"
                // desabilitando botão não exista integração selecionada ou caso existam dados no filtro individual
                disabled={!change.integracao ? true : change.identificador ? true : false}
               className="flex items-center justify-center w-full"
              >
                <CIcon
                  style={{ cursor: 'pointer'}}
                  size="lg"
                  icon={icon.cilPlus}
                />
              </CButton>
              
            </div>
          </div>
        </div>
        <div className="flex flex-col w-full lg:w-1/4">
          <CFormLabel>Status</CFormLabel>
          <MultiSelect
            disabled={!change.integracao}
            labelledBy="Selecione"
            placeholder="Selecione"
            hasSelectAll={false}
            overrideStrings={customMultSelect}
            options={optionsStatus}
            value={change.selectedStatus}
            onChange={(value) => change.setSelectedStatus(value)}
          />
        </div>
      </div>

      {/* line 2 */}
      <div className="flex flex-col md:flex-row gap-2 items-center mt-3 ">
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CFormInput
            disabled={!change.integracao}
            value={change.selectedInitialDate}
            onChange={(e) => change.setSelectedInitialDate(e.target.value)}
            label="Data de Evento - Início"
            placeholder="Data de Evento - Início"
            type="date"
          />
        </div>
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CFormInput
            disabled={!change.integracao}
            value={change.selectedInitialHour}
            maxLength="8"
            onChange={(e) => change.setSelectedInitialHour(e.target.value)}
            label="Hora do Evento - Início"
            placeholder="00:00:00"
            type="time"
            step="1"
          />
        </div>
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CFormInput
            disabled={!change.integracao}
            value={change.selectedEndDate}
            onChange={(e) => change.setSelectedEndDate(e.target.value)}
            label="Data de Evento - Fim"
            placeholder="Data de Evento - Fim"
            type="date"
          />
        </div>
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CFormInput
            disabled={!change.integracao}
            value={change.selectedEndHour}
            maxLength="8"
            onChange={(e) => change.setSelectedEndHour(e.target.value)}
            label="Hora do Evento - Fim"
            placeholder="00:00:00"
            type="time"
            step="1"
          />
        </div>
      </div>

      {/* line 3 */}
      <div className="flex flex-col md:flex-row gap-2 items-center mt-3 mb-3">
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CButton
            disabled={!change.integracao || change.identifierSelected?.length < 2}
            onClick={change.reproccessList}
            color="dark"
          >
            <CIcon
              style={{ cursor: 'pointer', marginRight: '20px' }}
              size="lg"
              icon={icon.cilLoopCircular}
            />
          </CButton>
        </div>
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CButton
            disabled={!change.integracao}
            onClick={change.handleSearch}
            color="dark"
            style={{ textAlignLast: 'center' }}
          >
            Filtrar
          </CButton>
        </div>
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CButton onClick={clear} color="dark" style={{ textAlignLast: 'center' }}>
            Limpar
          </CButton>
        </div>
        <div className="flex flex-col justify-center w-full lg:w-1/4">
          <CButton
            disabled={change.isEmpty || change.loading}
            onClick={change.exportData}
            color="dark"
            style={{ textAlignLast: 'center' }}
          >
            Exportar
          </CButton>
        </div>
      </div>

      {/* <CCol md={3} style={{ padding: '10px' }}>
      <CFormLabel className="col-sm-8 col-form-label">Tipo de filtro</CFormLabel>
      <Select
        options={options}
        isDisabled={!change.integracao}
        placeholder="Selecione"
        onChange={(value) => {
          setFilterSelected(value.value)
        }}
      />
      </CCol>
      <CCol md={3} style={{ padding: '10px' }}>
      </CCol>
      <CCol md={3} style={{ padding: '15px' }}>
        {filterSelected === 0 && (
          <CFormInput
            disabled={!change.integracao}
            value={change.identificador}
            label="Identificador"
            onChange={(e) => change.setIdentificador(e.target.value)}
            placeholder={!change.integracao ? 'Identificador' : placeholderIdentifier}
          />
        )}
        {filterSelected === 1 && (
          <>
            <CFormLabel className="col-sm-8 col-form-label">Filtro de massa</CFormLabel>
            <div className="flex  flex-row gap-2 max-w-[500px]">
              <CustomMultiSelect
                options={change.massFilterList}
                value={change.massFilterList}
                handleChangeMassFilter={change.handleChangeMassFilter}
              />
              <CButton
                onClick={change.addMassFilter}
                color="dark"
                style={{ textAlignLast: 'center', width: '45px', marginRight: '10px' }}
              >
                <CIcon
                  style={{ cursor: 'pointer', marginRight: '20px' }}
                  size="lg"
                  icon={icon.cilPlus}
                />
              </CButton>
            </div>
          </>
        )}
      </CCol>

      <CCol md={3} style={{ padding: '10px' }}>
        <CFormLabel className="col-sm-4 col-form-label">Status</CFormLabel>
        <MultiSelect
          disabled={!change.integracao}
          labelledBy="Selecione"
          placeholder="Selecione"
          hasSelectAll={false}
          overrideStrings={customMultSelect}
          options={optionsStatus}
          value={change.selectedStatus}
          onChange={(value) => change.setSelectedStatus(value)}
        />
      </CCol>

      <CCol md={2} style={{ padding: '15px' }}>
        <CFormInput
          disabled={!change.integracao}
          value={change.selectedInitialDate}
          onChange={(e) => change.setSelectedInitialDate(e.target.value)}
          label="Data de Evento - Início"
          placeholder="Data de Evento - Início"
          type="date"
        />
      </CCol>

      <CCol md={2} style={{ padding: '15px' }}>
        <CFormInput
          disabled={!change.integracao}
          value={change.selectedInitialHour}
          maxLength="8"
          onChange={(e) => change.setSelectedInitialHour(e.target.value)}
          label="Hora do Evento - Início"
          placeholder="00:00:00"
          type="time"
          step="1"
        />
      </CCol>
      <CCol md={2} style={{ padding: '15px' }}>
        <CFormInput
          disabled={!change.integracao}
          value={change.selectedEndDate}
          onChange={(e) => change.setSelectedEndDate(e.target.value)}
          label="Data de Evento - Fim"
          placeholder="Data de Evento - Fim"
          type="date"
        />
      </CCol>
      <CCol md={2} style={{ padding: '15px' }}>
        <CFormInput
          disabled={!change.integracao}
          value={change.selectedEndHour}
          maxLength="8"
          onChange={(e) => change.setSelectedEndHour(e.target.value)}
          label="Hora do Evento - Fim"
          placeholder="00:00:00"
          type="time"
          step="1"
        />
      </CCol>
      <CCol xs md={4} style={{ textAlignLast: 'right', padding: '20px', paddingTop: '50px' }}>
        <CTooltip content="Reprocessar" placement="top">
          <CButton
            disabled={!change.integracao || change.identifierSelected?.length < 2}
            onClick={change.reproccessList}
            color="dark"
            style={{ textAlignLast: 'center', width: '45px', marginRight: '10px' }}
          >
            <CIcon
              style={{ cursor: 'pointer', marginRight: '20px' }}
              size="lg"
              icon={icon.cilLoopCircular}
            />
          </CButton>
        </CTooltip>
        <CButton
          disabled={!change.integracao}
          onClick={change.handleSearch}
          color="dark"
          style={{ textAlignLast: 'center', width: '85px', marginRight: '10px' }}
        >
          Filtrar
        </CButton>
        <CButton
          onClick={clear}
          color="dark"
          style={{ textAlignLast: 'center', width: '85px', marginRight: '10px' }}
        >
          Limpar
        </CButton>
        <CButton
          disabled={change.isEmpty || change.loading}
          onClick={change.exportData}
          color="dark"
          style={{ textAlignLast: 'center', width: '90px' }}
        >
          Exportar
        </CButton>
      </CCol> */}
    </div>
  )
}
