import * as React from 'react';
import { CButton, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle } from "@coreui/react"
import { updateReprocessamento } from '../hooks/reprocessamento';
import { IIntegration } from 'src/domain/entities/interfaces/IIntegration';

interface IConfirmationProps{
  open: boolean;
  close:()=>void;
  setError: (error:string)=>void
  onFinish: ()=> void
  message: string;
  row: IIntegration

}

export const ConfirmationPopup = ({open,close,setError,onFinish,message,row}:IConfirmationProps) => {

    const handleSend = async () => {

        try{

            const res = await updateReprocessamento(JSON.stringify(row, null, 4));
            if(res.ok){
            onFinish();
            }else{
                setError('Erro: Não foi possível enviar o Payload');
            }
        }catch(e){
            setError('Erro: Não foi possível enviar o Payload');
        }
        close();
    };

    return (<>
        <CModal
            visible={open}
            onClose={close}
        >
        <CModalHeader>
            <CModalTitle>Atenção</CModalTitle>
        </CModalHeader>
        <CModalBody>{message}</CModalBody>
        <CModalFooter>
            <CButton color="light" onClick={close}>Cancelar</CButton>
            <CButton color="dark" onClick={handleSend}>Confirmar</CButton>
        </CModalFooter>
        </CModal>
    </>)
}
