import * as React from 'react';
import { CModal, CModalBody, CModalHeader, CModalTitle, CTable, CTableBody, CTableDataCell, CTableHead, CTableHeaderCell, CTableRow } from '@coreui/react';

import 'moment/locale/pt-br';
import moment from 'moment';

const LogComponent = (props) => {

    const handleClose = () => {
      props.close();
    }

    return (
      <>
        <CModal visible={props.open} onClose={handleClose} size='xl' >
          <CModalHeader onClose={handleClose}>
            <CModalTitle>Integração: {props.row?.integration?.name} / Identificador: {props.row?.identifier}</CModalTitle>
          </CModalHeader>
          <CModalBody >
            <div style={{margin: '20px'}}>
              <CTable>
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell scope="col">#</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Status</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Detalhes</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Data Evento</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Reprocessamento</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {
                    props.logs?.map( (log,index) =>
                    <><CTableRow>
                        <CTableHeaderCell scope="row">{index+1}</CTableHeaderCell>
                        <CTableDataCell>{log?.status}</CTableDataCell>
                        <CTableDataCell>{log?.message == null ? '-' : log?.message}</CTableDataCell>
                        <CTableDataCell>{ moment(log?.dtEvent).format('DD/MM/YYYY H:mm:ss') }</CTableDataCell>
                        <CTableDataCell>{log?.isAutomaticChange == true ? 'Automático' : (log?.isAutomaticChange == null ? '' : 'Manual')}</CTableDataCell>
                      </CTableRow>
                    </> )
                  }
                </CTableBody>
              </CTable>
            </div>
          </CModalBody>
        </CModal>
      </>
      );

}

export default LogComponent;
