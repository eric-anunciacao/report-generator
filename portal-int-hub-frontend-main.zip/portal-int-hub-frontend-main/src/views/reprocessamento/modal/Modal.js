import * as React from 'react';
import {
  CButton,
  CFormTextarea,
  CModal,
  CModalBody,
  CModalFooter,
  CModalHeader,
  CModalTitle,
  CCard,
  CCollapse,
  CCardBody,
  CCardFooter
} from '@coreui/react';

import 'moment/locale/pt-br';
import moment from 'moment';
import {updateReprocessamento} from '../hooks/reprocessamento';
import {UtilsString} from '../../../utils/string';
import {TopAlertErrorComponent} from '../../../utils/alerts';
import {RenameStatus} from '../utils/reprocessamentoUtils';
import {IIntegration} from 'src/domain/entities/interfaces/IIntegration';


const ModalReprocessamentoComponent = (props) => {

  const [modifiedPayload, setModifiedPayload] = React.useState('');
  const [error, setError] = React.useState('');
  const [collapseCause, setCollapseCause] = React.useState(false);
  const [collapseMessage, setCollapseMessage] = React.useState(false);
  const [collapseStacktrace, setCollapseStacktrace] = React.useState(false);

  const toggleCause = () => {
    setCollapseCause(!collapseCause);
  }

  const toggleMessage = () => {
    setCollapseMessage(!collapseMessage);
  }

  const toggleStacktrace = () => {
    setCollapseStacktrace(!collapseStacktrace);
  }

  React.useEffect(() => {

    setModifiedPayload(props.row);


  }, []);

  const formatPayload = (payload) => {
    const newPayload = {
      correlationId: props.row.correlationId,
      id: props.row?.id,
      identifier: props.row?.identifier,
      identifier2: props.row?.identifier2,
      identifier3: props.row?.identifier3,
      identifier4: props.row?.identifier4,
      integration: props.row?.integration,
      status: props?.row?.status,
      dtEvent: props.row?.dtEvent,
      dtUpdate: props.row?.dtUpdate,
      exceptionClass: props.row?.exceptionClass,
      exceptionMessage: props.row?.exceptionMessage,
      exceptionStacktrace: props.row?.exceptionStacktrace,
      key: props.row?.key,
      messageOffset: props.row?.messageOffset,
      partition: props.row?.partition,
      exceptionCause: props.row?.exceptionCause,
      successPayload: props.row?.successPayload,
      message: payload ?? props.row?.message
    }

    return newPayload;

  }

  const handleClose = () => {
    setError('');
    props.close();
  }

  const handleSend = async () => {

    try {
      const res = await updateReprocessamento(JSON.stringify(formatPayload(modifiedPayload)));
      if (res.ok) {
        setError('');
        props.onFinish();
      } else {
        setError('Erro: Não foi possível enviar. Verifique a conexão ou a formatação do payload.');
      }
    } catch (e) {
      setError('Erro: Não foi possível enviar. Verifique a conexão ou a formatação do payload.');
    }

  };

  return (
    <>
      <CModal visible={props.open} onClose={handleClose} size="xl">
        <CModalHeader onClose={props.close}>
          <CModalTitle>Integração: {props.row?.integration?.name}</CModalTitle>
        </CModalHeader>
        <CModalBody>
          {error && <TopAlertErrorComponent setError={setError} message={error}/>}
          <div style={{overflow: 'scroll', maxHeight: '600px', overflowX: 'hidden'}}>
            <div style={{display: 'flex', justifyContent: 'space-between', margin: '20px'}}>
              <div style={{flex: 1}}>
                <h5>Identificador</h5>
                <span>{props?.row?.identifier}</span>
              </div>
              <div style={{flex: 1}}>
                <h5>Status</h5>
                <span>{RenameStatus(props?.row?.status)}</span>
              </div>
            </div>
            <div style={{display: 'flex', justifyContent: 'space-between', margin: '20px'}}>
              <div style={{flex: 1}}>
                <h5>Data de Evento</h5>
                <span>{moment(props?.row?.dtEvent).format('DD/MM/YYYY HH:mm:ss')}</span>
              </div>
              <div style={{flex: 1}}>
                <h5>Data de Alteração</h5>
                <span>{!UtilsString.isNullOrEmpty(props.row?.dtUpdate) ? moment(props.row?.dtUpdate).format('DD/MM/YYYY HH:mm:ss') : 'Sem data de alteração'}</span>
              </div>
            </div>
            <div style={{margin: '20px'}}>
              <h5>Payload</h5>
              <div>
                <CFormTextarea
                  rows="12"
                  onChange={(e) => setModifiedPayload(e?.target?.value)}
                  defaultValue={props.row?.message}>
                </CFormTextarea>
              </div>
            </div>
            <CCard style={{margin: '20px', display: props.row?.status !== "Sucesso"  ? "block" : "none"}}>
              <CCardBody>
                <h4> Erros </h4>
                <div style={{margin: '20px'}}>
                  <CCard>
                    <CCollapse
                      visible={collapseCause}
                    >
                      <CCardBody>
                        <p>
                          {UtilsString.isNullOrEmpty(props.row?.exceptionCause) ? 'Sem erros' : props.row?.exceptionCause}
                        </p>
                      </CCardBody>
                    </CCollapse>
                    <CCardFooter>
                      <CButton
                        color="light"
                        onClick={toggleCause}
                        className={'mb-1'}
                      >
                        Causa
                      </CButton>
                    </CCardFooter>
                  </CCard>
                </div>
                <div style={{margin: '20px'}}>
                  <CCard>
                    <CCollapse
                      visible={collapseMessage}
                    >
                      <CCardBody>
                        <p>
                          {UtilsString.isNullOrEmpty(props.row?.exceptionMessage) ? 'Sem erros' : props.row?.exceptionMessage}
                        </p>
                      </CCardBody>
                    </CCollapse>
                    <CCardFooter>
                      <CButton
                        color="light"
                        onClick={toggleMessage}
                        className={'mb-1'}
                      >
                        Mensagem
                      </CButton>
                    </CCardFooter>
                  </CCard>
                </div>
                <div style={{margin: '20px'}}>
                  <CCard>
                    <CCollapse
                      visible={collapseStacktrace}
                    >
                      <CCardBody>
                        <p>
                          {UtilsString.isNullOrEmpty(props.row?.exceptionStacktrace) ? 'Sem erros' : props.row?.exceptionStacktrace}
                        </p>
                      </CCardBody>
                    </CCollapse>
                    <CCardFooter>
                      <CButton
                        color="light"
                        onClick={toggleStacktrace}
                        className={'mb-1'}
                      >
                        StackTrace
                      </CButton>
                    </CCardFooter>
                  </CCard>
                </div>
              </CCardBody>
            </CCard>

            <CCard style={{margin: '20px', display: props.row?.status === "Sucesso"  && !UtilsString.isNullOrEmpty(props.row?.successPayload) ? "block" : "none"}}>
              <CCardBody>
                <h4> Retorno de Sucesso </h4>
                <div style={{margin: '20px'}}>
                  <CCard>
                    <CCollapse
                      visible={collapseCause}
                    >
                      <CCardBody>
                        <p>
                          {UtilsString.isNullOrEmpty(props.row?.successPayload) ? '-' : props.row?.successPayload}
                        </p>
                      </CCardBody>
                    </CCollapse>
                    <CCardFooter>
                      <CButton
                        color="light"
                        onClick={toggleCause}
                        className={'mb-1'}
                      >
                        Mensagem
                      </CButton>
                    </CCardFooter>
                  </CCard>
                </div>
              </CCardBody>
            </CCard>
          </div>
        </CModalBody>
        <CModalFooter>
          <CButton onClick={handleClose} color="light">Cancelar</CButton>
          <CButton onClick={handleSend} color="dark">Reprocessar</CButton>
        </CModalFooter>
      </CModal>
    </>
  );

}

export default ModalReprocessamentoComponent;
