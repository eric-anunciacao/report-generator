import * as React from 'react'
// import DLQTable, { CustomDLQTable } from 'src/components/DLQTable'
import { CustomDLQTable } from '../../components/DLQTable'
import { CCard, CCardBody, CForm, CRow, CTooltip } from '@coreui/react'
import {
  TopAlertErrorComponent,
  TopAlertSuccessComponent,
  TopAlertWarningComponent,
} from '../../utils/alerts'
import { RenameStatus, CellClassName, CollorStatus } from './utils/reprocessamentoUtils'
import { FilterReprocessamento } from './filter'
import ModalReprocessamentoComponent from './modal/Modal'
import moment from 'moment'
import 'moment/locale/pt-br'
import { getReprocesamentoList, updateListReprocessamento,handleGetReprocessingByMassFilter, handleGetLogsMessage, getPayloadFull } from './hooks/reprocessamento'
import CIcon from '@coreui/icons-react'
import * as icon from '@coreui/icons'
import { ConfirmationPopup } from './modal/Confirmation'
import LogComponent from './modal/Log'
import ModalExportXLSX from '../../utils/exportXLSX'
import { Page } from '../../dtos/page'
import FilterMassModal from 'src/components/Modals/FilterMassModal'
import { siLK } from '@mui/material/locale'
import { useState } from 'react'


const Reprocessamento = () => {
  const [loading, setLoading] = useState(false)
  const [loadingExport, setLoadingExport] = useState(false)

  const [selectedStatus, setSelectedStatus] = useState([])
  const [selectedInitialDate, setSelectedInitialDate] = useState(moment().startOf("month").format("YYYY-MM-DD"))
  const [selectedInitialHour, setSelectedInitialHour] = useState('')
  const [selectedEndDate, setSelectedEndDate] = useState(moment().format('YYYY-MM-DD'))
  const [selectedEndHour, setSelectedEndHour] = useState('')
  const [integracao, setIntegracao] = useState(0)
  const [identificador, setIdentificador] = useState('')
  const [clusterId, setClusterId] = useState('')
  const [selectedIntegration, setSelectedIntegration] = useState(null)

  const [pagination, setPagination] = useState(Page)
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(100)

  const [reprocessamentoList, setReprocessamentoList] = useState([])
  const [identifierSelected, setIdentifierSelected] = useState([])
  const [selected, setSelected] = useState({ 2: true, 5: true })
  const [error, setError] = useState('')
  const [visibleModalMassFilter, setVisibleModalMassFilter] = useState(false)
  const [massFilterList, setMassFilterList] = useState([])
  const [massFilterIdentifierList, setMassFilterIdentifierList] = useState([])

  const clean = () => {
    setSelectedStatus([])
    setSelectedInitialDate('')
    setSelectedInitialHour('')
    setSelectedEndDate('')
    setSelectedEndHour('')
    setIntegracao(0)
    setIdentificador('')
    setClusterId('')
    setSelectedIntegration(null)
    setReprocessamentoList([])
    setIdentifierSelected([])
    setSelected({ 2: true, 5: true })
    setPagination(Page)
    setMassFilterList([])
  }

  const [open, setOpen] = useState(false)
  const [openExport, setOpenExport] = useState(false)
  const [confirmation, setConfirmation] = useState(false)
  const [openLog, setOpenLog] = useState(false)

  const [openConfirmation, setOpenConfirmation] = useState(false)

  const [row, setRow] = useState(null)
  const [selectedLog, setSelectedLog] = useState(null)

  //abrindo alerta para filtro de massa enviando o dado a ser buscado
  const handleAddDataOnMassFilter = (label, data) => {
    const newFilters = data.split('\n').filter((item) => item !== '')
    setMassFilterList((prevState) => {
      return prevState.concat(
        newFilters.map((filter) => {
          return { label: filter, value: label }
        }),
      )
    })
    setVisibleModalMassFilter(false)
  }

  const handleValidateDateFields = () => {

    if (!selectedInitialDate || !selectedEndDate) {
      setError('Necessário preencher as datas para realizar a busca')
      return
    }

    if(moment(selectedInitialDate).isAfter(moment(selectedEndDate))){
      setError("A data inicial não pode ser posterior a data final")
      return
    }

    if(moment(selectedEndDate).diff(moment(selectedInitialDate),"days") > 31){
      setError("O Intervalo para o filtro de mensagens é de no máximo 31 dias");
      return;
    }

    handleSearch()
  }

  //gerando o payload de identifiers de acordo com os filtros em massa selecionados no componente
  const handleGeneratePayloadMassFilter = () => {
    try {
      let massFilterPayload = []
      massFilterList.forEach((filter) => {
        // validando se já existe algum elemento com o mesmo identificador
        if (massFilterPayload.some((element) => element.type === filter.value)) {
          //buscando o elemento pré-existente e adicionando o novo valor para o filtro dentro do array
          massFilterPayload = massFilterPayload.map((readyFilter) =>
            readyFilter.type === filter.value
              ? { ...readyFilter, values: [...readyFilter.values, filter.label] }
              : readyFilter,
          )
        } else {
          //caso não exista nenhum elemento com o identificador adiciona um elemento novo
          massFilterPayload.push({
            type: filter.value,
            values: [filter.label],
          })
        }
      })
      return massFilterPayload
    } catch (error) {
      console.log(error)
      return []
    }
  }

  const handleGeneratePayloadStatus = ()=>{
    return  selectedStatus?.map((v) => v.value)?.join(';')
  }

  const handleSearch = async (currentPage = null, currentPageSize = null) => {

    if(massFilterList.length){
      handleSearchByMassFilter(currentPage,currentPageSize)
    }else{
      handleSearchIndividualFilter(currentPage,currentPageSize)
    }
  }



  //realizando busca pelo filtro individual
  const handleSearchIndividualFilter = async (currentPage,currentPageSize)=>{
    try {
      const props = {
        status: handleGeneratePayloadStatus(),
        dtEventBegin: selectedInitialDate,
        dtEventEnd: selectedEndDate,
        initialHour: selectedInitialHour || '00:00:01',
        endHour: selectedEndHour || '23:59:59',
        identifier: identificador,
        integrationId: integracao,
        clusterId: clusterId,
        page: !isNaN(currentPage) && currentPage != null ? currentPage : page,
        pageSize: currentPageSize ?? pageSize,
      }
      setLoading(true)
      setIdentifierSelected([])
      setSelected({ 2: true, 5: true })

      let res = await getReprocesamentoList(props)
      const json = await res.json()

      if (res.ok) {
        handleLoadResultsBySearch(json)
      }else{
        handleErrorOnFilter('Erro: Não foi possível exibir a listagem de Reprocessamento')
      }
    } catch (error) {
      console.log(error)
      handleErrorOnFilter('Erro: Não foi possível exibir a listagem de Reprocessamento')
    }
  }

  //realizando busca através do filtro de massa
  const handleSearchByMassFilter = async (currentPage,currentPageSize)=>{
    try {
      const payload = {
        integrationId: integracao,
        status: handleGeneratePayloadStatus(),
        identifiers: handleGeneratePayloadMassFilter(),
        dtEventBegin: selectedInitialDate ? `${selectedInitialDate} ${selectedInitialHour || '00:00:01'}` : null,
        dtEventEnd: selectedEndDate ?  `${selectedEndDate} ${selectedEndHour || '23:59:59'}` : null,
        pageNumber: !isNaN(currentPage) && currentPage != null ? currentPage : page,
        pageSize: currentPageSize ?? pageSize,
      }
      setLoading(true)
      setIdentifierSelected([])
      setSelected({ 2: true, 5: true })

      let res = await handleGetReprocessingByMassFilter(payload)
      const json = await res.json()
      if (res.ok) {
        handleLoadResultsBySearch(json)
      }else{
        handleErrorOnFilter('Erro: Não foi possível exibir a listagem de Reprocessamento')
      }
    } catch (error) {
      handleErrorOnFilter('Erro: Não foi possível exibir a listagem de Reprocessamento')
      console.log(error)
    }
  }

  //carregando os resultados da busca na tela
  const handleLoadResultsBySearch = (json) => {
    try {
      setPagination((page) => ({ ...page, ...json }))
      setPage(json?.pageable?.pageNumber)
      setPageSize(json?.pageable?.pageSize)
      setReprocessamentoList(json.content)
      setCurrentColumns(dynamicColumns())
      setError('')
      setLoading(false)
    } catch (error) {
      console.log(error)

    }
  }

  //tratando erro nas chamadas
  const handleErrorOnFilter = (message)=>{
    setLoading(false)
    setError(message)
  }



  const handleCloseLog = () => {
    setOpenLog(false)
  }

  const changePage = (page) => {
    setPage(page)
    handleSearch(page, null)
  }

  const reproccessList = async () => {
    try {
      setLoading(true)
      let res = await updateListReprocessamento(JSON.stringify(identifierSelected))
      if (res.ok) {
        setError('')
        handleSearch()
      } else {
        setError('Não foi possível fazer o reprocessamento em massa')
      }
    } catch (err) {
      setError('Não foi possível fazer o reprocessamento em massa')
    }
    setLoading(false)
  }

  const changePageSize = (pageSize) => {
    setPageSize(pageSize)
    handleSearch(null, pageSize)
  }

  const exportData = () => {
    setOpenExport(true)
  }



  const dynamicColumns = () => {
    const identifier1Column = selectedIntegration.nameIdentifier1
      ? {
          name: 'identifier',
          header: selectedIntegration.nameIdentifier1,
          defaultFlex: 1,
          minWidth: 290,
          render: ({ data }) => {
            return <span>{data.identifier}</span>
          },
        }
      : null
    const identifier2Column = selectedIntegration.nameIdentifier2
      ? {
          name: 'identifier2',
          header: selectedIntegration.nameIdentifier2,
          defaultFlex: 1,
          minWidth: 180,
          render: ({ data }) => {
            return <span>{data.identifier2}</span>
          },
        }
      : null
    const identifier3Column = selectedIntegration.nameIdentifier3
      ? {
          name: 'identifier3',
          header: selectedIntegration.nameIdentifier3,
          defaultFlex: 1,
          minWidth: 70,
          render: ({ data }) => {
            return <span>{data.identifier3}</span>
          },
        }
      : null
    const identifier4Column = selectedIntegration.nameIdentifier4
      ? {
          name: 'identifier4',
          header: selectedIntegration.nameIdentifier4,
          defaultFlex: 1,
          minWidth: 70,
          render: ({ data }) => {
            return <span>{data.identifier4}</span>
          },
        }
      : null

    let currentColumns = [
      identifier1Column,
      identifier2Column,
      identifier3Column,
      identifier4Column,
    ].filter((i) => i)
    return currentColumns.concat(columns)
  }

  const handleGetMessageLog = async (data)=>{
    try {
      setLoading(true)
      let res = await handleGetLogsMessage(data.id)

      if(res.ok){
        const json = await res.json()
        setRow(data)
        setSelectedLog(json)
        setOpenLog(true)
        setConfirmation(false)
        setLoading(false)
      }else{
        handleErrorOnFilter("Erro: Não foi possível carregar os logs solicitados");
      }
    } catch (error) {
      handleErrorOnFilter("Erro: Não foi possível carregar os logs solicitados");
      console.log(error)
    }

  }

  //buscando os dados completos do payload
  const handleGetPayloadFull = async (data, handleAfterGetPayload)=>{
    try {

      setLoading(true)
      let res = await getPayloadFull(data.id)
      if(res.ok){
        const json = await res.json()
        setRow(json)
        handleAfterGetPayload();
      }else{
        handleErrorOnFilter("Erro: Não foi possível buscar as informações!");
      }
    } catch (error) {
      handleErrorOnFilter("Erro: Não foi possível buscar as informações!");
      console.log(error)
    }
  }

  const handleFinishReprocessing = ()=>{
    setConfirmation(true)
    setOpenConfirmation(false)
    setOpen(false)
    handleSearch()
  }

  //abrindo o modal de reprocessamento de mensagens após buscar o payload completo após clique no botão
  const handleOpenConfirmationReprocessing = ()=>{
      setOpenConfirmation(true)
      // setConfirmation(false)
      setLoading(false)
  }

  //abrindo modal para editar o payload após buscar o payload completo após clique no botão
  const handleOpenEditPayload = ()=>{
      setOpen(true)
      // setConfirmation(false)
      setLoading(false)
  }


  const defaultColumns = [{ name: 'identifier', header: 'Identificador', minWidth: 400 }]

  const columns = [
    { name: 'id', header: 'Id', defaultVisible: false },
    {
      name: 'status',
      header: 'Status',
      minWidth: 150,
      render: (params) => RenameStatus(params?.data?.status),
      onRender: (cellProps, { data }) => {
        cellProps.style.background = CollorStatus(data.status)
      },
    },
    {
      name: 'dtEvent',
      header: 'Data de Evento',
      minWidth: 150,
      render: (params) => moment(params?.data?.dtEvent).format('DD/MM/YYYY H:mm:ss'),
    },
    {
      name: 'dtUpdate',
      header: 'Data de Atualização',
      minWidth: 150,
      render: (params) => {
        if(params?.data?.dtUpdate){
          return  moment(params?.data?.dtUpdate).format('DD/MM/YYYY H:mm:ss')
        }else{
          return (
            <div className='flex  w-full items-center justify-center' >
              <span>  -  </span>
            </div>
          )
        }
      },
    },
    {
      name: 'action',
      header: 'Ação',
      minWidth: 200,
      render: ({ data }) => {
        const openDialog = () => {
          handleGetPayloadFull(data,handleOpenEditPayload)
        }

        const openLog = () => {
          handleGetMessageLog(data)
        }

        const handleOpenConfirmation = () => {
          handleGetPayloadFull(data,handleOpenConfirmationReprocessing)
        }

        return (
          <>
            <CTooltip content="Editar" placement="top">
              <CIcon
                style={{ cursor: 'pointer', marginRight: '20px' }}
                onClick={openDialog}
                size="lg"
                icon={icon.cilPenAlt}
              />
            </CTooltip>
            <CTooltip content="Reprocessar" placement="top">
              <CIcon
                style={{ cursor: 'pointer', marginRight: '20px' }}
                onClick={handleOpenConfirmation}
                size="lg"
                icon={icon.cilLoopCircular}
              />
            </CTooltip>
            <CTooltip content="Logs" placement="top">
              <CIcon
                style={{ cursor: 'pointer', marginRight: '20px' }}
                onClick={openLog}
                size="lg"
                icon={icon.cilNotes}
              />
            </CTooltip>
            {data?.status === 'Erro' && data?.exceptionMessage && (
              <CTooltip content={data?.exceptionMessage} placement="top">
                <CIcon style={{ cursor: 'pointer' }} size="lg" icon={icon.cilBug} />
              </CTooltip>
            )}
          </>
        )
      },
    },
  ]

  const [currentColumns, setCurrentColumns] = React.useState(defaultColumns.concat(columns))


  return (
    <>
      {error && <TopAlertErrorComponent setError={setError} message={error} />}
     <TopAlertWarningComponent visible={loadingExport} setVisible={setLoadingExport} message="Exportação em andamento..." />
     <TopAlertSuccessComponent visible={confirmation} setVisible={setConfirmation} message="Reprocessamento enviado com sucesso!" />
      <CCard className="mb-4">
        <CCardBody>
          <CForm>
            <CRow>
              <FilterReprocessamento
                massFilterList={massFilterList}
                setMassFilterIdentifierList={setMassFilterIdentifierList}
                addMassFilter={() => {
                  setVisibleModalMassFilter(true)
                }}
                handleChangeMassFilter={setMassFilterList}
                setSelectedStatus={setSelectedStatus}
                selectedStatus={selectedStatus}
                selectedInitialDate={selectedInitialDate}
                selectedEndDate={selectedEndDate}
                setSelectedInitialDate={setSelectedInitialDate}
                setSelectedEndDate={setSelectedEndDate}
                selectedInitialHour={selectedInitialHour}
                setSelectedInitialHour={setSelectedInitialHour}
                selectedEndHour={selectedEndHour}
                setSelectedEndHour={setSelectedEndHour}
                clusterId={clusterId}
                setClusterId={setClusterId}
                handleSearch={handleValidateDateFields}
                setIntegracao={setIntegracao}
                integracao={integracao}
                identificador={identificador}
                setIdentificador={setIdentificador}
                setReprocessamentoList={setReprocessamentoList}
                setError={setError}
                setLoading={setLoading}
                loading={loading}
                // setConfirmation={setConfirmation}
                clean={clean}
                exportData={exportData}
                reproccessList={reproccessList}
                identifierSelected={identifierSelected}
                setSelectedIntegration={setSelectedIntegration}
                isEmpty={pagination?.empty}
              />

              <LogComponent
                open={openLog}
                close={handleCloseLog}
                row={row}
                logs={selectedLog}
              />

              <CustomDLQTable
                paginationMode="server"
                selected={selected}
                setSelected={setSelected}
                setIdentifierSelected={setIdentifierSelected}
                changePage={changePage}
                changePageSize={changePageSize}
                id="ID"
                pagination={pagination}
                loading={loading}
                columns={currentColumns}
                rows={reprocessamentoList}
                cellClassName={CellClassName}
              />
              <ModalExportXLSX
                setLoadingExport={setLoadingExport}
                setLoading={setLoading}
                setError={setError}
                open={openExport}
                setOpen={setOpenExport}
                integrationId={integracao}
                integrationName={selectedIntegration?.name}
              />
              <ModalReprocessamentoComponent
                onFinish={handleFinishReprocessing}
                setError={setError}
                open={open}
                close={()=>{
                  setOpen(false)
                }}
                row={row}
              />
              <ConfirmationPopup
                onFinish={handleFinishReprocessing}
                setError={setError}
                message={`Deseja confirmar o reprocessamento para o identificador ${row?.identifier}?`}
                open={openConfirmation}
                close={()=>{
                  setOpenConfirmation(false)
                }}
                row={row}
              />
              <FilterMassModal
                visible={visibleModalMassFilter}
                identifiers={massFilterIdentifierList}
                onConfirm={handleAddDataOnMassFilter}
                onCancel={()=>{
                  setVisibleModalMassFilter(false)
                }}
              />

            </CRow>
          </CForm>
        </CCardBody>
      </CCard>
    </>
  )
}

export default Reprocessamento
