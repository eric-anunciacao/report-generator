import {API} from "src/constants"

const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }

export const getAutoReprocessamentoList = async () => {
  const res = await fetch(`${API}auto-reprocessing-configs`, {
    headers: headers,
  })

  return res
}

export const getAutoReprocessamento = async (id: string) => {
  const res = await fetch(`${API}auto-reprocessing-configs/${id}`, {
    headers: headers,
  })

  return res
}

export const updateAutoReprocessamento = async (id: string, requestData: any) => {
  const requestOptions = {
    method: 'PUT',
    body: requestData,
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  return await fetch(`${API}auto-reprocessing-configs/${id}`, requestOptions)
}

export const saveAutoReprocessamento = async (requestData:any) => {
  const requestOptions = {
    method: 'POST',
    body: requestData,
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  return await fetch(`${API}auto-reprocessing-configs`, requestOptions)
}


//
// export const getIntegrationByClusterList = async (idCluster: string) => {
//   const res = await fetch(`${API}integration-controller/findByClusterId/${idCluster}`, {
//     headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
//   })
//
//   return res
// }
// export const getIntegration = async (id:string) => {
//   const res = await fetch(`${API}integration-controller/${id}`, {
//     headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
//   })
//
//   return res
// }
//
// export const saveIntegration = async (requestData:any) => {
//   const requestOptions = {
//     method: 'POST',
//     body: requestData,
//     headers: new Headers({
//       'Content-Type': 'application/json',
//       Accept: 'application/json',
//     }),
//   }
//   const response = await fetch(`${API}integration-controller`, requestOptions)
//
//   return response
// }
//
// export const deleteIntegration = async (id:string) => {
//   const requestOptions = {
//     method: 'DELETE',
//     headers: new Headers({
//       'Content-Type': 'application/json',
//       Accept: 'application/json',
//     }),
//   }
//   const response = await fetch(`${API}integration-controller/${id}`, requestOptions)
//
//   return response
// }
//
// export const updateIntegration = async (requestData: any) => {
//   const requestOptions = {
//     method: 'PUT',
//     body: requestData,
//     headers: new Headers({
//       'Content-Type': 'application/json',
//       Accept: 'application/json',
//     }),
//   }
//   const response = await fetch(`${API}integration-controller`, requestOptions)
//
//   return response
// }
