import { IAutoReprocessing } from "src/domain/entities/interfaces/IAutoReprocessing"


export const AutoReprocessamentoModel = ():IAutoReprocessing => {
    return {
      integrationId:0,
      integrationName:"",
      retries:0,
      ignoreAfterDays:0,
      ignoreAfterDaysLabel:"",
      strategy:"",
      strategyDescription:"",
      schedule: [],
      minutesToReprocess:0,
      configurationLabel:"",
      active:true
    }
}
