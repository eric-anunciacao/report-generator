import {ITimeInput} from "../../../domain/entities/interfaces/ITimeInput";


export const TimeInputsModel = ():ITimeInput[] => {
    return [{
      label: "Horário 1",
      value: ""
    }]
}
