import CIcon from '@coreui/icons-react';
import {CButton, CCard, CCardBody, CCol, CForm, CFormLabel, CRow, CTooltip} from '@coreui/react';
import React,{useState,useEffect} from 'react';
import { DLQTable } from '../../components';
import { CellClassName } from '../reprocessamento/utils/reprocessamentoUtils';
import * as icon from '@coreui/icons';
import { useNavigate  } from 'react-router-dom';
import { TopAlertErrorComponent, TopAlertSuccessComponent } from '../../utils/alerts';
import { ROUTES } from 'src/constants';
import { IAutoReprocessing } from 'src/domain/entities/interfaces/IAutoReprocessing';
import { AutoReprocessamentoModel } from '../autoreprocessamento/model/AutoReprocessamentoModel';
import { getAutoReprocessamentoList } from "./hooks/autoreprocessamento";
import {TextField, Typography} from "@mui/material";
import {Label} from "@mui/icons-material";

const AutoReprocessingList = () => {

    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);
    const [autoReprocessamentoList, setAutoReprocessamentoList] = useState([]);

    const [row, setRow] = useState<IAutoReprocessing>(AutoReprocessamentoModel);

    const [error, setError] = useState('');

    const addAutoReprocessamento=(): void =>{
        navigate(ROUTES.NEW_AUTOREPROCESSING);
    }

    const handleSearch = async (): Promise<void> => {
        try {
          setLoading(true);
          let res = await getAutoReprocessamentoList();
          const json = await res.json();

          if(res.ok){
            setAutoReprocessamentoList(json);
            setError('');
          }else{
            setError('Erro: Não foi possível exibir a listagem de reprocessamento automático')
          }
        } catch (e) {
          setError('Erro: Não foi possível exibir a listagem de reprocessamento automático');
         }

         setLoading(false);
      }

      useEffect(() => {
        handleSearch();
      }, []);

    const columns = [
      { field: "id", hide: true },
      { field: "integrationName", headerName: 'Integração', width: 320 },
      { field: "retries", headerName: 'Retentativas', width: 100 },
      { field: "ignoreAfterDaysLabel", headerName: 'Ignorar após', width: 120 },
      { field: "configurationLabel", headerName: 'Configuração', width: 300, renderCell: (params:any) => {
          return (
            <>
              <Typography style={{ whiteSpace: "pre-line" }}>
                {params.row.configurationLabel}
              </Typography>
            </>
          )
        } },
      { field: "Status", headerName: 'Status', width: 150,renderCell: (params:any) => params.row?.active ? "Ativo" : "Inativo" },
      { field: 'action', headerName: 'Ação', width: 100, renderCell: (params:any) => {
            const editPage=() : void=>{
                navigate(ROUTES.UPDATE_AUTOREPROCESSING,{state:{id: params.row.id}});
            }

            return (
            <>
                <CTooltip content="Editar" placement="top">
                    <CIcon onClick={editPage} style={{ cursor: 'pointer', marginRight: '20px' }} size='lg' icon={icon.cilPenAlt} />
                </CTooltip>
            </>
            )
        } },
    ];


    return (<>

        { error && <TopAlertErrorComponent setError={setError} message={error} /> }
        <CCard className="mb-4">
          <CCardBody>
            <CForm>
              <CRow>
                <CCol>
                  <h5>Configurações de Reprocessamento Automático</h5>
                </CCol>
                <CCol xs  style={{textAlignLast: 'right'}}>
                    <CButton onClick={addAutoReprocessamento} color="dark" style={{textAlignLast: 'center'}} >
                        Adicionar <CIcon style={{ cursor: 'pointer' }} size='lg' icon={icon.cilPlus} />
                    </CButton>
                </CCol>
                <DLQTable pagination="false" loading={loading} columns={columns} rows={autoReprocessamentoList} cellClassName={CellClassName}></DLQTable>
              </CRow>
            </CForm>
            </CCardBody>
        </CCard>
    </>);
}

export default AutoReprocessingList;
