import {useLocation, useNavigate} from "react-router-dom";
import React, {useEffect, useState} from "react";
import {IAutoReprocessing} from "../../domain/entities/interfaces/IAutoReprocessing";
import {AutoReprocessamentoModel} from "./model/AutoReprocessamentoModel";
import {IIntegrationShortened} from "../../domain/entities/interfaces/IIntegrationShortened";
import {
  getIntegrationList,
} from "../reprocessamento/hooks/integration";
import {getAutoReprocessamento, saveAutoReprocessamento, updateAutoReprocessamento} from "./hooks/autoreprocessamento";
import {TopAlertErrorComponent} from "../../utils/alerts";
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CFormCheck,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CFormSwitch,
  CRow
} from "@coreui/react";
import CIcon from "@coreui/icons-react";
import * as icon from "@coreui/icons";
import {ITimeInput} from "../../domain/entities/interfaces/ITimeInput";
import {TimeInputsModel} from "./model/TimeInputsModel";
import {boolean} from "@inovua/reactdatagrid-community/filterTypes";
import AsyncSelect from "react-select/async";


const AutoReprocessamentoPage = () => {

  const navigate = useNavigate();

  const location = useLocation();
  const id = location?.state?.id;
  const [error, setError] = useState('');
  const [strategy, setStrategy] = useState("AFTER_MINUTES");
  const [autoReprocessing, setAutoReprocessing] = useState<IAutoReprocessing>(AutoReprocessamentoModel);
  const [integrationList, setIntegrationList] = useState<IIntegrationShortened[]>([]);
  const [inputs, setInputs] = useState<ITimeInput[]>(TimeInputsModel);

  const handleChange = (event: any) => {
    var {name, value, checked} = event.target;

    if (name === 'integration') {
      name = 'integrationId';
    }

    if (name === 'active') {
      value = checked;
    }

    setAutoReprocessing(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleBack = () => {
    navigate(-1);
  }

  const fetchIntegrations = async () => {
    try {
      let res = await getIntegrationList();
      const json = await res.json();

      if (res.ok) {
        setIntegrationList(json);
        setError('');
      } else {
        setError('Erro: Não foi possível exibir a listagem de integrações')
      }
    } catch (e) {
      setError('Erro: Não foi possível exibir a listagem de integrações');
    }
  }

  const fetchAutoReprocessing = async () => {
    try {
      let res = await getAutoReprocessamento(id);
      const json = await res.json();
      if (res.ok) {
        var newInputs: ITimeInput[] = []

        json.schedule?.forEach((item: string, index: number) => {
          newInputs.push({label: 'Horário ' + ++index, value: item});
        })

        setAutoReprocessing(json);
        setInputs(newInputs);
        setError('');
      } else {
        setError('Erro: Não foi possível recuperar a integração')
      }
    } catch (e) {
      setError('Erro: Não foi possível recuperar a integração');
    }
  };

  useEffect(() => {
    if (id) {
      fetchAutoReprocessing();
      return;
    }

    fetchIntegrations();
  }, []);

  const handleSend = async () => {
    if (!validateForm())
      return;

    try {
      var res;
      if (id) {
        res = await updateAutoReprocessamento(id, JSON.stringify(autoReprocessing));
      } else {
        res = await saveAutoReprocessamento(JSON.stringify(autoReprocessing));
      }
      if (res.ok) {
        setError('');
        handleBack();
      } else {
        if (res.status === 409) {
          setError('Erro: configuração já existe. Por favor editar')
        } else {
          setError('Erro: Não foi possível enviar');
        }
      }
    } catch (e) {
      setError('Erro: Não foi possível enviar');
    }
  };

  const requiredFields = (): string => {
    if (!autoReprocessing.active) {
      return '';
    }

    var errorNames = '';
    if (!autoReprocessing.retries) {
      errorNames += 'Retentativas, ';
    }
    if (!autoReprocessing.ignoreAfterDays) {
      errorNames += 'Ignorar após, ';
    }

    if (autoReprocessing.strategy == "AFTER_MINUTES") {
      if (autoReprocessing.minutesToReprocess == 0) {
        errorNames += 'Minutos para reprocessar, ';
      }
    } else if (autoReprocessing.strategy == "FIXED_SCHEDULE") {
      if (inputs.length == 0) {
        errorNames += 'Horários, ';
      }
    }

    return errorNames;
  }

  function hasDuplicates(arr: string[]) {
    return arr.filter((item, index) => arr.indexOf(item) !== index)
      .length > 0;
  }

  const validateForm = () => {
    const required = requiredFields();

    if (required) {
      setError('Campo(s) obrigatório(s): ' + required);
      return false;
    }

    let hasDuplicateValues = hasDuplicates(inputs.map(i => i.value));

    if (autoReprocessing.strategy == "FIXED_SCHEDULE" && hasDuplicateValues) {
      setError("Erro: existem horários repetidos");
      return false;
    }

    if (!autoReprocessing.integrationId) {
      setError("Erro: é necessário selecionar a integração");
      return false;
    }

    return true;
  }

  const handleInputChange = (index: number, value: string) => {
    const newInputs = [...inputs];
    newInputs[index].value = value;
    setInputs(newInputs);

    setAutoReprocessing(prevState => ({
      ...prevState,
      schedule: newInputs.map(i => i.value)
    }));

  };

  const handleAddInput = () => {
    setInputs([...inputs, {label: `Horário ${inputs.length + 1}`, value: ''}]);
  };

  const handleRemoveInput = (index: number) => {
    const newInputs = [...inputs];
    newInputs.splice(index, 1);
    setInputs(newInputs);

    setAutoReprocessing(prevState => ({
      ...prevState,
      schedule: newInputs.map(i => i.value)
    }));
  }

  const handleStrategy = (strategy: string) => {
    setStrategy(strategy);
    setAutoReprocessing((prevState) => {
      return {
        ...prevState,
        strategy: strategy
      }
    })
  }

  return (<>
    {error && <TopAlertErrorComponent message={error} setError={setError}/>}

    <CCard className="mb-4">
      <CCardBody>

        <CCol>
          <div style={{paddingBottom: '15px'}}>
            <h4>Reprocessamento automático - { id ? autoReprocessing.integrationName : "novo" }</h4>
          </div>
        </CCol>

        <CCol hidden={id}>
          <CRow>
            <CCol md={3} style={{padding: '15px'}}>
              <div className="mb-3">
                <CFormLabel>Integração</CFormLabel>
                <CFormSelect name="integration"
                             onChange={handleChange} value={autoReprocessing.integrationId} >
                  <option value="">Selecione</option>
                  {
                    integrationList?.map( (x,y) =>
                      <option key={y} value={x?.id}> {x?.name}</option> )
                  }
                </CFormSelect>

              </div>
            </CCol>
          </CRow>
        </CCol>

        <CCol>
          <div style={{paddingBottom: '15px'}}>
            <h5><CFormSwitch size="xl" name="active"
                             label="Ativar reprocessamento automático de mensagens com erro"
                             checked={autoReprocessing.active} onChange={handleChange}></CFormSwitch></h5>
          </div>
        </CCol>
        <CRow>
          <CCol lg={3} md={4} sm={12} style={{padding: '15px'}}>
            <div style={{display: "flex", flexDirection: "row"}}>
              <CFormCheck type="radio" radioGroup="strategy" id="afterMinutesStrategy" name="afterMinutesStrategy"
                          key="afterMinutesStrategy" label="Reprocessar em"
                          checked={autoReprocessing.strategy === "AFTER_MINUTES"}
                          onChange={() => handleStrategy("AFTER_MINUTES")}>
              </CFormCheck>

              <div style={{display: "inline-flex"}}>
                <div style={{marginTop: -6, marginLeft: 5}}>
                  <CFormInput type="number" width="80" min="10" max="1000" step="10" onKeyUp={handleChange} name="minutesToReprocess"
                              value={autoReprocessing.minutesToReprocess} onChange={handleChange}></CFormInput>
                </div>
                <label style={{marginLeft: '5px'}}>minutos</label>
              </div>
            </div>

          </CCol>
        </CRow>
        <CRow>
          <CCol lg={3} md={4} sm={12} style={{padding: '15px'}}>
            <div className="mb-1">
              <CFormCheck type="radio" radioGroup="strategy" id="fixedTimeStrategy" name="fixedTimeStrategy"
                          key="fixedTimeStrategy" label="Reprocessar em horários fixos"
                          checked={autoReprocessing.strategy === "FIXED_SCHEDULE"}
                          onChange={() => handleStrategy("FIXED_SCHEDULE")}>
              </CFormCheck>
            </div>
          </CCol>
        </CRow>

        <div id="fixed-time" style={{display: autoReprocessing.strategy !== "FIXED_SCHEDULE" ? "none" : "block"}}>

          {inputs.map((input, index) => (
            <CRow key={index}>
              <CCol lg={2} md={3} sm={12}>
                <CFormLabel>{input.label}</CFormLabel>

                <div style={{display: "flex", flexDirection: "row"}}>
                  <CFormInput
                    type="time"
                    value={input.value}
                    onChange={(e) => handleInputChange(index, e.target.value)}
                  />
                  <CButton color="light" type="button" onClick={() => handleRemoveInput(index)}
                           style={{marginLeft: '5px'}} disabled={index === 0}>
                    <CIcon style={{cursor: 'pointer', marginTop: '5px'}}
                           size="lg"
                           icon={icon.cilTrash}/>
                  </CButton>
                </div>
              </CCol>
            </CRow>
          ))}

          <CButton color="dark" type="button" onClick={handleAddInput} style={{marginTop: '10px'}}>
            <CIcon style={{cursor: 'pointer', marginTop: '5px'}}
                   size="lg"
                   icon={icon.cilPlus}/>
          </CButton>
        </div>

        <CRow>
          <CCol lg={3} md={4} sm={12} style={{padding: '15px'}}>
            <div style={{display: "flex", flexDirection: "row"}}>

              <div style={{display: "inline-flex"}}>
                <label>Quantidade máxima de retentativas: </label>
                <div style={{marginTop: -6, marginLeft: 5}}>
                  <CFormInput type="number" width="80" min="1" max="100" onKeyUp={handleChange} name="retries"
                              value={autoReprocessing.retries} onChange={handleChange}></CFormInput>
                </div>
              </div>
            </div>

          </CCol>
        </CRow>
        <CRow>
          <CCol lg={3} md={4} sm={12} style={{padding: '15px'}}>
            <div style={{display: "flex", flexDirection: "row"}}>

              <div style={{display: "inline-flex"}}>
                <label>Ignorar após: </label>
                <div style={{marginTop: -6, marginLeft: 5}}>
                  <CFormInput type="number" width="80" min="1" max="7" onKeyUp={handleChange} name="ignoreAfterDays"
                              value={autoReprocessing.ignoreAfterDays} onChange={handleChange}></CFormInput>

                </div>
                <label style={{marginLeft: 5}}>dias</label>
              </div>
            </div>

          </CCol>
        </CRow>
        <CRow>
          <CCol xs style={{textAlignLast: 'right'}}>
            <CButton color="light" onClick={handleBack}
                     style={{textAlignLast: 'center', width: '100px', marginRight: '15px'}}>Cancelar</CButton>
            <CButton color="dark" onClick={handleSend} style={{textAlignLast: 'center', width: '85px'}}>Enviar</CButton>
          </CCol>
        </CRow>
      </CCardBody>
    </CCard>

  </>)
}

export default AutoReprocessamentoPage;
