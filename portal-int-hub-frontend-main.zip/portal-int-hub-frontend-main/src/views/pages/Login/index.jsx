import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { CButton, CForm, CFormInput, CInputGroup, CInputGroupText } from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilLockLocked, cilUser, cibGoogle } from '@coreui/icons'
import logo from '../../../assets/images/cia-hering-logo.png'
import { UserModel } from './Model'

const Login = () => {
  const [user, setUser] = useState(UserModel)
  const navigate = useNavigate()

  const handleUpdateUser = (field, value) => {
    setUser((prevState) => {
      return { ...prevState, [field]: value }
    })
  }

  const handleNavigateHome = () => {
    try {
      navigate('/Home')
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div className="bg-background-color flex-col lg:flex-row flex w-full h-screen  items-center gap-6 lg:gap-0">
      <header className="w-full lg:w-1/2 bg-primary-color h-1/4 lg:h-full items-center justify-center flex p-6 flex-col gap-2">
        <img src={logo} className="h-18 w-96" />
        <h3 className="text-primary-ligth text-2xl font-medium">Integration Hub</h3>
      </header>
      <main className="w-full lg:w-1/2 flex items-center justify-center ">
        <form className="bg-white w-11/12 max-w-[23.75rem] rounded-md shadow p-4">
          <p className="text-primary-color text-lg font-semibold">Login</p>
          <CForm>
            <p className="text-medium-emphasis">Entre com seu usuário e senha</p>
            <CInputGroup className="mb-3">
              <CInputGroupText>
                <CIcon icon={cilUser} />
              </CInputGroupText>
              <CFormInput
                placeholder="Usuário"
                autoComplete="username"
                value={user.user}
                onChange={(e) => {
                  handleUpdateUser('user', e.target.value)
                }}
              />
            </CInputGroup>
            <CInputGroup className="mb-4">
              <CInputGroupText>
                <CIcon icon={cilLockLocked} />
              </CInputGroupText>
              <CFormInput
                type="password"
                placeholder="Senha"
                autoComplete="current-password"
                value={user.password}
                onChange={(e) => {
                  handleUpdateUser('password', e.target.value)
                }}
              />
            </CInputGroup>
            <div className="w-full">
              <CButton
                className="w-full"
                onClick={handleNavigateHome}
                disabled={!(user?.user && user?.password)}
                style={{ backgroundColor: '#303C54', border: 'none' }}
              >
                Login
              </CButton>
            </div>
          </CForm>
          <div className="flex flex-row w-full gap-2 items-center mt-2">
            <hr className="border w-full bg-black h-1" />
            <p>ou</p>
            <hr className="border w-full bg-black h-1" />
          </div>
          <button
            onClick={() => {}}
            type="button"
            className="w-full rounded-md flex flex-row justify-center  items-center border h-9 cursor-pointer gap-3"
          >
            <CIcon icon={cibGoogle} />
            <p className="text-black  m-0">Entrar com o Google</p>
          </button>
        </form>
      </main>
    </div>
  )
}

export default Login
