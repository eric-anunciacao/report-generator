import  IUser  from "src/domain/entities/interfaces/IUser"

export const UserModel = () : IUser => {

    return {
        username: "",
        password: ""
      }
}