
import React,{useState,useEffect} from 'react';
import { CButton, CCard, CCardBody, CCol, CFormInput, CFormLabel, CRow } from '@coreui/react';
import {useLocation, useNavigate} from 'react-router-dom';
import { TopAlertErrorComponent }  from '../../utils/alerts';
import { getCluster, saveCluster, updateCluster } from './hooks/cluster';
import { ClusterModel } from './model/ClusterModel';
import { ICluster } from 'src/domain/entities/interfaces/ICluster';

const ClusterPage = () => {

    const navigate = useNavigate();

    const location = useLocation();
    const id = location?.state?.id;

    const [error, setError] = useState('');
    const [cluster, setCluster] = useState<ICluster>(ClusterModel);

    const handleChange = (event:any) => {
        const { name, value } = event.target;
        setCluster(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleBack = () => {
        navigate(-1);
    }

    const fetchCluster = async () => {
        try {
          let res = await getCluster(id);
          const json = await res.json();

          if(res.ok){
            setCluster(json);
            setError('');
          }else{
            setError('Erro: Não foi possível exibir a listagem do Cluster')
          }
        } catch (e) {
          setError('Erro: Não foi possível exibir a listagem do Cluster');
         }

      }

    useEffect(() => {
        if(id){
            fetchCluster();
        }
    }, []);

    const handleSend = async () => {
        try{
            var res;
            if(id) {
                res = await updateCluster(cluster);
            } else {
                res = await saveCluster(cluster);
            }
            if(res.ok){
                setError('');
                handleBack();
            }else{
                setError('Erro: Não foi possível enviar');
            }
        }catch(e){
            setError('Erro: Não foi possível enviar');
        }
       };

    return (<>
        { error && <TopAlertErrorComponent message={error} setError={setError} /> }
        <CCard className="mb-4">
            <CCardBody>
                    <CCol>
                        <div style={{paddingBottom: '15px'}}>
                            <h5>{ !id ? 'Cadastro de' : 'Editar' } Cluster</h5>
                        </div>
                    </CCol>
                    <CRow>
                      <CCol md={3} style={{padding: '15px'}}>
                        <div className="mb-3">
                          <CFormLabel>Nome</CFormLabel>
                          <CFormInput name="name" defaultValue={cluster.name} type="text" onChange={handleChange}/>
                        </div>
                        <div className="mb-3">
                          <CFormLabel>Servidores</CFormLabel>
                          <CFormInput name="servers" defaultValue={cluster.servers} type="text" onChange={handleChange}/>
                        </div>
                      </CCol>
                    </CRow>
              <CRow>
                <CCol xs style={{textAlignLast: 'right'}}>
                  <CButton color="light" onClick={handleBack}
                           style={{textAlignLast: 'center', width: '100px', marginRight: '15px'}} >Cancelar</CButton>
                            <CButton  color="dark" onClick={handleSend} style={{textAlignLast: 'center', width: '85px'}} >Enviar</CButton>
                        </CCol>
                    </CRow>
            </CCardBody>
        </CCard>
    </>)

}

export default ClusterPage;
