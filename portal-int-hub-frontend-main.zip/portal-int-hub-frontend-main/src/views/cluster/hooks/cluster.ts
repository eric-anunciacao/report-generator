import { API } from "src/constants"
import { ICluster } from "src/domain/entities/interfaces/ICluster"

export const getClusterList = async (): Promise<Response> => {
  const res = await fetch(`${API}cluster-controller`, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}

export const getCluster = async (id:string): Promise<Response> => {
  const res = await fetch(`${API}cluster-controller/${id}`, {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
  })

  return res
}

export const saveCluster = async (requestData:ICluster): Promise<Response> => {
  const requestOptions = {
    method: 'POST',
    body: JSON.stringify(requestData),
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}cluster-controller`, requestOptions)

  return response
}

export const deleteCluster = async (id:string) : Promise<Response>=> {
  const requestOptions = {
    method: 'DELETE',
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}cluster-controller/${id}`, requestOptions)

  return response
}

export const updateCluster = async (requestData:ICluster): Promise<Response> => {
  const requestOptions = {
    method: 'PUT',
    body: JSON.stringify(requestData),
    headers: new Headers({
      'Content-Type': 'application/json',
      Accept: 'application/json',
    }),
  }
  const response = await fetch(`${API}cluster-controller`, requestOptions)

  return response
}
