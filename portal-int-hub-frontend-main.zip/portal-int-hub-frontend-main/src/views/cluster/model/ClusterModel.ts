import { ICluster } from "src/domain/entities/interfaces/ICluster"

export const ClusterModel = (): ICluster => {

    return {
        id: "",
        name: "",
        servers: ""
      }
}
