import CIcon from '@coreui/icons-react'
import { CButton, CCard, CCardBody, CCol, CForm, CRow, CTooltip } from '@coreui/react'
import React,{useEffect,useState} from 'react'
import { DLQTable } from '../../components'
import { CellClassName } from '../reprocessamento/utils/reprocessamentoUtils'
import { getClusterList } from './hooks/cluster'
import * as icon from '@coreui/icons'
import { useNavigate } from 'react-router-dom'
import { TopAlertErrorComponent, TopAlertSuccessComponent } from '../../utils/alerts'
import { ConfirmationPopup } from './modal/confirmation'
import { ROUTES } from 'src/constants'
import { ICluster } from 'src/domain/entities/interfaces/ICluster'

const ClusterList = () => {
  const navigate = useNavigate()

  const [loading, setLoading] = useState(false)
  const [clusterList, setClusterList] = useState([])

  const [confirmation, setConfirmation] = useState(false)

  const [openConfirmation, setOpenConfirmation] = useState(false)
  const [row, setRow] = useState<ICluster>()

  const [error, setError] = useState('')

  const addCluster = () => {
    navigate(ROUTES.NEW_CLUSTER)
  }

  const handleSearch = async () => {
    try {
      setLoading(true)
      let res = await getClusterList()
      const json = await res.json()

      if (res.ok) {
        setClusterList(json)
        setError('')
      } else {
        setError('Erro: Não foi possível exibir a listagem do Cluster')
      }
    } catch (e) {
      setError('Erro: Não foi possível exibir a listagem do Cluster')
    }

    setLoading(false)
  }

  useEffect(() => {
    handleSearch()
  }, [])

  const handleCloseConfirmation = () => {
    setOpenConfirmation(false)
    if (confirmation) {
      handleSearch()
    }
  }

  const columns = [
    { field: 'id', headerName: 'Id', width: 100 },
    { field: 'name', headerName: 'Nome', width: 200 },
    { field: 'servers', headerName: 'Servidores', width: 300 },
    {
      field: 'action',
      headerName: 'Ação',
      width: 200,
      renderCell: (params:any) => {
        const editPage = () => {
          navigate(ROUTES.UPDATE_CLUSTER, { state: { id: params.row.id } })
        }

        const handleOpenConfirmation = () => {
          setRow(params.row)
          setOpenConfirmation(true)
          setConfirmation(false)
        }

        return (
          <>
            <CTooltip content="Editar" placement="top">
              <CIcon
                onClick={editPage}
                style={{ cursor: 'pointer', marginRight: '20px' }}
                size="lg"
                icon={icon.cilPenAlt}
              />
            </CTooltip>
            <CTooltip content="Deletar" placement="top">
              <CIcon
                onClick={handleOpenConfirmation}
                style={{ cursor: 'pointer', marginRight: '20px' }}
                size="lg"
                icon={icon.cilX}
              />
            </CTooltip>
          </>
        )
      },
    },
  ]



  return (
    <>
      {error && <TopAlertErrorComponent setError={setError} message={error} />}
      <TopAlertSuccessComponent visible={confirmation} setVisible={setConfirmation} message="Cluster deletado com sucesso!" />
      <CCard className="mb-4">
        <CCardBody>
          <CForm>
            <CRow>
              <CCol>
                <h5>Lista de Clusters</h5>
              </CCol>
              <CCol xs style={{ textAlignLast: 'right' }}>
                <CButton onClick={addCluster} color="dark" style={{ textAlignLast: 'center' }}>
                  Adicionar <CIcon style={{ cursor: 'pointer' }} size="lg" icon={icon.cilPlus} />
                </CButton>
              </CCol>
              <DLQTable
                paginationMode="mock"
                loading={loading}
                columns={columns}
                rows={clusterList}
                cellClassName={CellClassName}
              ></DLQTable>
              <ConfirmationPopup
                setConfirmation={setConfirmation}
                setError={setError}
                message={`Deseja confirmar a deleção para o cluster ${row?.name}?`}
                open={openConfirmation}
                close={handleCloseConfirmation}
                row={row}
              />
            </CRow>
          </CForm>
        </CCardBody>
      </CCard>
    </>
  )
}

export default ClusterList
