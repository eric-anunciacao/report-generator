import CIcon from '@coreui/icons-react';
import { CButton, CCard, CCardBody, CCol, CForm, CRow, CTooltip } from '@coreui/react';
import React,{useState,useEffect} from 'react';
import { DLQTable } from '../../components';
import { CellClassName } from '../reprocessamento/utils/reprocessamentoUtils';
import * as icon from '@coreui/icons';
import { useNavigate  } from 'react-router-dom';
import { TopAlertErrorComponent, TopAlertSuccessComponent } from '../../utils/alerts';
import { getIntegrationList } from '../reprocessamento/hooks/integration';
import { ConfirmationPopup } from './modal/confirmation';
import { ROUTES } from 'src/constants';
import { IIntegration } from 'src/domain/entities/interfaces/IIntegration';
import { IntegracaoModel } from './model/IntegracaoModel';

const IntegracaoList = () => {

    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);
    const [integrationList, setIntegrationList] = useState([]);
    const [clusterList, setClusterList] = useState([]);

    const [confirmation, setConfirmation] = useState(false);

    const [openConfirmation, setOpenConfirmation] = useState(false);
    const [row, setRow] = useState<IIntegration>(IntegracaoModel);

    const [error, setError] = useState('');

    const addIntegration=(): void =>{
        navigate(ROUTES.NEW_INTEGRATION);
    }

    const handleSearch = async (): Promise<void> => {
        try {
          setLoading(true);
          let res = await getIntegrationList();
          const json = await res.json();

          if(res.ok){
            setIntegrationList(json);
            setError('');
          }else{
            setError('Erro: Não foi possível exibir a listagem do Cluster')
          }
        } catch (e) {
          setError('Erro: Não foi possível exibir a listagem do Cluster');
         }

         setLoading(false);
      }

      useEffect(() => {
        handleSearch();
      }, []);

      const handleCloseConfirmation = (): void => {
        setOpenConfirmation(false);
        if(confirmation){
          handleSearch();
        }
      };

    const columns = [
      { field: "id", hide: true },
      { field: "name", headerName: 'Nome', width: 320 },
      { field: "cluster", headerName: 'Cluster', width: 150, renderCell: (params:any) => params.row?.cluster?.name },
      { field: "identifier1", headerName: 'Identificador 1', width: 150 },
      { field: "identifier2", headerName: 'Identificador 2', width: 150 },
      { field: "identifier3", headerName: 'Identificador 3', width: 150 },
      { field: "identifier4", headerName: 'Identificador 4', width: 150 },
      { field: "Status", headerName: 'Status', width: 150,renderCell: (params:any) => params.row?.active ? "Ativa" : "Inativa" },
      { field: 'action', headerName: 'Ação', width: 100, renderCell: (params:any) => {

            const editPage=() : void=>{
                navigate(ROUTES.UPDATE_INTEGRATION,{state:{id: params.row.id}});
            }

            const handleOpenConfirmation = (): void=> {
                setRow(params.row);
                setOpenConfirmation(true);
                setConfirmation(false);
              };

            return (
            <>
                <CTooltip content="Editar" placement="top">
                    <CIcon onClick={editPage} style={{ cursor: 'pointer', marginRight: '20px' }} size='lg' icon={icon.cilPenAlt} />
                </CTooltip>
                {
                  params.row?.active &&
                  <CTooltip content="Desativar" placement="top">
                      <CIcon onClick={handleOpenConfirmation} style={{ cursor: 'pointer', marginRight: '20px' }}  size='lg' icon={icon.cilX} />
                  </CTooltip>
                }
            </>
            )
        } },
    ];


    return (<>

        { error && <TopAlertErrorComponent setError={setError} message={error} /> }
        <TopAlertSuccessComponent visible={confirmation} setVisible={setConfirmation} message="Integração deletada com sucesso!" />
        <CCard className="mb-4">
          <CCardBody>
            <CForm>
              <CRow>
                <CCol>
                  <h5>Lista de Integrações</h5>
                </CCol>
                <CCol xs  style={{textAlignLast: 'right'}}>
                    <CButton onClick={addIntegration} color="dark" style={{textAlignLast: 'center'}} >
                        Adicionar <CIcon style={{ cursor: 'pointer' }} size='lg' icon={icon.cilPlus} />
                    </CButton>
                </CCol>
                <DLQTable paginationMode='mock' loading={loading} columns={columns} rows={integrationList} cellClassName={CellClassName}></DLQTable>
                <ConfirmationPopup setConfirmation={setConfirmation} setError={setError} message={`Deseja realmente desativar a Integração ${row?.name}?`} open={openConfirmation} close={handleCloseConfirmation} row={row} />
              </CRow>
            </CForm>
            </CCardBody>
        </CCard>
    </>);
}

export default IntegracaoList;
