
import React,{useState,useEffect} from 'react';
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CFormCheck,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CFormSwitch,
  CRow
} from '@coreui/react';
import {useLocation, useNavigate} from 'react-router-dom';
import { TopAlertErrorComponent } from '../../utils/alerts';
import { IntegracaoModel } from './model/IntegracaoModel';
import { getIntegration, saveIntegration, updateIntegration } from '../reprocessamento/hooks/integration';
import { getClusterList } from '../cluster/hooks/cluster';
import { ICluster } from "src/domain/entities/interfaces/ICluster"
import { IIntegration } from 'src/domain/entities/interfaces/IIntegration';
import CIcon from "@coreui/icons-react";
import * as icon from "@coreui/icons";

const IntegracaoPage = () => {

  const navigate = useNavigate();

  const location = useLocation();
  const id = location?.state?.id;

  const [error, setError] = useState('');
  const [integracao, setIntegracao] = useState<IIntegration>(IntegracaoModel);
  const [clusterList, setClusterList] = useState<ICluster[]>([]);

  const handleChange = (event:any) => {

    var { name, value } = event.target;

    if(name === 'cluster'){
      value = clusterList?.find( cluster => cluster.id == value );
    }


    setIntegracao(prevState => ({
      ...prevState,
      [name]: value
    }));
  };



  const handleActiveIntegration = (activation:boolean)=>{
    setIntegracao((prevState)=>{
      return{
        ...prevState,
        active:activation
      }
    })
  }

  const handleBack = () => {
    navigate(-1);
  }

  const requiredFields = () : string=> {
    var errorNames = '';

    if(!integracao.name){
      errorNames += 'Nome, ';
    }
    if(!integracao.cluster?.id){
      errorNames += 'Cluster, ';
    }
    if(!integracao.correlationId){
      errorNames += 'Chave Única, ';
    }
    if(!integracao.identifier1){
      errorNames += 'Identificador 1, ';
    }
    if(!integracao.nameIdentifier1){
      errorNames += 'Nome Identificador 1, ';
    }
    if(integracao.identifier2 && !integracao.nameIdentifier2){
      errorNames += 'Nome Identificador 2, ';
    }
    if(integracao.identifier3 && !integracao.nameIdentifier3){
      errorNames += 'Nome Identificador 3, ';
    }
    if(integracao.identifier4 && !integracao.nameIdentifier4){
      errorNames += 'Nome Identificador 4, ';
    }
    if(!integracao.dlqTopic){
      errorNames += 'Tópico DLQ, ';
    }
    if(!integracao.reprocessTopic){
      errorNames += 'Tópico de Reprocessamento, ';
    }
    return errorNames;
  }

  const fetchCluster = async () => {
    try {
      let res = await getClusterList();
      const json = await res.json();

      if(res.ok){
        setClusterList(json);
        setError('');
      }else{
        setError('Erro: Não foi possível exibir a listagem do Cluster')
      }
    } catch (e) {
      setError('Erro: Não foi possível exibir a listagem do Cluster');
    }

  }

  const fetchIntegration = async () => {
    try {
      let res = await getIntegration(id);
      const json = await res.json();

      if(res.ok){
        setIntegracao(json);
        setError('');
      }else{
        setError('Erro: Não foi possível recuperar a integração')
      }
    } catch (e) {
      setError('Erro: Não foi possível recuperar a integração');
    }

  }

  useEffect(() => {
    if(id){
      fetchIntegration();
    }
    fetchCluster();
  }, []);

  const handleSend = async () => {

    if(requiredFields()){
      setError('Campo(s) obrigatório(s): ' + requiredFields());
      return;
    }

    try{
      var res;
      if(id) {
        res = await updateIntegration(JSON.stringify(integracao));
      } else {
        res = await saveIntegration(JSON.stringify(integracao));
      }
      if(res.ok){
        setError('');
        handleBack();
      }else{
        setError('Erro: Não foi possível enviar');
      }
    }catch(e){
      setError('Erro: Não foi possível enviar');
    }
  };



  return (<>
    { error && <TopAlertErrorComponent message={error} setError={setError} /> }
    <CCard className="mb-4">
      <CCardBody>
        <CCol>
          <div style={{paddingBottom: '15px'}}>
            <h5>{ !id ? 'Cadastro de' : 'Editar' } Integração</h5>
          </div>
        </CCol>
        <CRow>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Cluster</CFormLabel>
              <CFormSelect name="cluster"
                           onChange={handleChange} value={integracao?.cluster?.id} >
                <option value="">Selecione</option>
                {
                  clusterList?.map( (x,y) =>
                    <option key={y} value={x?.id}> {x?.name}</option> )
                }
              </CFormSelect>
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Nome</CFormLabel>
              <CFormInput name="name" defaultValue={integracao.name} type="text" onKeyUp={handleChange} onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Chave Única</CFormLabel>
              <CFormInput name="correlationId" defaultValue={integracao.correlationId} onKeyUp={handleChange} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Ativado</CFormLabel>
              <CFormCheck type="radio" name="active" checked={integracao.active} onChange={()=>{handleActiveIntegration(true)}} label="Sim"/>
              <CFormCheck type="radio" name="active" checked={!integracao.active} onChange={()=>{handleActiveIntegration(false)}} label="Não"/>
            </div>
          </CCol>
        </CRow>
        <CRow>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Identificador 1</CFormLabel>
              <CFormInput name="identifier1" onKeyUp={handleChange} defaultValue={integracao.identifier1} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Identificador 2</CFormLabel>
              <CFormInput name="identifier2" onKeyUp={handleChange} defaultValue={integracao.identifier2} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Identificador 3</CFormLabel>
              <CFormInput name="identifier3" onKeyUp={handleChange} defaultValue={integracao.identifier3} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Identificador 4</CFormLabel>
              <CFormInput name="identifier4" onKeyUp={handleChange} defaultValue={integracao.identifier4} type="text" onChange={handleChange} />
            </div>
          </CCol>
        </CRow>
        <CRow>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Nome Identificador 1</CFormLabel>
              <CFormInput name="nameIdentifier1" onKeyUp={handleChange} defaultValue={integracao.nameIdentifier1} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Nome Identificador 2</CFormLabel>
              <CFormInput name="nameIdentifier2" onKeyUp={handleChange} defaultValue={integracao.nameIdentifier2} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Nome Identificador 3</CFormLabel>
              <CFormInput name="nameIdentifier3" onKeyUp={handleChange} defaultValue={integracao.nameIdentifier3} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={3} style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Nome Identificador 4</CFormLabel>
              <CFormInput name="nameIdentifier4" onKeyUp={handleChange} defaultValue={integracao.nameIdentifier4} type="text" onChange={handleChange} />
            </div>
          </CCol>
        </CRow>
        <CRow>
          <CCol md={4} style={{padding: '15px'}}>
            <div className="mb-4">
              <CFormLabel>Tópico Sucesso</CFormLabel>
              <CFormInput name="successTopic" onKeyUp={handleChange} defaultValue={integracao.successTopic} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={4} style={{padding: '15px'}}>
            <div className="mb-4">
              <CFormLabel>Tópico DLQ</CFormLabel>
              <CFormInput name="dlqTopic" onKeyUp={handleChange} defaultValue={integracao.dlqTopic} type="text" onChange={handleChange} />
            </div>
          </CCol>
          <CCol md={4} style={{padding: '15px'}}>
            <div className="mb-4">
              <CFormLabel>Tópico Reprocessamento</CFormLabel>
              <CFormInput name="reprocessTopic" onKeyUp={handleChange} defaultValue={integracao.reprocessTopic} type="text" onChange={handleChange} />
            </div>
          </CCol>
        </CRow>

        <CRow>
          <CCol xs  style={{textAlignLast: 'right' }}>
            <CButton  color="light" onClick={handleBack} style={{textAlignLast: 'center', width: '100px', marginRight: '15px'}} >Cancelar</CButton>
            <CButton  color="dark" onClick={handleSend} style={{textAlignLast: 'center', width: '85px'}} >Enviar</CButton>
          </CCol>
        </CRow>
      </CCardBody>
    </CCard>


    <CCard className="mb-4" style={{display: id ? "block" : "none"}}>
      <CCardBody>
      <CCol>
          <div style={{paddingBottom: '15px'}}>
            <h5>Status de tópicos</h5>
          </div>
        </CCol>
      <CRow>
          <CCol  style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Status de consumo - Tópico Sucesso</CFormLabel>
              <CFormInput name="successTopicConsumerStatus" onKeyUp={handleChange} defaultValue={integracao.successTopicConsumerStatus} type="text" readOnly disabled />
            </div>
          </CCol>
          <CCol  style={{padding: '15px'}}>
            <div className="mb-3">
              <CFormLabel>Status de consumo - Tópico DLQ</CFormLabel>
              <CFormInput name="dlqTopicConsumerStatus" onKeyUp={handleChange} defaultValue={integracao.dlqTopicConsumerStatus} readOnly type="text" disabled />
            </div>
          </CCol>
        </CRow>
      </CCardBody>
    </CCard>
  </>)

}

export default IntegracaoPage;
