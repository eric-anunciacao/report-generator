import * as React from 'react';
import { CButton, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle } from "@coreui/react"
import { deleteIntegration } from '../../reprocessamento/hooks/integration';

export const ConfirmationPopup = (props) => {

    const handleSend = async () => {

        try{
            const res = await deleteIntegration(JSON.stringify(props.row.id));
            if(res.ok){
            props.setConfirmation(true);
            }else{
                props.setError('Erro: Não foi possível deletar');
            }
        }catch(e){
            props.setError('Erro: Não foi possível deletar');
        }
        props.close();
    };

    return (<>
        <CModal
            visible={props.open}
            onClose={props.close}
        >
        <CModalHeader>
            <CModalTitle>Atenção</CModalTitle>
        </CModalHeader>
        <CModalBody>{props.message}</CModalBody>
        <CModalFooter>
            <CButton color="light" onClick={props.close}>Cancelar</CButton>
            <CButton color="dark" onClick={handleSend}>Confirmar</CButton>
        </CModalFooter>
        </CModal>
    </>)
}