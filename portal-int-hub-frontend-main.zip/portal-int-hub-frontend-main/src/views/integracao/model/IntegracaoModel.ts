import { IIntegration } from "src/domain/entities/interfaces/IIntegration"


export const IntegracaoModel = ():IIntegration => {
    return {
      id:0,
      active:true,
      correlationId:"",
      cluster:{
        id:0,
        name:"",
        servers:""
      },
      dlqTopic:"",
      dlqTopicConsumerStatus:"",
      dtCreate:"",
      dtUpdate:"",
      identifier1:"",
      identifier2:"",
      identifier3:"",
      identifier4:"",
      name:"",
      nameIdentifier1:"",
      nameIdentifier2:"",
      nameIdentifier3:"",
      nameIdentifier4:"",
      reprocessTopic:"",
      successTopic:"",
      successTopicConsumerStatus:""
      }
}
