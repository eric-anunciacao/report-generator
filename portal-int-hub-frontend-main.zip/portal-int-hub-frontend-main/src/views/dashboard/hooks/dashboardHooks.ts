import { API } from "src/constants"

export const getQueueDashboard = async (props:any) => {
  const res = await fetch(
    `${API}queue-controller/statistics${
      props.beginDate ? `?dtEventBegin=${props.beginDate} 00:00:01&` : ''
    }${props.endDate ? `dtEventEnd=${props.endDate} 23:59:59` : ''}`,
    { headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' } },
  )
  

  return res
}

