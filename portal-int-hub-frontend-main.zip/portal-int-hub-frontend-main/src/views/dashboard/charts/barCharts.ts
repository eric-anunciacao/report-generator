import { IChart } from "src/domain/entities/interfaces/IChart";
import { GenerateBarChartData } from "../models/barCharts";
import React from "react";

export const barCharts = (props:any) => {
    return {
        series: [{
            name: 'Sucesso',
            data: props.successList
        }, {
            name: 'Reprocessado',
            data: props.reprocessedList
        }, {
            name: 'Erro',
            data: props.errorList
        },
        {
            name: 'Aguardando reprocessamento',
            data: props.waitingReprocessingList
        },
        {
            name: 'Falha no reprocessamento',
            data: props.failedReprocessingList
        }],
        options: {
            noData: {
                text: "Loading...",
                align: 'center',
                verticalAlign: 'middle',
                offsetX: 0,
                offsetY: 0,
                style: {
                    color: "#000000",
                    fontSize: '14px',
                    fontFamily: "Helvetica"
                }
            },
            chart: {
                events: {
                    dataPointSelection: (event:any, chartContext:any, config:any) => {

                    }
                },
                type: 'bar',
                height: 100,
                stacked: true,
            },
            plotOptions: {
                bar: {
                    barHeight: '50px',
                    horizontal: true,
                },
            },
            stroke: {
                width: 1,
                colors: ['#fff']
            },
            title: {
                text: ''
            },
            xaxis: {
                categories: props.categories,
                labels: {
                    formatter: function (val:any) {
                        return Math.floor(val)
                    }
                }
            },
            yaxis: {
                title: {
                    text: undefined
                },
            },
            colors: ['#6ed463', '#008ffb', '#fa7d7d', '#ffa500', '#5a5a5a'],
            tooltip: {
                y: {
                    formatter: function (val:any) {
                        return val
                    }
                }
            },
            fill: {
                opacity: 1
            },
            legend: {
                position: 'top',
                horizontalAlign: 'left',
                offsetX: 40
            }
        }

    };

}

export const buildBarDashboard = (values:IChart[], setNewValues:any, setOptionsBar:any, newValues:any ) => {
    
    const barChartData = GenerateBarChartData(values);

    setNewValues( (bar: any) => ({
        ...bar,
        ...barChartData
    }) );

    setOptionsBar(barCharts(newValues));

}