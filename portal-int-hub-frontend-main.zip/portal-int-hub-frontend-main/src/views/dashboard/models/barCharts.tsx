import { IBarChartModel } from "src/domain/entities/interfaces/IBarChartModel"
import { IChart } from "src/domain/entities/interfaces/IChart"



export const EmptyBarChartData = () : IBarChartModel => {
    return {
        categories: [],
        successList: [],
        errorList: [],
        reprocessedList: [],
        waitingReprocessingList: [],
        failedReprocessingList: []
    }
}

export const GenerateBarChartData = (barChart: IChart[]) : IBarChartModel => {
    return {
      categories: barChart?.map((bar:IChart) => bar.integration?.name ),
      successList: barChart?.map((bar:IChart) => bar.success.toString() ),
      errorList: barChart?.map((bar: IChart) => bar.error.toString()),
      reprocessedList: barChart?.map((bar: IChart) => bar.reprocessed.toString() ),
      waitingReprocessingList: barChart?.map((bar: IChart) => bar.waitingReprocessing.toString() ),
      failedReprocessingList: barChart?.map((bar: IChart) => bar.failedReprocessing.toString() )
    }
  }