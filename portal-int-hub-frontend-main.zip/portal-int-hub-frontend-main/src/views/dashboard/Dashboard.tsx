import React, { useEffect, useState } from 'react'
import { CCard, CCardBody, CRow, CButton, CFormInput } from '@coreui/react'
import ReactApexChart from 'react-apexcharts'
import { getQueueDashboard } from './hooks/dashboardHooks'
import './Dashboard.scss'
import CIcon from '@coreui/icons-react'
import { TopAlertErrorComponent } from '../../utils/alerts'
import { buildBarDashboard } from './charts/barCharts'
import { EmptyBarChartData } from './models/barCharts'
import { useAsyncDeepState } from 'use-async-effect2'

import StatusAmbiente from '../statusAmbiente/StatusAmbiente'
import * as icon from '@coreui/icons'
import moment from 'moment'
import { IBarChartModel } from 'src/domain/entities/interfaces/IBarChartModel'

const Dashboard = () => {
  // const [loadingSimpleBar, setLoadingSimpleBar] = useState(false)
  //
  // // const [loadingLogBar, setLoadingLogBar] = useState(false)
  // // const [integrationSelected, setIntegrationSelected] = useState(false)
  // // const [errorLogsBar, setErrorLogsBar] = useState('')
  //
  // const [error, setError] = useState('')
  // const [errorSimpleBar, setErrorSimpleBar] = useState('')
  //
  // const [simpleBarCharts, setSimpleBarCharts] = useAsyncDeepState({ EmptyBarChartData })
  //
  // const [statusAmbiente, setStatusAmbiente] = useState([])
  //
  // const [selectedInitialDate, setSelectedInitialDate] = useState(moment().startOf("month").format("YYYY-MM-DD"))
  // const [selectedFinalDate, setSelectedFinalDate] = useState(moment().format('YYYY-MM-DD'))
  // const [qtIntegrations, setQtIntegrations] = useState(0)
  // const SIZE_INTEGRATION_CHART = 150
  //
  // const [optionsBarCharts, setOptionsBarCharts] = useState({
  //   series: [{ name: '', data: [] }],
  //   options: {},
  // })
  //
  //
  // const searchBar = async (request: any) => {
  //   let res = await request({ beginDate: selectedInitialDate, endDate: selectedFinalDate })
  //   const json = await res.json()
  //   return { res: res, json: json }
  // }
  //
  // const searchSimpleBar = async () => {
  //   try {
  //     setLoadingSimpleBar(true)
  //     let simpleBar = await searchBar(getQueueDashboard)
  //     if (simpleBar?.res.ok) {
  //       setQtIntegrations(simpleBar.json.length)
  //       buildBarDashboard(simpleBar.json, setSimpleBarCharts, setOptionsBarCharts, simpleBarCharts)
  //       const statusAmbienteJson = simpleBar.json.map((i: any) => {
  //         i.id = i.integration?.id
  //         return i
  //       })
  //
  //       setStatusAmbiente(statusAmbienteJson)
  //       setErrorSimpleBar('')
  //     } else {
  //       setErrorSimpleBar('Erro: Não foi possível exibir o dashboard linear')
  //     }
  //     setLoadingSimpleBar(false)
  //   } catch (e) {
  //     console.log('error => ' + e)
  //     setError('Erro: Não foi possível exibir o dashboard linear')
  //   }
  // }
  //
  // const handleSearch = async () => {
  //   setError('')
  //
  //   if (selectedInitialDate && !selectedFinalDate) {
  //     setError('Necessário preencher a data final do evento')
  //     return
  //   }
  //
  //   if (selectedFinalDate && !selectedInitialDate) {
  //     setError('Necessário preencher data inicial do evento')
  //     return
  //   }
  //
  //   if(moment(selectedInitialDate) > moment(selectedFinalDate)){
  //     setError('A data final deve ser posterior a data inicial')
  //     return
  //
  //   }
  //
  //   searchSimpleBar()
  // }
  //
  // useEffect(() => {
  //   handleSearch()
  // }, [])

  return (
    <>
      {/*{errorSimpleBar && (*/}
      {/*  <TopAlertErrorComponent setError={setErrorSimpleBar} message={errorSimpleBar} />*/}
      {/*)}*/}
      {/*{error && <TopAlertErrorComponent setError={setError} message={error} />}*/}

      {/*<CCard className="mb-4">*/}
      {/*  <CCardBody>*/}
      {/*    <CRow>*/}
      {/*      <div className='flex flex-col lg:flex-row items-center mb-4'>*/}

      {/*        <div className='flex w-full lg:w-1/2'>*/}
      {/*          <h4>Mensagens em Reprocessamento </h4>*/}
      {/*        </div>*/}
      {/*        <div className='flex w-full lg:w-1/2 gap-3 justify-end flex-col lg:flex-row'>*/}

      {/*          <div className='flex flex-col w-full lg:w-4/5'>*/}
      {/*            <CFormInput*/}
      {/*              value={selectedInitialDate}*/}
      {/*              onChange={(e) => setSelectedInitialDate(e.target.value)}*/}
      {/*              label="Data de Evento - Início"*/}
      {/*              placeholder="Data de Evento - Início"*/}
      {/*              type="date"*/}
      {/*            />*/}
      {/*          </div>*/}
      {/*          <div className='flex flex-col w-full lg:w-4/5'>*/}
      {/*            <CFormInput*/}
      {/*              value={selectedFinalDate}*/}
      {/*              onChange={(e) => setSelectedFinalDate(e.target.value)}*/}
      {/*              label="Data de Evento - Final"*/}
      {/*              placeholder="Data de Evento - Final"*/}
      {/*              type="date"*/}
      {/*            />*/}
      {/*          </div>*/}
      {/*           <div className='flex  flex-col w-full mb-1 lg:w-1/5 items-center justify-end'>*/}
      {/*            <CButton*/}
      {/*              disabled={false}*/}
      {/*              onClick={handleSearch}*/}
      {/*              color="dark"*/}
      {/*              className='flex items-center justify-center w-full'*/}
      {/*            >*/}
      {/*              <CIcon*/}
      {/*                style={{ cursor: 'pointer'}}*/}
      {/*                size="lg"*/}
      {/*                icon={icon.cilLoopCircular}*/}
      {/*              />*/}
      {/*            </CButton>*/}
      {/*          </div>*/}
      {/*        </div>*/}
      {/*      </div>*/}
      {/*      {loadingSimpleBar ? (*/}
      {/*        <>*/}
      {/*          <div style={{ height: '300px' }}>*/}
      {/*            <div className="loader-container">*/}
      {/*              <div className="spinner"></div>*/}
      {/*            </div>*/}
      {/*          </div>*/}
      {/*        </>*/}
      {/*      ) : (*/}
      {/*        <>*/}
      {/*          <ReactApexChart*/}
      {/*            options={optionsBarCharts?.options}*/}
      {/*            series={optionsBarCharts?.series}*/}
      {/*            type="bar"*/}
      {/*            height={qtIntegrations * SIZE_INTEGRATION_CHART}*/}
      {/*          />*/}
      {/*        </>*/}
      {/*      )}*/}
      {/*    </CRow>*/}
      {/*  </CCardBody>*/}
      {/*</CCard>*/}

      {/*<StatusAmbiente*/}
      {/*  error={error}*/}
      {/*  setError={setError}*/}
      {/*  statusAmbiente={statusAmbiente}*/}
      {/*  loading={loadingSimpleBar}*/}
      {/*/>*/}
    </>
  )
}

export default Dashboard
