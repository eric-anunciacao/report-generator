import * as React from 'react';
import DLQTable from '../../components/DLQTable';
import { CCard, CCardBody, CForm, CRow, CTooltip } from '@coreui/react';
import { TopAlertErrorComponent } from '../../utils/alerts';
import { RenameStatus, CellClassName } from '../reprocessamento/utils/reprocessamentoUtils';
import moment from 'moment';
import 'moment/locale/pt-br';
import CIcon from '@coreui/icons-react';
import * as icon from '@coreui/icons';
import { getReprocessadosList } from '../reprocessamento/hooks/reprocessamento';
import { FilterReprocessamento } from '../reprocessamento/filter';
import ModalReprocessamentoComponent from '../reprocessamento/modal/Modal';

const Reprocessados = () =>{

    const [loading, setLoading] = React.useState(false);

    const [selectedStatus, setSelectedStatus] = React.useState('');
    const [selectedInitialDate, setSelectedInitialDate] = React.useState('');
    const [selectedEndDate, setSelectedEndDate] = React.useState('');
    const [integracao, setIntegracao] = React.useState('');
    const [identificador, setIdentificador] = React.useState('');

    const [reprocessamentoList, setReprocessamentoList] = React.useState([]);
    const [error, setError] = React.useState('');

    const [open, setOpen] = React.useState(false);
    const [row, setRow] = React.useState(null);

    const fetchReprocessamentoList = async () => {
      const props = { status : selectedStatus, dtEventoStart : selectedInitialDate,
         dtEventoEnd : selectedEndDate, identificador: identificador, integracao: integracao };
      try {
        setLoading(true);
        let res = await getReprocessadosList(props);
        const json = await res.json();

        if(res.ok){
          setReprocessamentoList(json);
          setError('');
        }else{
          setError('Erro: Não foi possível exibir a listagem de Reprocessados')
        }
      } catch (e) {
        setError('Erro: Não foi possível exibir a listagem de Reprocessados');
       }

       setLoading(false);
    }

    React.useEffect(() => {
      fetchReprocessamentoList();
    }, []);

    const handleSearch = () => {
      fetchReprocessamentoList();
    };

    const handleClose = () => setOpen(false);


    const columns = [
      { field: "ID", hide: true },
      { field: 'INTEGRACAO', headerName: 'Integração', width: 200 },
      { field: 'STATUS', headerName: 'Status', width: 150, renderCell: (params) => RenameStatus(params?.row?.STATUS) },
      { field: 'DT_EVENTO', headerName: 'Data de Evento', width: 300, renderCell: (params) => moment(params?.row?.DT_EVENTO).format('DD/MM/YYYY H:mm:ss') },
      { field: 'OBSERVACAO', headerName: 'Observação', width: 200 },
      { field: 'action', headerName: 'Ação', width: 200, renderCell: (params) => {

          const openDialog = () => {
            setRow(params.row)
            setOpen(true);
          }

          return (
            <>
            <CTooltip content="Visualizar" placement="top" > 
              <CIcon style={{ cursor: 'pointer', marginRight: '20px' }} onClick={openDialog} size='lg' icon={icon.cilMagnifyingGlass} /> 
            </CTooltip>
            </>
          )
        } },
    ];

    return (
        <>
        { error && <TopAlertErrorComponent message={error} /> }
        <CCard className="mb-4">
          <CCardBody>
            <CForm>
              <CRow>
                <FilterReprocessamento
                setSelectedStatus={setSelectedStatus}
                setSelectedInitialDate={setSelectedInitialDate}
                setSelectedEndDate={setSelectedEndDate}
                handleSearch={handleSearch}
                setIntegracao={setIntegracao}
                setIdentificador={setIdentificador}
                setReprocessamentoList={setReprocessamentoList}
                setError={setError}
                setLoading={setLoading}
                />
                <DLQTable paginationMode='mock' id="ID" loading={loading} columns={columns} rows={reprocessamentoList} cellClassName={CellClassName}></DLQTable>
                <ModalReprocessamentoComponent setError={setError} open={open} close={handleClose} row={row} />
                </CRow>
            </CForm>
          </CCardBody>
        </CCard>
        </>
      );

}

export default Reprocessados;
