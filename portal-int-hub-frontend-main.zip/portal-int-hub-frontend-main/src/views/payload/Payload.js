import * as React from 'react';
import { TopAlertErrorComponent } from "../../utils/alerts";
import { CFormLabel, CFormInput, CCard, CCardBody, CCol, CRow, CFormTextarea, CButton } from "@coreui/react";
import { RequestModel } from "./Models/RequestModel";
import { getReprocesamentoList, updateReprocessamento } from '../reprocessamento/hooks/reprocessamento';
import {useLocation} from 'react-router-dom';
import { useNavigate  } from 'react-router-dom';



const Payload = () => {

    const navigate = useNavigate();

    const [loading, setLoading] = React.useState(false);

    const [request, setRequest] = React.useState(RequestModel);

    const [error, setError] = React.useState('');

    const location = useLocation();
    const ID = location?.state?.id;

    const prop = { identificador : ID };

    const handleChange = e => {
        const { name, value } = e.target;
        setRequest(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleBack = () => {
        navigate(-1);
    }

    const fetchPayload = async () => {
        try {
          setLoading(true);
          let res = await getReprocesamentoList(prop);
          const json = await res.json();

          if(res.ok){
            if(!json[0]){
                handleBack();
            }else{
                setRequest(json[0]);
                setError('');
            }
          }else{
            setError('Erro: Não foi possível trazer o conteúdo')
          }
        } catch (e) {
          setError('Erro: Não foi possível trazer o conteúdo');
         }

         setLoading(false);
      }


      React.useEffect(() => {
        fetchPayload();
      }, []);

      const handleSend = async () => {
        try{
            const res = await updateReprocessamento(request);
            if(res.ok){
            setError('');
            handleBack();
            }else{
                setError('Erro: Não foi possível enviar o Payload');
            }
        }catch(e){
            setError('Erro: Não foi possível enviar o Payload');
        }
       };

    return (<>
        { error && <TopAlertErrorComponent message={error} /> }
        <CCard className="mb-4">
            <CCardBody>
                    <legend>Integração</legend>
                    <CRow>
                        <CCol md={3} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Id</CFormLabel>
                                <CFormInput name="ID" defaultValue={request.ID} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={3} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Cluster</CFormLabel>
                                <CFormInput name="CLUSTER" defaultValue={request.CLUSTER} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={3} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Integração</CFormLabel>
                                <CFormInput name="INTEGRACAO" defaultValue={request.INTEGRACAO} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={3} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Status</CFormLabel>
                                <CFormInput name="STATUS" defaultValue={request.STATUS} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={3} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Data Alteração</CFormLabel>
                                <CFormInput name="DT_ALTERACAO" defaultValue={request.DT_ALTERACAO} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={3} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Data Evento</CFormLabel>
                                <CFormInput name="DT_EVENTO" defaultValue={request.DT_EVENTO} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                    </CRow>
                    <CRow>
                        <CCol style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>Observação</CFormLabel>
                                <CFormTextarea
                                    name="OBSERVACAO"
                                    defaultValue={request.OBSERVACAO}
                                    onChange={handleChange}
                                    rows="3"
                                    type="text" ></CFormTextarea>
                            </div>
                        </CCol>
                    </CRow>
            </CCardBody>
        </CCard>

        <CCard className="mb-4">
            <CCardBody>
                    <legend>Payload</legend>
                    <CRow>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>ID</CFormLabel>
                                <CFormInput name="invoice.ID" defaultValue={request.invoice?.ID} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>ACK</CFormLabel>
                                <CFormInput name="invoice.ACK" defaultValue={request.invoice?.ACK} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>APP ORIGIN</CFormLabel>
                                <CFormInput name="invoice.APP_ORIGIN" defaultValue={request.invoice?.APP_ORIGIN} type="text" onChange={handleChange}/>
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>APP SUB ORIGIN</CFormLabel>
                                <CFormInput name="invoice.APP_SUB_ORIGIN" defaultValue={request.invoice?.APP_SUB_ORIGIN} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>GROUP ID</CFormLabel>
                                <CFormInput name="invoice.GROUP_ID" defaultValue={request.invoice?.GROUP_ID} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>MODIFIED</CFormLabel>
                                <CFormInput name="invoice.MODIFIED" defaultValue={request.invoice?.MODIFIED} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>MODIFIED BY</CFormLabel>
                                <CFormInput name="invoice.MODIFIED_BY" defaultValue={request.invoice?.MODIFIED_BY} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>NUMBER</CFormLabel>
                                <CFormInput name="invoice.NUMBER" defaultValue={request.invoice?.NUMBER} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>REFERENCE ORDER</CFormLabel>
                                <CFormInput name="invoice.REFERENCE_ORDER" defaultValue={request.invoice?.REFERENCE_ORDER} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>USER ID</CFormLabel>
                                <CFormInput name="invoice.USER_ID" defaultValue={request.invoice?.USER_ID} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>XML VERSION</CFormLabel>
                                <CFormInput name="invoice.XML_VERSION" defaultValue={request.invoice?.XML_VERSION} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                    </CRow>
                    <CRow>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE KEY</CFormLabel>
                                <CFormInput name="invoice.NFE_KEY" defaultValue={request.invoice?.NFE_KEY} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>NFE TYPE</CFormLabel>
                                <CFormInput name="invoice.NFE_TYPE" defaultValue={request.invoice?.NFE_TYPE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE STATUS</CFormLabel>
                                <CFormInput name="invoice.NFE_STATUS" defaultValue={request.invoice?.NFE_STATUS} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE SERIE</CFormLabel>
                                <CFormInput name="invoice.NFE_SERIE" defaultValue={request.invoice?.NFE_SERIE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE RECEIPT</CFormLabel>
                                <CFormInput name="invoice.NFE_RECEIPT" defaultValue={request.invoice?.NFE_RECEIPT} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE RECEIPT DATE</CFormLabel>
                                <CFormInput name="invoice.NFE_RECEIPT_DATE" defaultValue={request.invoice?.NFE_RECEIPT_DATE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE DATE</CFormLabel>
                                <CFormInput name="invoice.NFE_DATE"  defaultValue={request.invoice?.NFE_DATE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE CORRECTION LETTER PROTOCOL</CFormLabel>
                                <CFormInput name="invoice.NFE_CORRECTION_LETTER_PROTOCOL"  defaultValue={request.invoice?.NFE_CORRECTION_LETTER_PROTOCOL} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE CREATION DATE</CFormLabel>
                                <CFormInput name="invoice.NFE_CREATION_DATE" defaultValue={request.invoice?.NFE_CREATION_DATE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE CANCELLATION REASON</CFormLabel>
                                <CFormInput name="invoice.NFE_CANCELLATION_REASON" defaultValue={request.invoice?.NFE_CANCELLATION_REASON} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE CANCELLATION PROTOCOL</CFormLabel>
                                <CFormInput name="invoice.NFE_CANCELLATION_PROTOCOL" defaultValue={request.invoice?.NFE_CANCELLATION_PROTOCOL} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE CANCELLATION ERROR CODE</CFormLabel>
                                <CFormInput name="invoice.NFE_CANCELLATION_ERROR_CODE" defaultValue={request.invoice?.NFE_CANCELLATION_ERROR_CODE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel >NFE CANCELLATION ERROR DESCRIPTION</CFormLabel>
                                <CFormInput name="invoice.NFE_CANCELLATION_ERROR_DESCRIPTION" defaultValue={request.invoice?.NFE_CANCELLATION_ERROR_DESCRIPTION} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>NFE CANCELLATION DATE</CFormLabel>
                                <CFormInput name="invoice.NFE_CANCELLATION_DATE"  defaultValue={request.invoice?.NFE_CANCELLATION_DATE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol md={4} style={{padding: '15px'}}>
                            <div className="mb-3">
                                <CFormLabel>NFE AUTHORIZATION DATE</CFormLabel>
                                <CFormInput name="invoice.NFE_AUTHORIZATION_DATE" defaultValue={request.invoice?.NFE_AUTHORIZATION_DATE} type="text" onChange={handleChange} />
                            </div>
                        </CCol>
                        <CCol xs  style={{textAlignLast: 'right' }}>
                            <CButton  color="light" onClick={handleBack} style={{textAlignLast: 'center', width: '100px', marginRight: '15px'}} >Cancelar</CButton>
                            <CButton  color="dark" onClick={handleSend} style={{textAlignLast: 'center', width: '85px'}} >Enviar</CButton>
                        </CCol>
                    </CRow>
            </CCardBody>
        </CCard>

    </>)

}

export default Payload;
