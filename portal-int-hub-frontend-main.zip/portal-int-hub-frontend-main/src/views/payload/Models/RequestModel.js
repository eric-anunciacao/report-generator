export const RequestModel = () => {

    return {
        "CLUSTER": "",
        "DT_ALTERACAO": "",
        "DT_EVENTO": "",
        "ID": "",
        "INTEGRACAO": "",
        "OBSERVACAO": "",
        "STATUS": "",
        "invoice": {
          "ACK": "",
          "APP_ORIGIN": "",
          "APP_SUB_ORIGIN": "",
          "CREATED": "",
          "CREATED_BY": "",
          "FILES": [
            {
              "ID": "",
              "TYPE": "",
              "URL": ""
            }
          ],
          "GROUP_ID": "",
          "ID": "",
          "MODIFIED": "",
          "MODIFIED_BY": "",
          "NFE_AUTHORIZATION_DATE": "",
          "NFE_CANCELLATION_DATE": "",
          "NFE_CANCELLATION_ERROR_CODE": "",
          "NFE_CANCELLATION_ERROR_DESCRIPTION": "",
          "NFE_CANCELLATION_PROTOCOL": "",
          "NFE_CANCELLATION_REASON": "",
          "NFE_CORRECTION_LETTER_PROTOCOL": "",
          "NFE_CREATION_DATE": "",
          "NFE_DATE": "",
          "NFE_KEY": "",
          "NFE_PROTOCOL": "",
          "NFE_RECEIPT": "",
          "NFE_RECEIPT_DATE": "",
          "NFE_SERIE": "",
          "NFE_STATUS": "",
          "NFE_TYPE": "",
          "NUMBER": "",
          "REFERENCE_ORDER": "",
          "USER_ID": "",
          "XML_VERSION": ""
        }
      }

}