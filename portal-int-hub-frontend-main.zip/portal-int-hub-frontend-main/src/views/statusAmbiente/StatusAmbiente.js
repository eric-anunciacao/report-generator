import * as React from 'react'
import DLQTable from '../../components/DLQTable'
import { CButton, CCard, CCardBody, CCol, CFormInput, CRow } from '@coreui/react'
import { getQueueDashboard } from '../dashboard/hooks/dashboardHooks'

function cellClassName(params) {
  if (params.value == null || params.value === '') {
    return ''
  }

  if (params.field == 'success') {
    return 'sucesso'
  }
  if (params.field == 'error') {
    return 'erro'
  }
  if (params.field == 'reprocessed') {
    return 'reprocessado'
  }
  if (params.field == 'waitingReprocessing') {
    return 'aguardandoreprocess'
  }
  if (params.field == 'failedReprocessing') {
    return 'falhareprocess'
  }

  return ''
}

const StatusAmbiente = ({ error, setError, statusAmbiente, loading }) => {


  const columns = [
    { field: 'id', hide: true },
    {
      field: 'cluster',
      headerName: 'Cluster',
      width: 100,
      renderCell: (params) => {
        return params.row?.integration?.cluster?.name
      },
    },
    {
      field: 'integracao',
      headerName: 'Integração',
      width: 450,
      renderCell: (params) => {
        return params.row?.integration?.name
      },
    },
    { field: 'success', headerName: 'Sucesso', width: 150 },
    { field: 'error', headerName: 'Erro', width: 150 },
    { field: 'reprocessed', headerName: 'Reprocessado', width: 150 },
    { field: 'waitingReprocessing', headerName: 'Aguardando reprocessamento', width: 150 },
    { field: 'failedReprocessing', headerName: 'Falha no reprocessamento', width: 150 }
  ]

  return (
    <>
      {/* { error && <TopAlertErrorComponent setError={setError} message={error} /> } */}
      <CCard className="mb-4">
        <CCardBody>
          <CRow>
            <h4>Status do ambiente</h4>
            <DLQTable
              paginationMode="mock"
              loading={loading}
              columns={columns}
              rows={statusAmbiente}
              cellClassName={cellClassName}
            ></DLQTable>
          </CRow>
        </CCardBody>
      </CCard>
    </>
  )
}

export default StatusAmbiente
