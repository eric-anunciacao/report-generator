import * as React from 'react';
import { CButton, CCol, CFormInput, CFormLabel, CFormSelect } from '@coreui/react';
import { getIntegrationList } from '../reprocessamento/hooks/integration';

export const FilterStatusAmbiente = (change) => {

    const [integrationList, setIntegrationList] = React.useState([]);

    const searchIntegration = async () => { 

        try {
        let res = await getIntegrationList();
        const json = await res.json();

        if(res.ok){
            setIntegrationList(json);
            change.setError('');
        }else{
            change.setError('Erro: Não foi possível exibir a listagem de Integração')
        }
        } catch (e) {
        change.setError('Erro: Não foi possível exibir a listagem de Integração');
        }

    };

    React.useEffect(() => {
      searchIntegration();
    }, []);

    return (<>
      <CCol md={4} style={{padding: '10px'}}>
        <CFormLabel className="col-sm-4 col-form-label">Integração</CFormLabel><CFormSelect
          onChange={(e) => change.setIntegracao(e.target.value)} value={change.integracao} >
          <option value="">Selecione</option>
          {
            integrationList?.map( (x,y) => 
              <option key={y} value={x.id}> {x.name}</option> )
          }
        </CFormSelect>
      </CCol>
      <CCol md={4} style={{padding: '10px'}}>
      { (change.selectedStatus !== undefined) && <><CFormLabel className="col-sm-2 col-form-label">Status</CFormLabel><CFormSelect
          onChange={(e) => change.setSelectedStatus(e.target.value)} value={change.selectedStatus}
          aria-label="Default select example">
          <option value="">Selecione</option>
          <option value='Sucesso'>Sucesso</option>
          <option value='Erro'>Erro</option>
          {/* <option value='PENDING'>Pendente</option> */}
          <option value='Reprocessado'>Reprocessado</option>
          <option value='Aguardando reprocessamento'>Aguardando reprocessamento</option>
          <option value='Falha no reprocessamento'>Falha no reprocessamento</option>
        </CFormSelect></> }
      </CCol>
    </>)

}
