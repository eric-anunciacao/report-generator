import React from 'react'
import { BrowserRouter, Routes, Route, HashRouter } from 'react-router-dom'
// import Login from './views/pages/Login'
import Home from './views/pages/Home'
import Dashboard from './views/dashboard/Dashboard'
import Reprocessing from './views/reprocessamento/Reprocessamento'
import IntegrationList from './views/integracao/IntegracaoList'
import IntegrationPage from './views/integracao/IntegracaoPage'
import ClusterList from './views/cluster/ClusterList'
import ClusterPage from './views/cluster/ClusterPage'
import AutoReprocessingList from "./views/autoreprocessamento/AutoReprocessamentoList";
import AutoReprocessingPage from "./views/autoreprocessamento/AutoReprocessamentoPage";
import { ROUTES } from './constants'

export const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* <Route path="/"  element={<Login />} /> */}

        <Route path={ROUTES.HOME} element={<Home />}>
          <Route index element={<Dashboard />} />
          <Route path={ROUTES.MESSAGES} element={<Reprocessing />} />
          <Route path={ROUTES.INTEGRATION} element={<IntegrationList />} />
          <Route path={ROUTES.NEW_INTEGRATION} element={<IntegrationPage />} />
          <Route path={ROUTES.UPDATE_INTEGRATION} element={<IntegrationPage />} />
          <Route path={ROUTES.CLUSTER} element={<ClusterList />} />
          <Route path={ROUTES.NEW_CLUSTER} element={<ClusterPage />} />
          <Route path={ROUTES.UPDATE_CLUSTER} element={<ClusterPage />} />
          <Route path={ROUTES.AUTOREPROCESSING} element={<AutoReprocessingList />} />
          <Route path={ROUTES.NEW_AUTOREPROCESSING} element={<AutoReprocessingPage />} />
          <Route path={ROUTES.UPDATE_AUTOREPROCESSING} element={<AutoReprocessingPage />} />

        </Route>
      </Routes>
    </BrowserRouter>
  )
}
