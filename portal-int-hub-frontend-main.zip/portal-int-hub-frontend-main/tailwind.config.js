/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary-ligth': '#D6DFFC',
        'background-color': '#EBEDEF',
        'blue-50': '#EFF6FF',
        'primary-color':'#303C54',
        'blue-800': '#1E40AF',
        'text-regular-color': '#111827',
        'text-secundary' : '#6B7280',
        'error-color': 'rgb(185 28 28);',
        "error-color-bold": '#991B1B',
        'error-box': '#FEF2F2',
        'button-disabled': '#E0E7FF',
        'text-color-disable': '#4338CA',
        "color-succes": "#ECFDF5",
        "text-color-success": "#065F46",
        "box-color-succes": "#D1FAE5"                
      },
    },
  },
  plugins: [],
}
