
CREATE OR REPLACE FUNCTION partial_clear_queue_data_before(_date timestamp)
    RETURNS INT
    LANGUAGE plpgsql AS
$func$
BEGIN

    CREATE TEMP TABLE tmp_queue_ids ON COMMIT DROP AS
    SELECT id FROM public.queue WHERE dt_event <= _date LIMIT 500;

    DELETE FROM public.queue_logs ql
        USING  tmp_queue_ids t
    WHERE  ql.id_queue = t.id;

    DELETE FROM public.queue q
        USING  tmp_queue_ids t
    WHERE  q.id = t.id;

    RETURN (SELECT COUNT(*) FROM tmp_queue_ids);

END
$func$;