
ALTER TABLE public.integration ALTER COLUMN active SET NOT NULL;

ALTER TABLE public.integration ALTER COLUMN name SET NOT NULL;
