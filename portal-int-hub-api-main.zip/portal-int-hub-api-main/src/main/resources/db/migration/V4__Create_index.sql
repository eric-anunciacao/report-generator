
CREATE INDEX IF NOT EXISTS queue_idx_dt_event_integration_id
    on queue (dt_event, integration_id);

