
ALTER TABLE public.queue ADD COLUMN IF NOT EXISTS success_payload text null;