
ALTER TABLE IF EXISTS public.queue_logs
    DROP CONSTRAINT IF EXISTS queue_logs_queue_fkey;