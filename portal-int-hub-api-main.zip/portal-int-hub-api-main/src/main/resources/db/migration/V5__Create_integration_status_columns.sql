
ALTER TABLE public.integration ADD COLUMN IF NOT EXISTS dlq_topic_consumer_status varchar(1000);

ALTER TABLE public.integration ADD COLUMN IF NOT EXISTS success_topic_consumer_status varchar(1000);
