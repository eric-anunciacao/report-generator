ALTER TABLE integration ALTER COLUMN cluster_id SET NOT NULL;

CREATE INDEX IF NOT EXISTS integration_idx_cluster_id on integration (cluster_id);

ALTER TABLE queue ALTER COLUMN integration_id SET NOT NULL;

ALTER TABLE queue_logs ALTER COLUMN id_queue SET NOT NULL;

CREATE INDEX IF NOT EXISTS queue_logs_idx_queue_id on queue_logs (id_queue);

CREATE TABLE IF NOT EXISTS public.outbox
(
    id uuid not null,
    aggregate varchar(500) not null,
    aggregate_id varchar(500),
    created_at timestamp not null,
    dispatched boolean not null,
    dispatched_at timestamp,
    message text not null,
    operation varchar(500) not null,
    primary key (id)
);

CREATE INDEX IF NOT EXISTS  outbox_idx_aggregate_created_at_dispatched
    on public.outbox (aggregate, created_at, dispatched);

CREATE INDEX IF NOT EXISTS  outbox_idx_dispatched_created_at
    on public.outbox (dispatched, created_at);

CREATE INDEX IF NOT EXISTS outbox_idx_aggregate_id
    on public.outbox (aggregate_id);

ALTER TABLE public.queue_logs ADD COLUMN IF NOT EXISTS message varchar(1000);

CREATE TABLE IF NOT EXISTS public.consumer_logs
(
    id bigserial not null,
    dt_event timestamp not null,
    topic_type varchar(50) not null,
    event_type varchar(50) not null,
    integration_id bigserial not null,
    message varchar(1000) not null,
    primary key (id)
);

CREATE INDEX IF NOT EXISTS consumer_logs_idx_integration_id
    on public.consumer_logs (integration_id);