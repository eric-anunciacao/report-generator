
CREATE TABLE IF NOT EXISTS public.auto_reprocessing
(
    integration_id bigserial not null,
    strategy varchar(50) not null,
    active boolean not null,
    created_at timestamp not null,
    ignore_after_days int4 not null,
    retries int4 not null,
    minutes_to_reprocess int4,
    reprocess_schedule varchar(100),
    CONSTRAINT auto_reprocessing_pkey PRIMARY KEY (integration_id)
);

ALTER TABLE public.queue ADD COLUMN IF NOT EXISTS auto_reprocessing_retries integer null;

ALTER TABLE public.queue ADD COLUMN IF NOT EXISTS first_auto_reprocessing_retry_date timestamp null;

ALTER TABLE public.queue_logs ADD COLUMN IF NOT EXISTS is_automatic_change boolean null;
