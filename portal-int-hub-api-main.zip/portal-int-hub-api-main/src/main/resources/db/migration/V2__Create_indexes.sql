CREATE INDEX IF NOT EXISTS cluster_idx_name on cluster(name);

CREATE INDEX IF NOT EXISTS integration_idx_active on integration(active);

CREATE INDEX IF NOT EXISTS queue_idx_correlation_id on queue(correlation_id);

CREATE INDEX IF NOT EXISTS queue_idx_status on queue(status);

CREATE INDEX IF NOT EXISTS queue_logs_idx_status on queue_logs(status);

