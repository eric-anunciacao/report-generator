
ALTER TABLE public.cluster ADD COLUMN IF NOT EXISTS servers varchar(500);