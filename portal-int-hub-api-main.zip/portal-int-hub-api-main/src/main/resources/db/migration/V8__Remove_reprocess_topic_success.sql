
ALTER TABLE public.integration
    DROP COLUMN IF EXISTS reprocess_topic_success;

DO $$
BEGIN
    IF EXISTS(SELECT *
              FROM information_schema.columns
              WHERE table_name='integration' and column_name='reprocess_topic_dql')
    THEN
        alter table public.integration
            rename column reprocess_topic_dql to reprocess_topic;

    END IF;
END $$;