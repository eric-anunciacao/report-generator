CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS public.cluster (
	id bigserial NOT NULL,
	name varchar(255) NULL,
	CONSTRAINT cluster_pkey PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS public.integration (
	id bigserial NOT NULL,
	dlq_topic varchar(255) NULL,
	dt_create timestamp NULL,
	dt_update timestamp NULL,
	identifier1 varchar(255) NULL,
	identifier2 varchar(255) NULL,
	identifier3 varchar(255) NULL,
	identifier4 varchar(255) NULL,
	name varchar(255) NULL,
	reprocess_topic_dql varchar(255) NULL,
	reprocess_topic_success varchar(255) NULL,
	success_topic varchar(255) NULL,
	cluster_id int8 NULL,
	correlation_id varchar(255) NULL,
	name_integration1 varchar(255) NULL,
	name_integration2 varchar(255) NULL,
	name_integration3 varchar(255) NULL,
	name_integration4 varchar(255) NULL,
	name_identifier1 varchar(255) NULL,
	name_identifier2 varchar(255) NULL,
	name_identifier3 varchar(255) NULL,
	name_identifier4 varchar(255) NULL,
	active bool NULL DEFAULT true,
	CONSTRAINT integration_pkey PRIMARY KEY (id),
	CONSTRAINT integration_cluster_fkey FOREIGN KEY (cluster_id) REFERENCES public.cluster(id)
);

CREATE TABLE IF NOT EXISTS public.queue (
	id bigserial NOT NULL,
	correlation_id varchar(255) NULL,
	dt_event timestamp NULL,
	dt_update timestamp NULL,
	exception_cause text NULL,
	exception_class text NULL,
	exception_message text NULL,
	exception_stacktrace text NULL,
	identifier varchar(255) NULL,
	identifier2 varchar(255) NULL,
	identifier3 varchar(255) NULL,
	identifier4 varchar(255) NULL,
	key varchar(255) NULL,
	message text NULL,
	message_offset int8 NULL,
	partition int4 NULL,
	status varchar(255) NULL,
	integration_id int8 NULL,
	CONSTRAINT queue_pkey PRIMARY KEY (id),
	CONSTRAINT queue_integration_fkey FOREIGN KEY (integration_id) REFERENCES public.integration(id)
);

CREATE TABLE IF NOT EXISTS public.queue_logs (
	id bigserial NOT NULL,
	dt_event timestamp NULL,
	status varchar(255) NULL,
	id_queue int8 NOT NULL,
	CONSTRAINT queue_logs_pkey PRIMARY KEY (id),
	CONSTRAINT queue_logs_queue_fkey FOREIGN KEY (id_queue) REFERENCES public.queue(id)
);