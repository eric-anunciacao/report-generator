package br.com.hering.domain.model.integration.events;


import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.shared.DomainEvent;
import lombok.Getter;

@Getter
public class TopicConsumerChanged extends DomainEvent {
    private final transient Integration integration;
    private final Integration.TopicType topicType;
    private final Integration.ConsumerEventType eventType;
    private final String message;

    public TopicConsumerChanged(Integration integration,
                                Integration.TopicType topicType,
                                Integration.ConsumerEventType eventType,
                                String message) {
        super(integration);
        this.integration = integration;
        this.topicType = topicType;
        this.eventType = eventType;
        this.message = message;
    }
}
