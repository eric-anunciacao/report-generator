package br.com.hering.presentation.controllers.queue.request;

import br.com.hering.domain.model.queue.StatusEnum;
import lombok.Data;

@Data
public class SimulateNewQueuesRequest {
    private int quantity;
    private StatusEnum status;
    private long integrationId;
}
