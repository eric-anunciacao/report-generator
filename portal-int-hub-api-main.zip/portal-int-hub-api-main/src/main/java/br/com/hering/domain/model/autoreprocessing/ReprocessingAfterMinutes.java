package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.model.integration.IntegrationId;
import lombok.Getter;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;

@Entity(name = "ReprocessingAfterMinutes")
@DiscriminatorValue("AFTER_MINUTES")
public class ReprocessingAfterMinutes extends AutoReprocessing {

    @Getter
    @Embedded
    private MinutesToReprocess minutesToReprocess;

    protected ReprocessingAfterMinutes() {}

    private ReprocessingAfterMinutes(IntegrationId integrationId,
                                     RetryCount retries,
                                     IgnoreAfterDays ignoreAfterDays,
                                     MinutesToReprocess minutesToReprocess) {
        super(integrationId, retries, ignoreAfterDays);

        this.minutesToReprocess = minutesToReprocess;
    }

    public static ReprocessingAfterMinutes register(IntegrationId integrationId,
                           RetryCount retries,
                           IgnoreAfterDays ignoreAfterDays,
                           MinutesToReprocess minutesToReprocess) {

        return new ReprocessingAfterMinutes(
                integrationId,
                retries,
                ignoreAfterDays,
                minutesToReprocess);
    }

    @Override
    public Strategy getStrategy() {
        return Strategy.AFTER_MINUTES;
    }

    @Override
    public String configurationLabel() {
        return getConfigurationLabel(minutesToReprocess.getValue());
    }

    public static String getConfigurationLabel(int minutesToReprocess) {
        return String.format("Reprocessar após %s minutos", minutesToReprocess);
    }
}
