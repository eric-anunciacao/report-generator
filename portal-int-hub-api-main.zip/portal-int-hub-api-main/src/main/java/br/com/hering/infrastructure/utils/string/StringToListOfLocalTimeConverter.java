package br.com.hering.infrastructure.utils.string;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Converter
public class StringToListOfLocalTimeConverter implements AttributeConverter<List<LocalTime>, String> {

    @Override
    public String convertToDatabaseColumn(List<LocalTime> list) {
        return localTimeListToString(list);
    }

    public static String localTimeListToString(List<LocalTime> list) {
        if (list == null)
            return null;

        StringBuilder timeString = new StringBuilder();

        for (var time : list)
            timeString.append(time.format(DateTimeFormatter.ofPattern("HH:mm"))).append(",");

        timeString.deleteCharAt(timeString.lastIndexOf(","));

        return timeString.toString();
    }

    @Override
    public List<LocalTime> convertToEntityAttribute(String joined) {
        return stringToLocalTimeList(joined);
    }

    public static List<LocalTime> stringToLocalTimeList(String joined) {
        if (joined == null)
            return new ArrayList<>();

        List<LocalTime> list = new ArrayList<>();

        for (var time : joined.split(","))
            list.add(LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm")));


        return list;
    }
}
