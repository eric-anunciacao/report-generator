package br.com.hering.infrastructure.cleanup;

import br.com.hering.application.queue.SanitizeQueueService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import java.time.LocalDate;

@Service
public class SanitizeQueueServiceImpl implements SanitizeQueueService {
    @PersistenceContext
    private EntityManager em;

    private static final Logger logger = LoggerFactory.getLogger(SanitizeQueueServiceImpl.class);

    @Override
    public void clearOldQueuesAndLogsBefore(LocalDate date) {
        try {
            var hasMoreItemsToDelete = true;

            while (hasMoreItemsToDelete) {

                var query = em.createNativeQuery("SELECT public.partial_clear_queue_data_before(:date) as rows_affected;", Tuple.class);
                query.setParameter("date", date);

                var result = (Tuple)query.getSingleResult();

                var rowsAffected = (int)result.get("rows_affected");
                logger.info("Removed " + rowsAffected + " old queues before " + date + ".");

                Thread.sleep(2000);

                if (rowsAffected == 0)
                    hasMoreItemsToDelete = false;
            }
        } catch (InterruptedException e) {
            logger.warn("Thread interrupted!", e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            logger.error("Error removing old queues before " + date + ".", e);
        }
    }
}
