package br.com.hering.domain.queries.autoreprocessing.impl;

import br.com.hering.domain.model.autoreprocessing.AutoReprocessing;
import br.com.hering.domain.model.autoreprocessing.AutoReprocessingRepository;
import br.com.hering.domain.model.autoreprocessing.ReprocessingAfterMinutes;
import br.com.hering.domain.model.autoreprocessing.ReprocessingFixedSchedule;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.queries.autoreprocessing.AutoReprocessingQueries;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingResponseDto;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static br.com.hering.infrastructure.utils.string.StringToListOfLocalTimeConverter.stringToLocalTimeList;

@Service
public class AutoReprocessingQueriesImpl implements AutoReprocessingQueries {

    @PersistenceContext
    private EntityManager em;
    private final AutoReprocessingRepository autoReprocessingRepository;
    private final IntegrationRepository integrationRepository;

    public AutoReprocessingQueriesImpl(AutoReprocessingRepository autoReprocessingRepository,
                                       IntegrationRepository integrationRepository) {
        this.autoReprocessingRepository = autoReprocessingRepository;
        this.integrationRepository = integrationRepository;
    }

    @Override
    public List<AutoReprocessingResponseDto> findAll(Sort sort) {
        var findAllSql = findAllQuery(sort);
        var findAllQuery = em.createNativeQuery(findAllSql, Tuple.class);

        return mapAutoReprocessingList(findAllQuery.getResultList());
    }

    private List<AutoReprocessingResponseDto> mapAutoReprocessingList(List<Tuple> resultList) {
        List<AutoReprocessingResponseDto> list = new ArrayList<>(resultList.size());

        for (var tuple : resultList) {

            var integrationId = ((BigInteger)tuple.get("integration_id")).longValue();
            var integrationName = tuple.get("name").toString();
            var createdAt = ((Timestamp) tuple.get("created_at")).toLocalDateTime();
            var retries = (int) tuple.get("retries");
            var ignoreAfterDays = (int) tuple.get("ignore_after_days");
            var active = (boolean) tuple.get("active");
            var strategy = tuple.get("strategy").toString();
            var minutesToReprocess =  tuple.get("minutes_to_reprocess") == null ? 0 : (int) tuple.get("minutes_to_reprocess");
            var schedule =  tuple.get("reprocess_schedule") == null ? null : stringToLocalTimeList(tuple.get("reprocess_schedule").toString());

            var strategyEnum = AutoReprocessing.Strategy.valueOf(strategy);
            var autoReprocessing = AutoReprocessingResponseDto
                    .builder()
                    .id(integrationId)
                    .integrationId(integrationId)
                    .integrationName(integrationName)
                    .createdAt(createdAt)
                    .retries(retries)
                    .ignoreAfterDays(ignoreAfterDays)
                    .ignoreAfterDaysLabel(ignoreAfterDays + " dias")
                    .active(active)
                    .strategy(strategy)
                    .strategyDescription(strategyEnum.getLabel())
                    .minutesToReprocess(minutesToReprocess)
                    .schedule(schedule)
                    .configurationLabel(getConfigurationLabel(strategyEnum, minutesToReprocess, schedule))
                    .build();

            list.add(autoReprocessing);
        }

        return list;
    }

    private static String getConfigurationLabel(AutoReprocessing.Strategy strategy, Integer minutesToReprocess, List<LocalTime> schedule) {
        if (strategy == AutoReprocessing.Strategy.AFTER_MINUTES)
            return ReprocessingAfterMinutes.getConfigurationLabel(minutesToReprocess);

        if (strategy == AutoReprocessing.Strategy.FIXED_SCHEDULE)
            return ReprocessingFixedSchedule.getConfigurationLabel(schedule);

        throw new ResponseStatusException(HttpStatus.CONFLICT, "Strategy " + strategy + " not supported");
    }

    private String findAllQuery(Sort sort) {
        var query = " SELECT ar.integration_id, i.name, ar.created_at, ar.retries, ar.ignore_after_days, ar.active, ar.strategy, ar.minutes_to_reprocess, ar.reprocess_schedule \n" +
                    " FROM auto_reprocessing ar \n" +
                    " INNER JOIN integration i ON i.id = ar.integration_id \n" +
                    " INNER JOIN cluster c on c.id = i.cluster_id\n";

        if (!sort.isEmpty()) {
            var order = sort.get().findFirst().orElse(Sort.Order.desc("name"));
            query += "ORDER BY " + order.getProperty() + " " + order.getDirection().name() + " \n";
        }

        return query;
    }

    @Override
    public AutoReprocessingResponseDto findById(IntegrationId id) {

       var integrationName = integrationRepository.findNameById(id);

        var autoReprocessing = autoReprocessingRepository.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Auto reprocessing id %d not found", id.getValue())));
        return mapAutoReprocessing(integrationName, autoReprocessing);
    }

    private AutoReprocessingResponseDto mapAutoReprocessing(String integrationName, AutoReprocessing autoReprocessing) {
        var responseBuilder = AutoReprocessingResponseDto.builder()
                .integrationName(integrationName)
                .createdAt(autoReprocessing.getCreatedAt())
                .integrationId(autoReprocessing.getId().getValue())
                .ignoreAfterDays(autoReprocessing.getIgnoreAfterDays().getValue())
                .ignoreAfterDaysLabel(autoReprocessing.getIgnoreAfterDays().getLabel())
                .active(autoReprocessing.isActive())
                .retries(autoReprocessing.getRetries().getValue())
                .strategy(autoReprocessing.getStrategy().name())
                .strategyDescription(autoReprocessing.getStrategy().getLabel())
                .configurationLabel(autoReprocessing.configurationLabel());

        if (autoReprocessing instanceof ReprocessingFixedSchedule) {
            responseBuilder.schedule(((ReprocessingFixedSchedule) autoReprocessing).getSchedule().getItems());
        } else if (autoReprocessing instanceof ReprocessingAfterMinutes) {
            responseBuilder.minutesToReprocess(((ReprocessingAfterMinutes) autoReprocessing).getMinutesToReprocess().getValue());
        } else {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Strategy not supported");
        }

        return responseBuilder.build();
    }
}