package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.shared.ValueObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode
@Embeddable
@Getter
public class IgnoreAfterDays implements ValueObject<IgnoreAfterDays> {
    @NotNull(message="value in ignore_after_days is required")
    @Column(name = "ignore_after_days", nullable = false)
    private int value;

    protected IgnoreAfterDays() {}

    private IgnoreAfterDays(int value) {
        this.value = value;
    }

    public static IgnoreAfterDays is(int value) {

        if (value == 0)
            throw new IllegalArgumentException("IgnoreAfterDays value should not be zero");

        if (value > 7)
            throw new IllegalArgumentException("IgnoreAfterDays value should not be more than 7");

        return new IgnoreAfterDays(value);
    }

    @Override
    public boolean sameValueAs(IgnoreAfterDays other) {
        return other != null && other.equals(this);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public String getLabel() { return value + " dias"; }
}
