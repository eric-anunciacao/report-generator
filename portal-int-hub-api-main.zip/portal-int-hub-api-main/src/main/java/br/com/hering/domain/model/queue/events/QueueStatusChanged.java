package br.com.hering.domain.model.queue.events;


import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.shared.DomainEvent;
import lombok.Getter;

@Getter
public class QueueStatusChanged extends DomainEvent {
    private final transient Queue queue;
    private String message;
    private Boolean automaticChange;

    public QueueStatusChanged(Queue queue, String message, Boolean automaticChange) {
        super(queue);
        this.queue = queue;
        this.message = message;
        this.automaticChange = automaticChange;
    }
}
