package br.com.hering.domain.model.integration;

public interface IntegrationIdProvider {
    IntegrationId nextId();
}
