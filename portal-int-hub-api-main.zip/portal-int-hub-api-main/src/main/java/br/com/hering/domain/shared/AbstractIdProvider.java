package br.com.hering.domain.shared;

import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Component
public abstract class AbstractIdProvider {
    @PersistenceContext
    private EntityManager em;

    protected long nextLongId(String sequenceName) {
        var query = em.createNativeQuery("SELECT nextval(:sequenceName);");
        query.setParameter("sequenceName", sequenceName);

        return Long.parseLong(query.getSingleResult().toString());
    }
}
