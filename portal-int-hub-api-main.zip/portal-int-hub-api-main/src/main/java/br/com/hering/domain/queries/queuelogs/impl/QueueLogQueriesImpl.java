package br.com.hering.domain.queries.queuelogs.impl;

import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.domain.queries.queuelogs.QueueLogQueries;
import br.com.hering.presentation.controllers.queue.dto.QueueLogsDto;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Service
public class QueueLogQueriesImpl implements QueueLogQueries {

    @PersistenceContext
    private EntityManager em;

    @Override
    public List<QueueLogsDto> findAllByQueueId(QueueId queueId) {
        var findAllByQueueId = findAllByQueueIdSql();
        var query = em.createNativeQuery(findAllByQueueId, Tuple.class);
        query.setParameter("queueId", queueId.getValue());

        return mapFindAllByQueueId(query.getResultList());
    }

    private String findAllByQueueIdSql() {
        return "SELECT ql.id, ql.dt_event AS dtEvent, ql.status, ql.message, ql.is_automatic_change \n" +
               "FROM queue_logs ql \n" +
               "WHERE ql.id_queue = :queueId \n" +
               "order by ql.dt_event desc";
    }

    private List<QueueLogsDto> mapFindAllByQueueId(List<Tuple> resultList) {
        List<QueueLogsDto> list = new ArrayList<>(resultList.size());

        for (var tuple : resultList) {
            var id = ((BigInteger) tuple.get("id")).longValue();
            var dtEvent = ((Timestamp) tuple.get("dtEvent")).toLocalDateTime();
            var status = tuple.get("status").toString();
            var message = tuple.get("message") == null ? null : tuple.get("message").toString();
            var isAutomaticChange = tuple.get("is_automatic_change") == null ? null : (boolean)tuple.get("is_automatic_change");

            list.add(QueueLogsDto.builder()
                    .id(id)
                    .dtEvent(dtEvent)
                    .status(status)
                    .message(message)
                    .isAutomaticChange(isAutomaticChange)
                    .build());
        }

        return list;
    }
}
