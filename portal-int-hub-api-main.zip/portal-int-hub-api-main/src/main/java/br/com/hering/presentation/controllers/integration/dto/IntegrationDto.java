package br.com.hering.presentation.controllers.integration.dto;

import br.com.hering.presentation.controllers.cluster.dto.ClusterDto;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.Id;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class IntegrationDto {
    @Id
    Long id;
    String dlqTopic;
    String dlqTopicConsumerStatus;
    LocalDateTime dtCreate;
    LocalDateTime dtUpdate;
    String identifier1;
    String identifier2;
    String identifier3;
    String identifier4;
    String name;
    String reprocessTopic;
    String successTopic;
    String successTopicConsumerStatus;
    ClusterDto cluster;
    String correlationId;
    String nameIdentifier1;
    String nameIdentifier2;
    String nameIdentifier3;
    String nameIdentifier4;
    boolean active;
}