package br.com.hering.infrastructure.utils.string;

public final class InternalStringUtils {
    private InternalStringUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static String getStringValue(Object object) {
        return object == null ? null : object.toString();
    }
}
