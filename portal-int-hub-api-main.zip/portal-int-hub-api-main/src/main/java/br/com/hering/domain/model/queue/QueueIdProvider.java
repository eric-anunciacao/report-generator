package br.com.hering.domain.model.queue;

public interface QueueIdProvider {
    QueueId nextId();
}
