package br.com.hering.infrastructure.messaging.producer;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;

import static br.com.hering.infrastructure.config.KafkaConfig.producerProps;

@Slf4j
@Component
public class MultiBrokerProducer {

    private KafkaTemplate<String, String> kafkaTemplate;
    private String currentBootstrapServers;

    @Value("${spring.kafka.bootstrap-servers}")
    private String defaultBootstrapServers;

    @PostConstruct
    public void init() {
        updateKafkaTemplate(defaultBootstrapServers);
    }

    /**
     * Produtor de mensagem para algum tópico especificado
     */
    public synchronized void produceMessage(
            String bootstrapServers,
            String topic,
            String key,
            String message,
            Map<String, String> headers
    ) {
        if (kafkaTemplate == null || !bootstrapServers.equals(currentBootstrapServers))
            updateKafkaTemplate(bootstrapServers);

        log.info(String.format("Publicando mensagem %s no topico: %s", message, topic));
        var producerRecord = new ProducerRecord<>(topic, key, message);
        if (headers != null)
            headers.forEach((k, v) -> producerRecord.headers().add(k, v.getBytes()));

        kafkaTemplate.send(producerRecord);
    }

    private synchronized void updateKafkaTemplate(String bootstrapServers) {
        this.currentBootstrapServers = bootstrapServers;
        var factory = new DefaultKafkaProducerFactory<String, String>(producerProps(bootstrapServers));
        this.kafkaTemplate = new KafkaTemplate<>(factory);
    }
}