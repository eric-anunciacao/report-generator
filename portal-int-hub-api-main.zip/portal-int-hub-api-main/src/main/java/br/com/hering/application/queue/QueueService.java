package br.com.hering.application.queue;

import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.infrastructure.messaging.consumer.dto.MessageDataDto;
import br.com.hering.presentation.controllers.queue.request.UpdateQueueRequest;

import java.util.List;

public interface QueueService {
    boolean processEvent(MessageDataDto messageData);

    Queue execute(UpdateQueueRequest request);

    void reprocess(List<QueueId> ids);

    void reprocess(QueueId queueId);

    void informFailedReprocessing(QueueId queueId, String message);
}