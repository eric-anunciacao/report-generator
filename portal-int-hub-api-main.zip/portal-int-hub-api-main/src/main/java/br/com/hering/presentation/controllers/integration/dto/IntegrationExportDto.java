package br.com.hering.presentation.controllers.integration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.Id;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class IntegrationExportDto {
    @Id
    Long id;
    String name;
    String nameIdentifier1;
    String nameIdentifier2;
    String nameIdentifier3;
    String nameIdentifier4;
}

