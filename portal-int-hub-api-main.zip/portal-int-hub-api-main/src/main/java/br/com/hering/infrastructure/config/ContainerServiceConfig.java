package br.com.hering.infrastructure.config;

import br.com.hering.application.container.ContainerService;
import br.com.hering.infrastructure.broker.container.FakeTestContainerService;
import br.com.hering.infrastructure.broker.container.KafkaContainerService;
import br.com.hering.infrastructure.messaging.consumer.DefaultMessageListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class ContainerServiceConfig {

    @Value("${spring.profiles.active}")
    private String activeProfile;

    @Bean
    ContainerService containerService(@Lazy DefaultMessageListener defaultMessageListener) {

        if (activeProfile.contains("itst"))
            return new FakeTestContainerService();

        return new KafkaContainerService(defaultMessageListener);
    }
}
