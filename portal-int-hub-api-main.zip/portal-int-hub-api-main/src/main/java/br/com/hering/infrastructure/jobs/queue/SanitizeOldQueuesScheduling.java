package br.com.hering.infrastructure.jobs.queue;


import br.com.hering.application.queue.SanitizeQueueService;
import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.spring.annotations.Recurring;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Profile({"local", "dev", "hom", "prod"})
@Service
public class SanitizeOldQueuesScheduling {
    private static final Logger logger = LoggerFactory.getLogger(SanitizeOldQueuesScheduling.class);

    @Value("${cleanup.queues.months-before}")
    private int cleanUpMonthsBefore;

    private final SanitizeQueueService sanitizeQueueService;

    public SanitizeOldQueuesScheduling(SanitizeQueueService sanitizeQueueService) {
        this.sanitizeQueueService = sanitizeQueueService;
    }

    @Job(name = "Eliminate old queues")
    @Recurring(id = "sanitize-old-queues-job", cron = "30 02 * * *", zoneId = "America/Sao_Paulo") // todos os dias, às 2:30 da manhã
    public void execute() {
        var date = LocalDate.now().minusMonths(cleanUpMonthsBefore);
        logger.debug("starting SanitizeOldQueuesScheduling job. cleaning up data before " + date);
        sanitizeQueueService.clearOldQueuesAndLogsBefore(date);
        logger.debug("finishing SanitizeOldQueuesScheduling job.");
    }
}
