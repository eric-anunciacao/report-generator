package br.com.hering.domain.shared;

public @interface DomainService {
}
