package br.com.hering.domain.model.autoreprocessing.events;

import br.com.hering.domain.model.autoreprocessing.AutoReprocessing;
import br.com.hering.domain.shared.DomainEvent;

public class AutoReprocessingConfigurationInactivated extends DomainEvent {

    private final AutoReprocessing autoReprocessing;

    public AutoReprocessingConfigurationInactivated(AutoReprocessing autoReprocessing) {
        super(autoReprocessing);
        this.autoReprocessing = autoReprocessing;
    }
}
