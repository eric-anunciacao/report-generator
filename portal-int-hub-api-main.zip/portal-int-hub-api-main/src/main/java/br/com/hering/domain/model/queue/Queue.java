package br.com.hering.domain.model.queue;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.queue.events.QueueReprocessed;
import br.com.hering.domain.model.queue.events.QueueReprocessingFailed;
import br.com.hering.domain.model.queue.events.QueueStatusChanged;
import br.com.hering.domain.model.queue.events.QueueReprocessingRequested;
import br.com.hering.domain.shared.AggregateRootBase;
import br.com.hering.infrastructure.utils.json.JsonUtils;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Entity
@Table(name = "queue",
        schema = "public",
        indexes = {
                @Index(name = "queue_idx_correlation_id", columnList = "correlation_id"),
                @Index(name = "queue_idx_status", columnList = "status"),
                @Index(name = "queue_idx_dt_event_integration_id", columnList = "dt_event,integration_id"),
        }
)
@Getter
@DynamicUpdate
public class Queue extends AggregateRootBase<Queue> {
    @EmbeddedId
    @AttributeOverride(name = "value", column = @Column(name = "id", nullable = false))
    private QueueId id;

    @Column(name = "correlation_id")
    private String correlationId;

    @Column(name = "dt_event")
    private LocalDateTime dtEvent;

    @Setter
    @Column(name = "dt_update")
    private LocalDateTime dtUpdate;

    @Setter
    @Column(name = "exception_cause", columnDefinition = "TEXT")
    private String exceptionCause;

    @Setter
    @Column(name = "exception_class", columnDefinition = "TEXT")
    private String exceptionClass;

    @Setter
    @Column(name = "exception_message", columnDefinition = "TEXT")
    private String exceptionMessage;

    @Setter
    @Column(name = "exception_stacktrace", columnDefinition = "TEXT")
    private String exceptionStacktrace;

    @Setter
    private String identifier;

    @Setter
    private String identifier2;

    @Setter
    private String identifier3;

    @Setter
    private String identifier4;

    @Setter
    private String key;

    @Column(columnDefinition = "TEXT")
    private String message;

    @Setter
    @Column(name = "message_offset")
    private Long messageOffset;

    @Setter
    private Integer partition;

    private String status;

    @Embedded
    @NotNull(message = "integrationId is required")
    private IntegrationId integrationId;

    @Setter
    @Column(name = "headers")
    private String headers;

    @Setter
    @Column(name = "success_payload", columnDefinition = "TEXT")
    private String successPayload;

    @Column(name = "auto_reprocessing_retries")
    private Integer autoReprocessingRetries;

    @Column(name = "first_auto_reprocessing_retry_date")
    private LocalDateTime firstAutoReprocessingRetryDate;

    protected Queue() {
    }

    private Queue(QueueId id,
                  String correlationId,
                  LocalDateTime dtEvent,
                  String exceptionCause,
                  String exceptionClass,
                  String exceptionMessage,
                  String exceptionStacktrace,
                  String identifier,
                  String identifier2,
                  String identifier3,
                  String identifier4,
                  String key,
                  String message,
                  Long messageOffset,
                  Integer partition,
                  String status,
                  IntegrationId integrationId,
                  String headers,
                  String successPayload) {

        this.id = id;
        this.correlationId = correlationId;
        this.dtEvent = dtEvent;
        this.exceptionCause = exceptionCause;
        this.exceptionClass = exceptionClass;
        this.exceptionMessage = exceptionMessage;
        this.exceptionStacktrace = exceptionStacktrace;
        this.identifier = identifier;
        this.identifier2 = identifier2;
        this.identifier3 = identifier3;
        this.identifier4 = identifier4;
        this.key = key;
        this.message = message;
        this.messageOffset = messageOffset;
        this.partition = partition;
        this.integrationId = integrationId;
        this.headers = headers;
        this.successPayload = successPayload;

        changeStatus(status, null, null);
    }

    public static Queue.Builder newQueue(QueueId id, String correlationId, IntegrationId integrationId) {
        return new Builder(id, correlationId, integrationId);
    }

    public static Queue.Builder newQueue(QueueId id, String correlationId, IntegrationId integrationId, LocalDateTime dtEvent) {
        return new Builder(id, correlationId, integrationId, dtEvent);
    }

    public void changeStatus(String status) {
        changeStatus(status, null, isInAutomaticReprocessingFlow());
    }

    private void changeStatus(String status, String message, Boolean automaticChange) {
        this.dtUpdate = LocalDateTime.now(ZoneId.systemDefault());
        this.status = status;

        changeOrClearReprocessingData(automaticChange);

        registerEvent(new QueueStatusChanged(this, message, automaticChange));
    }

    private void changeOrClearReprocessingData(Boolean automaticChange) {
        if (Objects.equals(status, StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription())) {
            if (automaticChange != null && automaticChange) {
                changeReprocessingData();
                return;
            }

            clearReprocessingData();
        }
    }

    public void requestAutomaticReprocessing() {
        requestReprocessing(true);
    }

    public void requestManualReprocessing() {
        requestReprocessing(false);
    }

    private void requestReprocessing(boolean automaticChange) {
        changeStatus(StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription(), null, automaticChange);
        registerEvent(new QueueReprocessingRequested(this, automaticChange));
    }

    private void clearReprocessingData() {
        firstAutoReprocessingRetryDate = null;
        autoReprocessingRetries = null;
    }

    private void changeReprocessingData() {
        if (firstAutoReprocessingRetryDate == null)
            firstAutoReprocessingRetryDate = LocalDateTime.now(ZoneId.systemDefault());

        autoReprocessingRetries = autoReprocessingRetries == null ? 1 : ++autoReprocessingRetries;
    }

    public void informFailedReprocessing(String message) {
        var automatic = isInAutomaticReprocessingFlow();
        changeStatus(StatusEnum.FALHA_NO_REPROCESSAMENTO.getDescription(), message, automatic);
        registerEvent(new QueueReprocessingFailed(this, message));
    }

    public void reprocess() {
        var automatic = isInAutomaticReprocessingFlow();
        changeStatus(StatusEnum.REPROCESSADO.getDescription(), null, automatic);
        registerEvent(new QueueReprocessed(this));
    }

    public boolean isReprocessingRequested() {
        return StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription().equals(status);
    }

    public Map<String, String> getHeadersAsHashmap() {
        return headers != null ? JsonUtils.deserialize(HashMap.class, headers) : null;
    }

    public void setMessage(String message) {
        this.message = JsonUtils.prettyJsonString(message);
    }

    public boolean isInAutomaticReprocessingFlow() {
        return firstAutoReprocessingRetryDate != null;
    }

    @Override
    public boolean sameIdentityAs(Queue other) {
        return other != null && other.id.equals(this.id);
    }

    public static class Builder {
        private final String correlationId;
        private final LocalDateTime dtEvent;
        private final QueueId id;
        private String exceptionCause;
        private String exceptionClass;
        private String exceptionMessage;
        private String exceptionStacktrace;
        private String identifier;
        private String identifier2;
        private String identifier3;
        private String identifier4;
        private String key;
        private String message;
        private Long messageOffset;
        private Integer partition;
        private String status;
        private final IntegrationId integrationId;
        private String headers;
        private String successPayload;

        public Builder(QueueId id, String correlationId, IntegrationId integrationId) {
            this.id = id;
            this.correlationId = correlationId;
            this.integrationId = integrationId;
            dtEvent = LocalDateTime.now(ZoneId.systemDefault());
        }

        public Builder(QueueId id, String correlationId, IntegrationId integrationId, LocalDateTime dtEvent) {
            this.id = id;
            this.correlationId = correlationId;
            this.integrationId = integrationId;
            this.dtEvent = dtEvent;
        }

        public Builder exceptionCause(String exceptionCause) {
            this.exceptionCause = exceptionCause;
            return this;
        }

        public Builder exceptionClass(String exceptionClass) {
            this.exceptionClass = exceptionClass;
            return this;
        }

        public Builder exceptionMessage(String exceptionMessage) {
            this.exceptionMessage = exceptionMessage;
            return this;
        }

        public Builder exceptionStacktrace(String exceptionStacktrace) {
            this.exceptionStacktrace = exceptionStacktrace;
            return this;
        }

        public Builder identifier(String identifier) {
            this.identifier = identifier;
            return this;
        }

        public Builder identifier2(String identifier2) {
            this.identifier2 = identifier2;
            return this;
        }

        public Builder identifier3(String identifier3) {
            this.identifier3 = identifier3;
            return this;
        }

        public Builder identifier4(String identifier4) {
            this.identifier4 = identifier4;
            return this;
        }

        public Builder key(String key) {
            this.key = key;
            return this;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder messageOffset(Long messageOffset) {
            this.messageOffset = messageOffset;
            return this;
        }

        public Builder partition(Integer partition) {
            this.partition = partition;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder headers(String headers) {
            this.headers = headers;
            return this;
        }

        public Builder successPayload(String successPayload) {
            this.successPayload = successPayload;
            return this;
        }

        public Queue build() {
            return new Queue(id,
                    correlationId,
                    dtEvent,
                    exceptionCause,
                    exceptionClass,
                    exceptionMessage,
                    exceptionStacktrace,
                    identifier,
                    identifier2,
                    identifier3,
                    identifier4,
                    key,
                    message,
                    messageOffset,
                    partition,
                    status,
                    integrationId,
                    headers,
                    successPayload);
        }
    }
}