package br.com.hering.domain.model.queuelog;

import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.presentation.controllers.queue.dto.QueueLogsDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QueueLogsRepository extends JpaRepository<QueueLogs, Long>, JpaSpecificationExecutor<QueueLogs> {

    @Query("SELECT new br.com.hering.presentation.controllers.queue.dto.QueueLogsDto(ql.id, ql.dtEvent, ql.status, ql.message, ql.isAutomaticChange) " +
            "FROM QueueLogs ql " +
            "WHERE ql.queueId = :queueId " +
            "order by ql.dtEvent desc")
    List<QueueLogsDto> getQueueLogsByQueueId(@Param("queueId") QueueId queueId);
}