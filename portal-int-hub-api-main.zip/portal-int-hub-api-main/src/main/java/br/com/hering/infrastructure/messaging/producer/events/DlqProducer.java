package br.com.hering.infrastructure.messaging.producer.events;

import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.Map;
import java.util.concurrent.ExecutionException;

@Log4j2
@Service
public class DlqProducer {

    private final KafkaTemplate<String, String> template;

    public DlqProducer(KafkaTemplate<String, String> template) {
        this.template = template;
    }

    public boolean sendToDlq(String topicoDlq,
                             String topicoOriginal,
                             String payload,
                             String msgErro,
                             Map<String, String> headers,
                             String key) {
        try {
            produceDlq(topicoDlq, topicoOriginal, payload, msgErro, headers, key);

            log.warn("Sending payload {} to DLQ on topic {}", payload, topicoDlq);

            return true;
        } catch (InterruptedException e) {
            log.warn("Error on sending to DLQ. Interrupted!", e);
            Thread.currentThread().interrupt();
            return false;
        } catch (Exception e) {
            log.error("Ocorreram erros ao tentar enviar para o DLQ", e);
            return false;
        }
    }

    protected void produceDlq(String topicoDlq,
                              String topicoOriginal,
                              String message,
                              String msgErro,
                              Map<String, String> headers,
                              String key) throws ExecutionException, InterruptedException {

        log.debug("enviando DLQ msg='{}' topic='{}' key='{}'", message, topicoDlq, "");

        var producerRecord = new ProducerRecord(topicoDlq, key, message);
        producerRecord.headers().add(KafkaHeaders.DLT_ORIGINAL_TOPIC, topicoOriginal.getBytes());
        producerRecord.headers().add(KafkaHeaders.DLT_EXCEPTION_MESSAGE, msgErro.getBytes());

        if (headers != null)
            headers.forEach((k, v) -> producerRecord.headers().add(k, v.getBytes()));

        var future = template.send(producerRecord);

        addCallback(future);

        future.get(); //espero a resposta
    }

    protected void addCallback(ListenableFuture<SendResult<String, String>> future) {
        future.addCallback(new ListenableFutureCallback<>() {
            @Override
            public void onFailure(Throwable throwable) {
                log.error("falha envio kafka", throwable);
            }

            @Override
            public void onSuccess(SendResult<String, String> stringCentroCustoSendResult) {
                var metadata = stringCentroCustoSendResult.getRecordMetadata();
                var message = "partição " + metadata.partition() + " offset " + metadata.offset();
                log.debug("sucesso envio kafka: " + message);
            }
        });
    }
}
