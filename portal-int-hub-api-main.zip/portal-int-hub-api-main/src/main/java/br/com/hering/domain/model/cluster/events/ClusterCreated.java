package br.com.hering.domain.model.cluster.events;


import br.com.hering.domain.shared.DomainEvent;
import br.com.hering.domain.model.cluster.Cluster;
import lombok.Getter;

@Getter
public class ClusterCreated extends DomainEvent {
    private final transient Cluster cluster;

    public ClusterCreated(Cluster cluster) {
        super(cluster);
        this.cluster = cluster;
    }
}
