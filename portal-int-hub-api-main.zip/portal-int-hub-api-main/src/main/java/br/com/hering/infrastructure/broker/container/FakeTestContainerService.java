package br.com.hering.infrastructure.broker.container;

import br.com.hering.application.container.ContainerService;

public class FakeTestContainerService implements ContainerService {
    @Override
    public void createContainer(String topic, String bootstrapServers) {
        // fake
    }

    @Override
    public void stopContainer(String topic) {
        // fake
    }
}
