package br.com.hering.infrastructure.jobs.autoreprocessing;


import br.com.hering.application.autoreprocessing.AutoReprocessingService;
import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.spring.annotations.Recurring;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Profile({"local", "dev", "hom", "prod"})
@Service
public class AutoReprocessingScheduling {
    private static final Logger logger = LoggerFactory.getLogger(AutoReprocessingScheduling.class);

    private final AutoReprocessingService autoReprocessingService;

    public AutoReprocessingScheduling(AutoReprocessingService autoReprocessingService) {
        this.autoReprocessingService = autoReprocessingService;
    }

    @Job(name = "Auto Reprocessing")
    @Recurring(id = "auto-reprocessing-queues-job", cron = "*/2 * * * *", zoneId = "America/Sao_Paulo")
    public void execute() {
        logger.debug("starting AutoReprocessingScheduling job.");
        autoReprocessingService.reprocessAll(LocalDateTime.now());
        logger.debug("finishing SanitizeOldQueuesScheduling job.");
    }
}
