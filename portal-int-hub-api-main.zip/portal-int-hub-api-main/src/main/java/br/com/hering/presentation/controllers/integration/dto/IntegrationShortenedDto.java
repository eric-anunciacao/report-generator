package br.com.hering.presentation.controllers.integration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.Id;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class IntegrationShortenedDto {
    @Id
    Long id;
    String name;
    boolean active;
}

