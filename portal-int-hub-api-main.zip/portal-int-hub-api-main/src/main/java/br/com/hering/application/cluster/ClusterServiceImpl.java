package br.com.hering.application.cluster;

import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.presentation.controllers.cluster.request.CreateClusterRequest;
import br.com.hering.presentation.controllers.cluster.request.UpdateClusterRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class ClusterServiceImpl implements ClusterService {

    private final ClusterRepository clusterRepository;

    @Override
    public Cluster execute(CreateClusterRequest request) {

        var clusterId = clusterRepository.nextId();
        var cluster = Cluster.newCluster(clusterId, request.getName(), request.getServers());
        return this.clusterRepository.save(cluster);
    }

    @Override
    public Cluster execute(UpdateClusterRequest request) {
        var cluster = clusterRepository
                .findById(ClusterId.is(request.getId()))
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND,
                                String.format("Cluster with id (%d) could not be found", request.getId()))
                );

        cluster.changeName(request.getName());
        cluster.changeServers(request.getServers());

        return clusterRepository.save(cluster);
    }
}