package br.com.hering.domain.model.queue;

import br.com.hering.domain.model.integration.IntegrationId;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface QueueRepository extends JpaRepository<Queue, QueueId>, QueueIdProvider {

    Optional<Queue> findByCorrelationId(String correlationId);

    List<Queue> findByIdIn(List<QueueId> ids);

    @Query(" SELECT q FROM Queue q " +
           " WHERE (q.autoReprocessingRetries IS NULL OR q.autoReprocessingRetries <= :retries) " +
           " AND (q.dtEvent IS NULL OR q.dtEvent > :ignoreOlderThanDate) " +
           " AND q.dtUpdate < :updatedBeforeDate " +
           " AND q.status = :status" +
           " AND q.integrationId = :integrationId ")
    List<Queue> findForReprocessing(
            int retries, LocalDateTime ignoreOlderThanDate, LocalDateTime updatedBeforeDate, String status, IntegrationId integrationId, Pageable pageable);

    List<Queue> findByIntegrationIdAndAutoReprocessingRetriesNotNull(IntegrationId id);
}
