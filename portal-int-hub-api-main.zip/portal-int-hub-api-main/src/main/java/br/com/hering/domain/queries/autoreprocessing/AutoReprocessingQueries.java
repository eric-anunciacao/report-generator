package br.com.hering.domain.queries.autoreprocessing;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingResponseDto;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface AutoReprocessingQueries {
    List<AutoReprocessingResponseDto> findAll(Sort sort);
    AutoReprocessingResponseDto findById(IntegrationId id);
}
