package br.com.hering.domain.model.cluster;

import br.com.hering.domain.shared.AggregateRootBase;
import br.com.hering.domain.model.cluster.events.ClusterCreated;
import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "cluster",
        schema = "public",
        indexes = {
                @Index(name = "cluster_idx_name", columnList = "name")
        }
)
@Getter
@ToString
public class Cluster extends AggregateRootBase<Cluster> {

    @EmbeddedId
    @AttributeOverride(name = "value", column = @Column(name = "id", nullable = false))
    private ClusterId id;

    @Column(name = "name", nullable = false, length = 500)
    private String name;

    @Column(name = "servers", length = 500)
    private String servers;

    protected Cluster() { }

    private Cluster(ClusterId id, String name, String servers) {
        this.id = id;
        this.name = name;
        this.servers = servers;

        registerEvent(new ClusterCreated(this));
    }

    public static Cluster newCluster(ClusterId id, String name, String servers) {
        return new Cluster(id, name, servers);
    }

    public void changeName(String name) {
        this.name = name;
    }

    public void changeServers(String servers) {
        this.servers = servers;
    }

    @Override
    public boolean sameIdentityAs(Cluster other) {
        return other != null && other.id.equals(this.id);
    }
}