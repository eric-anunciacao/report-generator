package br.com.hering.presentation.controllers.queue.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class QueueFilterIdentifierDto {
    String type;
    List<String> values;
}