package br.com.hering.infrastructure.outbox;


import br.com.hering.infrastructure.outbox.aggregate.OutBoxAggregateOperation;
import lombok.Getter;

public enum QueueAggregate implements OutBoxAggregateOperation {
    REPROCESSING_REQUESTED("REPROCESSING_REQUESTED");

    public static final String AGGREGATE_NAME = "QUEUE";

    @Getter
    private final String operation;

    QueueAggregate(String operation) {
        this.operation = operation;
    }

    @Override
    public String aggregate() {
        return AGGREGATE_NAME;
    }

    @Override
    public String operation() {
        return operation;
    }
}
