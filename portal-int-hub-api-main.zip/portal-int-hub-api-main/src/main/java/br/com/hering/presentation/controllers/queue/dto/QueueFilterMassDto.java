package br.com.hering.presentation.controllers.queue.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Validated
public class QueueFilterMassDto {

    @NotNull
    @NotEmpty
    Long integrationId;

    String status;

    List<QueueFilterIdentifierDto> identifiers;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    String dtEventBegin;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    String dtEventEnd;

    @NotNull
    @NotEmpty
    int pageNumber;

    @NotNull
    @NotEmpty
    int pageSize;

    public List<String> getStatus() {
        if (status == null || Objects.equals(status, ""))
            return null;

        return Arrays.stream(status.split(";")).collect(Collectors.toList());
    }
}