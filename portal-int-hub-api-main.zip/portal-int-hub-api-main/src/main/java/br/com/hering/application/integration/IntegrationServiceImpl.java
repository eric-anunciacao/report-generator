package br.com.hering.application.integration;

import br.com.hering.application.container.ContainerService;
import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class IntegrationServiceImpl implements IntegrationService {
    static final Logger logger = LoggerFactory.getLogger(IntegrationServiceImpl.class);
    public static final String INTEGRATION_NOT_FOUND = "Integration with id (%d) could not be found";

    private final IntegrationRepository integrationRepository;
    private final ClusterRepository clusterRepository;
    private final ContainerService containerService;

    @Override
    public Integration save(IntegrationDto integrationDto) {
        var integrationId = integrationRepository.nextId();

        var integrationBuilder = Integration.newIntegration(integrationId, integrationDto.getName())
                .identifier1(integrationDto.getIdentifier1())
                .identifier2(integrationDto.getIdentifier2())
                .identifier3(integrationDto.getIdentifier3())
                .identifier4(integrationDto.getIdentifier4())
                .reprocessTopic(integrationDto.getReprocessTopic())
                .successTopic(integrationDto.getSuccessTopic())
                .dlqTopic(integrationDto.getDlqTopic())
                .clusterId(ClusterId.is(integrationDto.getCluster().getId()))
                .correlationId(integrationDto.getCorrelationId())
                .nameIdentifier1(integrationDto.getNameIdentifier1())
                .nameIdentifier2(integrationDto.getNameIdentifier2())
                .nameIdentifier3(integrationDto.getNameIdentifier3())
                .nameIdentifier4(integrationDto.getNameIdentifier4())
                .active(integrationDto.isActive());

        var saved = integrationRepository.save(integrationBuilder.build());

        stopOrCreateIntegrationContainers(saved);

        return saved;
    }

    @Override
    @Transactional
    public Integration update(IntegrationDto integrationDto) {

        var integration = this.integrationRepository.findById(IntegrationId.is(integrationDto.getId())).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(INTEGRATION_NOT_FOUND, integrationDto.getId())));

        integration.update(integrationDto);

        var saved = integrationRepository.save(integration);

        stopOrCreateIntegrationContainers(integration);

        return saved;
    }

    @Override
    public void deleteById(long id) {

        var integration = this.integrationRepository.findById(IntegrationId.is(id)).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(INTEGRATION_NOT_FOUND, id)));

        integration.deactivate();

        var savedIntegration = integrationRepository.save(integration);

        stopSuccessTopicConsumer(savedIntegration);
        stopDlqTopicConsumer(savedIntegration);
    }

    private void stopOrCreateIntegrationContainers(Integration integration) {
        if (integration.isActive()) {
            startSuccessTopicConsumer(integration);
            startDlqTopicConsumer(integration);
            return;
        }

        stopSuccessTopicConsumer(integration);
        stopDlqTopicConsumer(integration);
    }

    @Override
    public void startAllIntegrationsContainers() {

        var integrations = this.integrationRepository.findAll();

        integrations.forEach(integration -> {
            if (!integration.isActive()) {
                try {
                    integration.deactivateSuccessTopic();
                    integration.deactivateDlqTopic();

                    integrationRepository.save(integration);
                } catch (Exception e) {
                    logger.warn("Error saving consumer status", e);
                }

                return;
            }

            startDlqTopicConsumer(integration);
            startSuccessTopicConsumer(integration);
        });
    }

    @Override
    public void startSuccessTopicConsumer(Integration integration) {
        try {
            if (integration.successTopicExists()) {
                var cluster = clusterRepository.getReferenceById(integration.getClusterId());

                containerService.createContainer(integration.getSuccessTopic(), cluster.getServers());
                integration.startSuccessTopic();
            } else
                integration.successTopicNotFound();

            integrationRepository.save(integration);
        } catch (Exception e) {
            integration.errorStartingSuccessTopic(e.getMessage());
            integrationRepository.save(integration);

            var logMessage = String.format("Error starting Sucess topic %s Message:%s%s",
                    integration.getSuccessTopic(),
                    e.getMessage(),
                    getExceptionCause(e));

            logger.error(logMessage, e);
        }
    }

    private static String getExceptionCause(Exception e) {
        return e.getCause() != null ? " Cause: " + e.getCause().getMessage() : "";
    }

    @Override
    public void startDlqTopicConsumer(Integration integration) {
        try {
            if (integration.dlqTopicExists()) {
                var cluster = clusterRepository.getReferenceById(integration.getClusterId());

                containerService.createContainer(integration.getDlqTopic(), cluster.getServers());
                integration.startDlqTopic();
            } else
                integration.dlqTopicNotFound();

            integrationRepository.save(integration);
        } catch (Exception e) {
            integration.errorStartingDlqTopic(e.getMessage());
            integrationRepository.save(integration);

            var logMessage = String.format("Error starting DLQ topic %s Message: %s %s",
                    integration.getDlqTopic(),
                    e.getMessage(),
                    getExceptionCause(e));

            logger.error(logMessage, e);
        }
    }

    @Override
    public void stopSuccessTopicConsumer(Integration integration) {
        if (!integration.successTopicExists())
            return;

        try {
            containerService.stopContainer(integration.getSuccessTopic());

            integration.stopSuccessTopic();
            integrationRepository.save(integration);
        } catch (Exception e) {
            integration.errorStoppingSuccessTopic(e.getMessage());
            integrationRepository.save(integration);

            var logMessage = String.format("Error stopping topic consume %s Message:%s%s",
                    integration.getSuccessTopic(),
                    e.getMessage(),
                    getExceptionCause(e));

            logger.error(logMessage, e);
        }
    }

    @Override
    public void stopDlqTopicConsumer(Integration integration) {
        try {
            containerService.stopContainer(integration.getDlqTopic());

            integration.stopDlqTopic();
            integrationRepository.save(integration);
        } catch (Exception e) {
            integration.errorStoppingDlqTopic(e.getMessage());
            integrationRepository.save(integration);

            var logMessage = String.format("Error stopping topic consume %s Message:%s%s",
                    integration.getDlqTopic(),
                    e.getMessage(),
                    getExceptionCause(e));

            logger.error(logMessage, e);
        }
    }
}