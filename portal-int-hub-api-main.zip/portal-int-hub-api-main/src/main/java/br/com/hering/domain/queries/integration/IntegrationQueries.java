package br.com.hering.domain.queries.integration;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationShortenedDto;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface IntegrationQueries {
    List<IntegrationDto> findAll(Sort sort);
    List<IntegrationShortenedDto> findAllShortened(Sort sort);
    IntegrationDto findById(IntegrationId id);
}
