package br.com.hering.domain.queries.queue;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.queue.FilterMassParam;
import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.presentation.controllers.queue.dto.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface QueueQueries {
    Page<QueueSummaryDto> findAll(QueueFilterDto filter, Pageable pageable);

    Page<QueueSummaryDto> findAllMass(FilterMassParam filter, Pageable pageable);

    List<QueueExportDto> findAllToExport(IntegrationId integrationId, LocalDateTime dtEventBegin, LocalDateTime dtEventEnd);

    List<QueueStatisticsDto> getQueueStatistics(LocalDateTime dtEventBegin, LocalDateTime dtEventEnd);

    QueueDto findById(QueueId id);
}
