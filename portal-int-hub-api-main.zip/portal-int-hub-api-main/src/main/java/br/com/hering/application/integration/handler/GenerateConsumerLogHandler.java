package br.com.hering.application.integration.handler;

import br.com.hering.domain.model.integration.events.TopicConsumerChanged;
import br.com.hering.domain.shared.SubscribeTo;
import br.com.hering.infrastructure.broker.container.ConsumerLogs;
import br.com.hering.infrastructure.broker.container.ConsumerLogsRepository;
import org.springframework.stereotype.Component;

@Component
public class GenerateConsumerLogHandler implements SubscribeTo<TopicConsumerChanged> {

    private final ConsumerLogsRepository consumerLogsRepository;

    public GenerateConsumerLogHandler(ConsumerLogsRepository consumerLogsRepository) {
        this.consumerLogsRepository = consumerLogsRepository;
    }

    @Override
    public void handle(TopicConsumerChanged event) {
        var log = ConsumerLogs.builder()
                .integrationId(event.getIntegration().getId())
                .dtEvent(event.getWhen())
                .topicType(event.getTopicType())
                .eventType(event.getEventType())
                .message(event.getMessage())
                .build();

        consumerLogsRepository.save(log);
    }
}
