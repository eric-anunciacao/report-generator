package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.model.integration.IntegrationId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AutoReprocessingRepository extends JpaRepository<AutoReprocessing, IntegrationId> {
    public List<AutoReprocessing> findAllByActiveIsTrue();
}
