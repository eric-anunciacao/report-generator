package br.com.hering.infrastructure.outbox.message;

import br.com.hering.domain.model.queue.QueueId;
import lombok.Getter;

@Getter
public class QueueIdMessage {
    private final QueueId id;

    public QueueIdMessage(QueueId id) {
        this.id = id;
    }
}