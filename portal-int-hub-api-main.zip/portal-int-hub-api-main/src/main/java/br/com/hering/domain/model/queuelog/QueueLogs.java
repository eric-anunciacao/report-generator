package br.com.hering.domain.model.queuelog;

import br.com.hering.domain.model.queue.QueueId;
import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "queue_logs",
        schema = "public",
        indexes = {
                @Index(name = "queue_logs_idx_status", columnList = "status"),
                @Index(name = "queue_logs_idx_queue_id", columnList = "id_queue")
        }
)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class QueueLogs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(name = "dt_event")
    LocalDateTime dtEvent;

    String status;

    @Embedded
    @NotNull(message = "queueId is required")
    @AttributeOverride(name = "value", column = @Column(name = "id_queue", nullable = false))
    QueueId queueId;

    @Column(name = "is_automatic_change")
    Boolean isAutomaticChange;

    @Column(name = "message", length = 1000)
    String message;
}