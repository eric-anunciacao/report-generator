package br.com.hering.domain.model.cluster;


import br.com.hering.domain.shared.AbstractIdProvider;
import org.springframework.stereotype.Component;

@Component
public class ClusterIdProviderImpl extends AbstractIdProvider implements ClusterIdProvider {

    private static final String SEQUENCE = "cluster_id_seq";

    @Override
    public ClusterId nextId() {
        return ClusterId.is(super.nextLongId(SEQUENCE));
    }
}
