package br.com.hering.infrastructure.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.TimeZone;

@Configuration
public class GlobalConfig {

    @Value("${timezone}")
    private String timeZone;

    @PostConstruct
    public void setGlobalConfiguration(){
        setGlobalTimeZone();
    }

    private void setGlobalTimeZone() {
        TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
    }
}
