package br.com.hering.infrastructure.jobs.outbox;


import br.com.hering.infrastructure.outbox.OutBox;

import java.util.concurrent.ExecutionException;

public interface KafkaDispatcher {
    void dispatch(OutBox outBox) throws ExecutionException, InterruptedException;
}
