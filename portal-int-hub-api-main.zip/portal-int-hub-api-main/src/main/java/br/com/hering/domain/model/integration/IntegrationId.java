package br.com.hering.domain.model.integration;

import br.com.hering.domain.shared.ValueObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode
@Embeddable
@Getter
public class IntegrationId implements ValueObject<IntegrationId> {
    @NotNull(message="value is required")
    @Column(name = "integration_id", nullable = false)
    private long value;

    protected IntegrationId() {}

    private IntegrationId(long value) {
        this.value = value;
    }

    public static IntegrationId is(long value) {
        return new IntegrationId(value);
    }

    @Override
    public boolean sameValueAs(IntegrationId other) {
        return other != null && other.equals(this);
    }

    @Override
    public String toString() {
        return Long.toString(value);
    }
}
