package br.com.hering.application.autoreprocessing;

import br.com.hering.domain.model.autoreprocessing.*;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.domain.model.queue.StatusEnum;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingRequestDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class AutoReprocessingServiceImpl implements AutoReprocessingService {

    private final AutoReprocessingRepository autoReprocessingRepository;
    private final QueueRepository queueRepository;

    @Override
    public AutoReprocessing create(AutoReprocessingRequestDto autoReprocessingRequestDto) {

        var integrationId = IntegrationId.is(autoReprocessingRequestDto.getIntegrationId());

        var autoReprocessingExists = autoReprocessingRepository.existsById(integrationId);

        if (autoReprocessingExists)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Auto Reprocessing Configuration already exists");

        var newAutoReprocessing = createNewReprocessing(autoReprocessingRequestDto, integrationId);

        return autoReprocessingRepository.save(newAutoReprocessing);
    }

    private static AutoReprocessing createNewReprocessing(AutoReprocessingRequestDto autoReprocessingRequestDto, IntegrationId integrationId) {
        var retries = RetryCount.is(autoReprocessingRequestDto.getRetries());
        var ignoreAfterDays = IgnoreAfterDays.is(autoReprocessingRequestDto.getIgnoreAfterDays());

        AutoReprocessing newAutoReprocessing;

        if (autoReprocessingRequestDto.getStrategy() == AutoReprocessing.Strategy.AFTER_MINUTES) {
            newAutoReprocessing = ReprocessingAfterMinutes
                    .register(integrationId,
                            retries,
                            ignoreAfterDays,
                            MinutesToReprocess.is(autoReprocessingRequestDto.getMinutesToReprocess()));
        } else if (autoReprocessingRequestDto.getStrategy() == AutoReprocessing.Strategy.FIXED_SCHEDULE) {
            newAutoReprocessing = ReprocessingFixedSchedule
                    .register(integrationId,
                            retries,
                            ignoreAfterDays,
                            autoReprocessingRequestDto.getSchedule());
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Strategy not supported");
        }

        if (!autoReprocessingRequestDto.isActive())
            newAutoReprocessing.inactivate();

        return newAutoReprocessing;
    }

    @Override
    public AutoReprocessing update(IntegrationId integrationId, AutoReprocessingRequestDto autoReprocessingRequestDto) {
       var autoReprocessingExists = autoReprocessingRepository.existsById(integrationId);

        if (!autoReprocessingExists)
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Auto Reprocessing Configuration does not exist");

        autoReprocessingRepository.deleteById(integrationId);

        var newAutoReprocessing = createNewReprocessing(autoReprocessingRequestDto, integrationId);

        autoReprocessingRepository.save(newAutoReprocessing);

        return newAutoReprocessing;
    }

    @Override
    public void reprocessAll(LocalDateTime baseDateTime) {
        var activeConfigs = autoReprocessingRepository.findAllByActiveIsTrue();

        for (var config : activeConfigs) {
            var ignoreAfterDays = config.getIgnoreAfterDays();
            var retries = config.getRetries();

            var strategy = config.getStrategy();

            List<Queue> queues = List.of();

            if (strategy == AutoReprocessing.Strategy.AFTER_MINUTES) {
                var afterMinutesConfig = (ReprocessingAfterMinutes) config;
                var minutesToReprocess = afterMinutesConfig.getMinutesToReprocess().getValue();

                queues = queueRepository.findForReprocessing(
                        retries.getValue(),
                        baseDateTime.minusDays(ignoreAfterDays.getValue()),
                        baseDateTime.minusMinutes(minutesToReprocess),
                        StatusEnum.ERRO.getDescription(),
                        config.getId(),
                        PageRequest.of(0, 1000));
            } else if (strategy == AutoReprocessing.Strategy.FIXED_SCHEDULE) {
                var fixedScheduleConfig = (ReprocessingFixedSchedule) config;
                var scheduleTimeExists = fixedScheduleConfig.getNearestTimeBeforeIfExists(baseDateTime.toLocalTime());

                if (scheduleTimeExists.isPresent()) {
                    queues = queueRepository.findForReprocessing(
                            retries.getValue(),
                            baseDateTime.minusDays(ignoreAfterDays.getValue()),
                            LocalDateTime.of(baseDateTime.toLocalDate(), scheduleTimeExists.get()),
                            StatusEnum.ERRO.getDescription(),
                            config.getId(),
                            PageRequest.of(0, 1000));
                }
            } else {
                throw new NotImplementedException("strategy not found");
            }

            for (var queue : queues) {
                queue.requestAutomaticReprocessing();
                queueRepository.save(queue);
            }
        }
    }
}
