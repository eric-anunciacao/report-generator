package br.com.hering.presentation.controllers.integration;

import br.com.hering.application.integration.IntegrationService;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.queries.integration.IntegrationQueries;
import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationShortenedDto;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

@RestController
@RequestMapping({"/integration-controller", "integrations"} )
public class IntegrationController {
    private final IntegrationService integrationService;
    private final IntegrationQueries integrationQueries;

    public IntegrationController(IntegrationService integrationService,
                                 IntegrationQueries integrationQueries) {
        this.integrationService = integrationService;
        this.integrationQueries = integrationQueries;
    }

    @GetMapping
    public ResponseEntity<List<IntegrationDto>> getAllIntegration() {
        var integrationsDto = integrationQueries.findAll(Sort.by(Sort.Direction.ASC, "name"));

        return ResponseEntity.ok(integrationsDto);
    }

    @GetMapping("short")
    public ResponseEntity<List<IntegrationShortenedDto>> getAllIntegrationShortened() {
        var integrationsDto = integrationQueries.findAllShortened(Sort.by(Sort.Direction.ASC, "name"));

        return ResponseEntity.ok(integrationsDto);
    }

    @GetMapping("{id}")
    public ResponseEntity<IntegrationDto> getIntegrationById(@PathVariable long id) {
        var dto = integrationQueries.findById(IntegrationId.is(id));

        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<String> save(@RequestBody IntegrationDto integrationDto, UriComponentsBuilder uriComponentsBuilder) {
        var integration = this.integrationService.save(integrationDto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .location(uriComponentsBuilder.path("/integrations/{id}").buildAndExpand(integration.getId()).toUri())
                .build();
    }

    @PutMapping
    public ResponseEntity<String> update(@RequestBody IntegrationDto integrationDto) {
        integrationService.update(integrationDto);

        return ResponseEntity.ok().build();
    }

    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteIntegrationById(@PathVariable long id) {
        this.integrationService.deleteById(id);
    }
}