package br.com.hering.domain.model.integration.events;


import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.shared.DomainEvent;
import lombok.Getter;

@Getter
public class IntegrationUpdated extends DomainEvent {
    private final transient Integration integration;

    public IntegrationUpdated(Integration integration) {
        super(integration);
        this.integration = integration;
    }
}
