package br.com.hering.presentation.controllers.queue;

import br.com.hering.application.queue.QueueService;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.queue.FilterMassParam;
import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.domain.queries.queue.QueueQueries;
import br.com.hering.domain.queries.queuelogs.QueueLogQueries;
import br.com.hering.infrastructure.http.BadRequestException;
import br.com.hering.presentation.controllers.queue.dto.*;
import br.com.hering.presentation.controllers.queue.request.UpdateQueueRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping({"/queue-controller", "queues"})
@RequiredArgsConstructor
public class QueueController {
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final QueueService queueService;
    private final QueueQueries queueQueries;
    private final QueueLogQueries queueLogQueries;

    @GetMapping("/export/excel")
    public ResponseEntity<List<QueueExportDto>> exportToExcel(@RequestParam(name = "integrationId") Long integrationId,
                                                              @RequestParam(name = "dtEventBegin") String dtEventBegin,
                                                              @RequestParam(name = "dtEventEnd") String dtEventEnd) {

        var dateBegin = LocalDateTime.parse(dtEventBegin, DATE_TIME_FORMATTER);
        var dateEnd = LocalDateTime.parse(dtEventEnd, DATE_TIME_FORMATTER);

        validatePeriod(dateBegin, dateEnd);

        var queues = queueQueries.findAllToExport(IntegrationId.is(integrationId), dateBegin, dateEnd);

        return ResponseEntity.ok(queues);
    }

    private static void validatePeriod(LocalDateTime dateBegin, LocalDateTime dateEnd) {
        if (ChronoUnit.DAYS.between(dateBegin, dateEnd) > 31)
            throw new BadRequestException("period must be a maximum of 31 days");
    }

    @PostMapping("/filterMass")
    public ResponseEntity<Page<QueueSummaryDto>> getAllQueueMass(@RequestBody QueueFilterMassDto filter) {
        var dateBegin = LocalDateTime.parse(filter.getDtEventBegin(), DATE_TIME_FORMATTER);
        var dateEnd = LocalDateTime.parse(filter.getDtEventEnd(), DATE_TIME_FORMATTER);

        validatePeriod(dateBegin, dateEnd);

        FilterMassParam filterMassParam = FilterMassParam.builder()
                .status(filter.getStatus())
                .dtEventBegin(dateBegin)
                .dtEventEnd(dateEnd)
                .integrationId(filter.getIntegrationId())
                .identifier(getIdentifierValue(filter.getIdentifiers(), "identifier"))
                .identifier2(getIdentifierValue(filter.getIdentifiers(), "identifier2"))
                .identifier3(getIdentifierValue(filter.getIdentifiers(), "identifier3"))
                .identifier4(getIdentifierValue(filter.getIdentifiers(), "identifier4"))
                .build();

        var queues = queueQueries.findAllMass(filterMassParam,
                PageRequest.of(filter.getPageNumber(),
                        filter.getPageSize(),
                        Sort.by(Sort.Direction.DESC, "dtEvent")
                ));

        return ResponseEntity.ok(queues);
    }

    private List<String> getIdentifierValue(List<QueueFilterIdentifierDto> identifiers, String identifier) {
        return identifiers.stream()
                .filter(i -> i.getType().equals(identifier))
                .flatMap(i -> i.getValues().stream())
                .collect(Collectors.toList());

    }

    @GetMapping
    public ResponseEntity<Page<QueueSummaryDto>> getAllQueue(@RequestParam(name = "clusterId", required = false) Long clusterId,
                                                             @RequestParam(name = "integrationId", required = false) Long integrationId,
                                                             @RequestParam(name = "status", required = false) String status,
                                                             @RequestParam(name = "identifier", required = false, defaultValue = "") String identifier,
                                                             @Valid @RequestParam(name = "dtEventBegin") String dtEventBegin,
                                                             @Valid @RequestParam(name = "dtEventEnd") String dtEventEnd,
                                                             @RequestParam(name = "pageNumber", defaultValue = "0") int pageNumber,
                                                             @RequestParam(name = "pageSize", defaultValue = "10") int pageSize) {

        var dateBegin = LocalDateTime.parse(dtEventBegin, DATE_TIME_FORMATTER);
        var dateEnd = LocalDateTime.parse(dtEventEnd, DATE_TIME_FORMATTER);

        validatePeriod(dateBegin, dateEnd);

        var filterDto = new QueueFilterDto(clusterId, integrationId, status, identifier, dateBegin, dateEnd);
        var pageable = PageRequest.of(pageNumber, pageSize, Sort.by(Sort.Direction.DESC, "dtEvent"));

        return ResponseEntity.ok(queueQueries.findAll(filterDto, pageable));
    }

    @GetMapping("{id}")
    public ResponseEntity<QueueDto> getQueueById(@PathVariable long id) {
        var dto = queueQueries.findById(QueueId.is(id));

        return ResponseEntity.ok(dto);
    }

    @GetMapping(value =  {"/getAllQueueDashboard", "statistics"})
    public ResponseEntity<List<QueueStatisticsDto>> getQueueStatistics(@RequestParam(name = "dtEventBegin", required = false) String dtEventBegin,
                                                                         @RequestParam(name = "dtEventEnd", required = false) String dtEventEnd) {
        LocalDateTime dateBegin = null;
        LocalDateTime dateEnd = null;

        if (dtEventBegin != null && dtEventEnd != null) {
            dateBegin = LocalDateTime.parse(dtEventBegin, DATE_TIME_FORMATTER);
            dateEnd = LocalDateTime.parse(dtEventEnd, DATE_TIME_FORMATTER);
        }

        return ResponseEntity.ok(queueQueries.getQueueStatistics(dateBegin, dateEnd));
    }

    @GetMapping("/getQueueLogsByQueueId")
    public ResponseEntity<List<QueueLogsDto>> getQueueLogsByQueueId(@RequestParam(name = "queueId") Long queueId) {
        return ResponseEntity.ok(queueLogQueries.findAllByQueueId(QueueId.is(queueId)));
    }

    @PutMapping
    @Transactional
    public ResponseEntity<QueueDto> update(@RequestBody UpdateQueueRequest request) {
        queueService.execute(request);

        return ResponseEntity.ok().build();
    }

    @PutMapping("/update-queues")
    public ResponseEntity<String> reprocess(@RequestBody List<Long> ids) {
        var queueIds = ids.stream().map(QueueId::is).collect(Collectors.toList());

        queueService.reprocess(queueIds);

        return ResponseEntity.ok().build();
    }
}