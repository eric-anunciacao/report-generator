package br.com.hering.infrastructure.outbox;

import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.domain.shared.ValueObject;
import br.com.hering.infrastructure.outbox.aggregate.OutBoxAggregateOperation;
import br.com.hering.infrastructure.outbox.message.QueueIdMessage;
import br.com.hering.infrastructure.utils.json.InternalJsonSerializer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotNull;

@Service
public class OutBoxMessages {
    private final InternalJsonSerializer serializer;
    private final OutBoxRepository outBoxRepository;

    public OutBoxMessages(InternalJsonSerializer serializer,
                          OutBoxRepository outBoxRepository) {
        this.serializer = serializer;
        this.outBoxRepository = outBoxRepository;
    }

    public void save(OutBoxAggregateOperation operation,
                     String aggregateId,
                     Message message) {
        var outbox = OutBox.of(aggregateId, operation, message);
        outBoxRepository.save(outbox);
    }

    public Message toReprocessQueue(QueueId queueId) {
        return new Message(serializer.toJson(new QueueIdMessage(queueId)));
    }

    @EqualsAndHashCode
    @Getter
    public static class Message implements ValueObject<Message> {
        @NotNull(message = "value must not be null")
        private String value;

        private Message(String value) {
            this.value = value;
        }

        @Override
        public boolean sameValueAs(Message other) {
            return other != null && other.equals(this);
        }

        @Override
        public String toString() {
            return value;
        }
    }
}
