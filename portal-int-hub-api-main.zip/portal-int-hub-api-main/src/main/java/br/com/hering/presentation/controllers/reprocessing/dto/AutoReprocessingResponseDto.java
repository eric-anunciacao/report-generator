package br.com.hering.presentation.controllers.reprocessing.dto;


import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoReprocessingResponseDto {
    long id;
    long integrationId;
    String integrationName;
    LocalDateTime createdAt;
    int retries;
    int ignoreAfterDays;
    String ignoreAfterDaysLabel;
    String strategy;
    String strategyDescription;
    List<LocalTime> schedule;
    int minutesToReprocess;
    String configurationLabel;
    boolean active;
}