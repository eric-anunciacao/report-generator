package br.com.hering.infrastructure.messaging.consumer.events;

import br.com.hering.application.queue.QueueService;
import br.com.hering.domain.model.queue.CantReprocessQueueException;
import br.com.hering.infrastructure.config.KafkaConfig;
import br.com.hering.infrastructure.jobs.outbox.dispatcher.QueueKafkaDispatcher;
import br.com.hering.infrastructure.messaging.producer.events.DlqProducer;
import br.com.hering.infrastructure.outbox.message.QueueIdMessage;
import br.com.hering.infrastructure.utils.json.InternalJsonSerializer;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Log4j2
@Component
@Profile({ "dev", "hom", "prod", "local"})
public class ReprocessQueueConsumer {
    private final QueueService queueService;

    private final InternalJsonSerializer serializer;
    private final DlqProducer dlqProducer;
    private final KafkaConfig config;

    public static final int NACK_RETRY_SECONDS = 60;

    public ReprocessQueueConsumer(QueueService queueService, InternalJsonSerializer serializer,
                                  DlqProducer dlqProducer,
                                  KafkaConfig config) {
        this.queueService = queueService;
        this.serializer = serializer;
        this.dlqProducer = dlqProducer;
        this.config = config;
    }

    @KafkaListener(topics = "${spring.kafka.commandTopics.reprocessQueue}", groupId = "${spring.kafka.consumer.group-id}", concurrency = "3")
    public void consume(@Payload String payload,
                        Acknowledgment ack,
                        @Header(value = KafkaHeaders.RECEIVED_MESSAGE_KEY, required = false) String key,
                        @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
                        @Header(QueueKafkaDispatcher.OUTBOX_ID) String outboxId) {

        log.debug("Start consumer {}. Outbox id: {}", ReprocessQueueConsumer.class.getName(), outboxId);

        QueueIdMessage message;

        try {
            message = serializer.fromJson(payload, QueueIdMessage.class);
        } catch (Exception e) {
            var errorMessage = String.format("Fail serializing message. Message key: %s. Queue id: %s. Outbox id: %s. Payload: %s", e.getMessage(), key, outboxId, payload);
            if (dlqProducer.sendToDlq(config.getCommandTopics().getReprocessQueueDlq(), topic, payload, errorMessage, null, key))
                ack.acknowledge();
            else
                ack.nack(Duration.ofSeconds(NACK_RETRY_SECONDS));

            log.error(errorMessage, e);
            return;
        }

        var queueId = message.getId();
        try {
            queueService.reprocess(queueId);
            ack.acknowledge();
        } catch (CantReprocessQueueException e) {
            log.error(String.format("Reprocessing integration failed, sending to DLQ. Error: %s Queue id: %s. Outbox id: %s", e.getMessage(), key, outboxId), e);

            var errorMessage = String.format("Reprocessing integration failed %s. Message key: %s. Queue id: %s. Outbox id: %s", e.getMessage(), key, queueId, outboxId);
            var userFriendlyMessage = String.format("Reprocessamento com falha. Queue id: %s. Outbox id: %s", queueId, outboxId);

            if (dlqProducer.sendToDlq(config.getCommandTopics().getReprocessQueueDlq(), topic, payload, errorMessage, null, key)) {
                queueService.informFailedReprocessing(queueId, userFriendlyMessage);
                ack.acknowledge();
            }
            else
                ack.nack(Duration.ofSeconds(NACK_RETRY_SECONDS));
        } catch (KafkaException e) {
            if (e.getCause() instanceof TimeoutException) {
                log.error(String.format("Fail trying to execute reprocessing. KAFKA TIMEOUT! Error: %s. Queue Id: %s Outbox id: %s", e.getMessage(), queueId, outboxId), e);
                ack.nack(Duration.ofSeconds(NACK_RETRY_SECONDS));
            } else {
                var errorMessage = String.format("Fail trying to execute reprocessing. KAFKA ERROR! Error: %s. Queue Id: %s. Outbox id: %s", e.getMessage(), queueId, outboxId);
                log.error(errorMessage, e);

                var userFriendlyMessage = String.format("Reprocessamento com falha. Queue Id: %s. Outbox id: %s", queueId, outboxId);

                if (dlqProducer.sendToDlq(config.getCommandTopics().getReprocessQueueDlq(), topic, payload, errorMessage, null, key)) {
                    queueService.informFailedReprocessing(queueId, userFriendlyMessage);
                    ack.acknowledge();
                }
            }

        } catch (Exception e) {
            log.error("Fail trying to execute reprocessing. Error: " + e.getMessage() + ". Outbox id: " + outboxId, e);
            ack.nack(Duration.ofSeconds(NACK_RETRY_SECONDS));
        }
    }
}
