package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.shared.ValueObject;
import br.com.hering.infrastructure.utils.string.StringToListOfLocalTimeConverter;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embeddable;
import java.time.LocalTime;
import java.util.List;

import static br.com.hering.infrastructure.utils.string.StringToListOfLocalTimeConverter.localTimeListToString;

@EqualsAndHashCode
@Embeddable
@Getter
public class ReprocessSchedule implements ValueObject<ReprocessSchedule> {
    @Column(name = "reprocess_schedule", length = 100)
    @Convert(converter = StringToListOfLocalTimeConverter.class)
    private List<LocalTime> items;

    protected ReprocessSchedule() {}

    private ReprocessSchedule(List<LocalTime> items) {
        if (items.isEmpty())
            throw new IllegalArgumentException("ReprocessSchedule cannot be empty");

        if (items.size() > 10)
            throw new IllegalArgumentException("ReprocessSchedule accepts a maximum of 10 items");

        items.sort(LocalTime::compareTo);

        this.items = items;
    }

    public static ReprocessSchedule from(List<LocalTime> items) {
        return new ReprocessSchedule(items);
    }

    @Override
    public boolean sameValueAs(ReprocessSchedule other) {
        return other != null && localTimeListToString(other.items).equals(localTimeListToString(this.items));
    }

    @Override
    public String toString() {
        return localTimeListToString(items);
    }
}
