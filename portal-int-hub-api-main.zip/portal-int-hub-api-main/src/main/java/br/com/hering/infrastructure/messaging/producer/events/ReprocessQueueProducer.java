package br.com.hering.infrastructure.messaging.producer.events;


import br.com.hering.infrastructure.config.KafkaConfig;
import br.com.hering.infrastructure.utils.json.InternalJsonSerializer;
import lombok.extern.log4j.Log4j2;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.Map;
import java.util.concurrent.ExecutionException;

@Log4j2
@Service
@Profile({ "dev", "hom", "prod", "local"})
public class ReprocessQueueProducer {
    private final InternalJsonSerializer serializer;
    private final KafkaTemplate<String, String> template;
    private final KafkaConfig config;

    public ReprocessQueueProducer(InternalJsonSerializer serializer,
                                  KafkaTemplate<String, String> template,
                                  KafkaConfig config) {
        this.serializer = serializer;
        this.template = template;
        this.config = config;
    }

    public void produce(String key, Object data, Map<String, String> headers) throws ExecutionException, InterruptedException {

        var message = serializer.toJson(data);

        var topic = config.getCommandTopics().getReprocessQueue();

        var producerRecord = new ProducerRecord<>(topic, key, message);
        
        if (headers != null)
            headers.forEach((k, v) -> producerRecord.headers().add(k, v.getBytes()));

        log.debug("sending message='{}' topic='{}' key='{}'", message, topic, key);

        var future = template.send(producerRecord);

        addCallback(future);

        future.get(); //espero a resposta
    }

    protected void addCallback(ListenableFuture<SendResult<String, String>> future){
        future.addCallback(new ListenableFutureCallback<>() {
            @Override
            public void onFailure(Throwable throwable) {
                log.error("falha envio kafka", throwable);
            }
            @Override
            public void onSuccess(SendResult<String, String> stringCentroCustoSendResult) {
                var metadata = stringCentroCustoSendResult.getRecordMetadata();
                var message = "partição " + metadata.partition() + " offset " + metadata.offset();
                log.debug("sucesso envio kafka: " + message);
            }
        });
    }
}
