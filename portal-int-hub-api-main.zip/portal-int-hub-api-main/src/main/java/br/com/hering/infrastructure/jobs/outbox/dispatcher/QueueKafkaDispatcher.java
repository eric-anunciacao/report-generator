package br.com.hering.infrastructure.jobs.outbox.dispatcher;

import br.com.hering.infrastructure.jobs.outbox.KafkaDispatcher;
import br.com.hering.infrastructure.messaging.producer.events.ReprocessQueueProducer;
import br.com.hering.infrastructure.outbox.OutBox;
import br.com.hering.infrastructure.outbox.QueueAggregate;
import br.com.hering.infrastructure.outbox.message.QueueIdMessage;
import br.com.hering.infrastructure.utils.json.InternalJsonSerializer;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.concurrent.ExecutionException;

@Service
@Profile({ "dev", "hom", "prod", "local"})
public class QueueKafkaDispatcher implements KafkaDispatcher {
    public static final String OUTBOX_ID = "outbox_id";
    private final ReprocessQueueProducer producer;
    private final InternalJsonSerializer serializer;

    public QueueKafkaDispatcher(ReprocessQueueProducer producer,
                                InternalJsonSerializer serializer) {
        this.producer = producer;
        this.serializer = serializer;
    }

    @Override
    public void dispatch(OutBox outBox) throws ExecutionException, InterruptedException {
        if (!outBox.getAggregate().equalsIgnoreCase(QueueAggregate.AGGREGATE_NAME))
            throw new IllegalArgumentException("invalid outbox aggregate");

        var operation = QueueAggregate.valueOf(outBox.getOperation());

        if (operation == QueueAggregate.REPROCESSING_REQUESTED){
            var payload = serializer.fromJson(outBox.getMessage(), QueueIdMessage.class);

            var headers = new HashMap<String, String>();
            headers.put(OUTBOX_ID, outBox.getId().toString());

            producer.produce(payload.getId().toString(), payload, headers);
        }
    }
}