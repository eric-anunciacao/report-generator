package br.com.hering.presentation.controllers.queue.request;

import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import br.com.hering.presentation.controllers.queue.dto.QueueLogsDto;
import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@ToString
public class UpdateQueueRequest {
    @Id
    Long id;
    String correlationId;
    LocalDateTime dtEvent;
    LocalDateTime dtUpdate;
    String exceptionCause;
    String exceptionClass;
    String exceptionMessage;
    String exceptionStacktrace;
    String identifier;
    String identifier2;
    String identifier3;
    String identifier4;
    String key;
    String message;
    Long messageOffset;
    Integer partition;
    String status;
    IntegrationDto integration;
    List<QueueLogsDto> queueLogs = new ArrayList<>();
    String headers;
}