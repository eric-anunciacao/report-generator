package br.com.hering.infrastructure.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.StandardEnvironment;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Properties;

@Configuration
public class EnvironmentConfig implements EnvironmentAware {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void setEnvironment(Environment environment) {
        var props = new Properties();
        try {
            props.setProperty("spring.kafka.consumer.client-id", InetAddress.getLocalHost().getHostName());
            PropertiesPropertySource propertySource = new PropertiesPropertySource("myProps", props);
            if (environment instanceof StandardEnvironment) {
                ((StandardEnvironment) environment).getPropertySources().addFirst(propertySource);
            }
        } catch (UnknownHostException e) {
            logger.error("Error setting properties.", e);
        }
    }
}
