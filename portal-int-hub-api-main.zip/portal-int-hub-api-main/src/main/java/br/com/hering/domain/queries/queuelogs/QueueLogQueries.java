package br.com.hering.domain.queries.queuelogs;

import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.presentation.controllers.queue.dto.QueueLogsDto;

import java.util.List;

public interface QueueLogQueries {

    List<QueueLogsDto> findAllByQueueId(QueueId queueId);
}
