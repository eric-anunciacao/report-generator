package br.com.hering.infrastructure.utils.json;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class JsonUtils {

    private static final ObjectMapper OBJECT_MAPPER;
    private static final ObjectMapper PRETTY_OBJECT_MAPPER;

    static {
        OBJECT_MAPPER = new ObjectMapper();
        OBJECT_MAPPER.configOverride(String.class)
                .setSetterInfo(JsonSetter.Value.forValueNulls(Nulls.AS_EMPTY));
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        PRETTY_OBJECT_MAPPER = new ObjectMapper();
        PRETTY_OBJECT_MAPPER.configOverride(String.class)
                .setSetterInfo(JsonSetter.Value.forValueNulls(Nulls.AS_EMPTY));
        PRETTY_OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        PRETTY_OBJECT_MAPPER.writerWithDefaultPrettyPrinter();
    }

    public static String serialize(Object obj, boolean pretty) {
        try {
            if (pretty) {
                return PRETTY_OBJECT_MAPPER.writeValueAsString(obj);
            }
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error serializing object", e);
        }
    }

    public static <T> T deserialize(Class<T> element, String msg) {
        try {
            return OBJECT_MAPPER.readValue(msg.getBytes(StandardCharsets.UTF_8), element);
        } catch (IOException e) {
            throw new IllegalArgumentException("Error deserializing JSON string", e);
        }
    }

    public static String getJsonIdentifier(String identifierPath, String message) {
        try {
            JsonNode messageJson = OBJECT_MAPPER.readTree(message);

            if (identifierPath != null && !identifierPath.isEmpty()) {
                for (String identifierField : identifierPath.split("\\.")) {
                    messageJson = getJsonIdentifierNode(messageJson, identifierField);
                }
            }

            return messageJson != null ? messageJson.asText() : null;
        } catch (JsonProcessingException ex) {
            log.warn("Error getting identifier from identifier path {}: {}", identifierPath, ex.getMessage());
            return null;
        }
    }

    private static JsonNode getJsonIdentifierNode(JsonNode node, String identifierField) {
        if (node == null) {
            return null;
        }
        return node.get(identifierField);
    }

    public static String prettyJsonString(String jsonString) {
        try {
            return new GsonBuilder().setPrettyPrinting().create()
                    .toJson(JsonParser.parseString(jsonString).getAsJsonObject());
        } catch (Exception e) {
            log.warn("Error formatting JSON string to pretty format: {}", jsonString, e);
            return jsonString;
        }
    }
}
