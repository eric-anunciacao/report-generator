package br.com.hering.domain.model.queue;

import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class FilterMassParam {

    Long integrationId;
    List<String> status;
    List<String> identifier;
    List<String> identifier2;
    List<String> identifier3;
    List<String> identifier4;
    LocalDateTime dtEventBegin;
    LocalDateTime dtEventEnd;

    public List<String> getStatus() {
        if (Objects.isNull(status) || status.isEmpty())
            return Collections.emptyList();

        return status;
    }

    public List<String> getIdentifier() {
        if (Objects.isNull(identifier) || identifier.isEmpty())
            return Collections.emptyList();

        return identifier;
    }

    public List<String> getIdentifier2() {
        if (Objects.isNull(identifier2) || identifier2.isEmpty())
            return Collections.emptyList();

        return identifier2;
    }

    public List<String> getIdentifier3() {
        if (Objects.isNull(identifier3) || identifier3.isEmpty())
            return Collections.emptyList();

        return identifier3;
    }

    public List<String> getIdentifier4() {
        if (Objects.isNull(identifier4) || identifier4.isEmpty())
            return Collections.emptyList();

        return identifier4;
    }
}
