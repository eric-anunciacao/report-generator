package br.com.hering.presentation.controllers.queue.dto;

import br.com.hering.presentation.controllers.integration.dto.IntegrationExportDto;
import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.Id;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@ToString
public class QueueExportDto {
    @Id
    Long id;
    LocalDateTime dtEvent;
    LocalDateTime dtUpdate;
    String identifier;
    String identifier2;
    String identifier3;
    String identifier4;
    String exceptionCause;
    String exceptionMessage;
    String message;
    String status;
    IntegrationExportDto integration;
    String lastReprocessing;
}