package br.com.hering.infrastructure.outbox.aggregate;

public interface OutBoxAggregateOperation {
    String aggregate();
    String operation();
}
