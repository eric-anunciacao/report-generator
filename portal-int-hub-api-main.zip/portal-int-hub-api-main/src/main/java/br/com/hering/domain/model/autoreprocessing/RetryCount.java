package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.shared.ValueObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode
@Embeddable
@Getter
public class RetryCount implements ValueObject<RetryCount> {
    @NotNull(message="value in retry_count is required")
    @Column(name = "retries", nullable = false)
    private int value;

    protected RetryCount() {}

    private RetryCount(int value) {
        this.value = value;
    }

    public static RetryCount is(int value) {

        if (value == 0)
            throw new IllegalArgumentException("RetryCount value should not be zero");

        if (value > 100)
            throw new IllegalArgumentException("RetryCount value should not be more than 100");

        return new RetryCount(value);
    }


    @Override
    public boolean sameValueAs(RetryCount other) {
        return other != null && other.equals(this);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
