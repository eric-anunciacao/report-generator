package br.com.hering.domain.model.queue;

import lombok.Getter;

@Getter
public enum StatusEnum {
    ERRO("Erro"),
    AGUARDANDO_REPROCESSAMENTO("Aguardando reprocessamento"),
    REPROCESSADO("Reprocessado"),
    FALHA_NO_REPROCESSAMENTO("Falha no reprocessamento"),
    SUCESSO("Sucesso");

    private String description;

    StatusEnum(String description) {
        this.description = description;
    }
}
