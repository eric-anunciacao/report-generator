package br.com.hering.presentation.controllers.queue.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class QueueFilterDto {
    Long clusterId;
    Long integrationId;
    String status;
    String identifier;
    LocalDateTime dtEventBegin;
    LocalDateTime dtEventEnd;

    public List<String> getStatus() {
        if (status != null)
            return Arrays.stream(status.split(";")).collect(Collectors.toList());

        return Collections.emptyList();
    }
}