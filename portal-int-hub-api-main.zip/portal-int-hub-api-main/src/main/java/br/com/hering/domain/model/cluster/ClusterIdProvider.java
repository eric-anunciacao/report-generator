package br.com.hering.domain.model.cluster;

public interface ClusterIdProvider {
    ClusterId nextId();
}
