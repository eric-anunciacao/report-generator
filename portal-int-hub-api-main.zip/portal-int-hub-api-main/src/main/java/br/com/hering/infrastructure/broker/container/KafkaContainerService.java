package br.com.hering.infrastructure.broker.container;

import br.com.hering.application.container.ContainerService;
import br.com.hering.infrastructure.config.KafkaConfig;
import br.com.hering.infrastructure.http.NotFoundException;
import br.com.hering.infrastructure.messaging.consumer.DefaultMessageListener;
import lombok.SneakyThrows;
import org.apache.kafka.clients.admin.AdminClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;

import java.util.Map;
import java.util.concurrent.ExecutionException;

public class KafkaContainerService implements ContainerService {

    @Value("${spring.kafka.consumer.group-id}")
    private String groupId;

    private final DefaultMessageListener defaultMessageListener;

    public KafkaContainerService(@Lazy DefaultMessageListener defaultMessageListener) {
        this.defaultMessageListener = defaultMessageListener;
    }

    @SneakyThrows
    @Override
    public void createContainer(String topic, String bootstrapServers) {
        var existingContainer = KafkaConfig.getConsumersMap().get(topic);

        if (existingContainer != null) {
            existingContainer.stop();
            KafkaConfig.getConsumersMap().remove(topic);
        }

        var consumerProps = KafkaConfig.consumerProps(bootstrapServers, "dlq-portal","false", topic);
        var consumerFactory = new DefaultKafkaConsumerFactory<>(consumerProps);
        var containerProperties = new ContainerProperties(topic);
        containerProperties.setAckMode(ContainerProperties.AckMode.MANUAL);
        KafkaMessageListenerContainer<String, String> container = new KafkaMessageListenerContainer<>(consumerFactory, containerProperties);
        container.setupMessageListener(defaultMessageListener);

        verifyTopicExists(topic, consumerProps);

        KafkaConfig.getConsumersMap().put(topic, container);
        container.start();
    }

    private void verifyTopicExists(String topic, Map<String, Object> consumerProps) throws InterruptedException, ExecutionException {
        try (var kafkaAdminClient = AdminClient.create(consumerProps)) {
            var topics = kafkaAdminClient.listTopics().names().get();
            if (!topics.contains(topic))
                throw new NotFoundException("topic " + topic + " does not exist in the cluster");
        }
    }

    @Override
    public void stopContainer(String topic) {
        var container = KafkaConfig.getConsumersMap().get(topic);

        if (container == null)
            throw new NotFoundException("topic " + topic + " does not exist in consumers list");

        container.stop();

        KafkaConfig.getConsumersMap().remove(topic);
    }
}
