package br.com.hering.presentation.controllers.reprocessing;

import br.com.hering.application.autoreprocessing.AutoReprocessingService;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.queries.autoreprocessing.AutoReprocessingQueries;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingRequestDto;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingResponseDto;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

@RestController
@RequestMapping({"/auto-reprocessing-configs"} )
public class AutoReprocessingController {
    private final AutoReprocessingService autoReprocessingService;
    private final AutoReprocessingQueries autoReprocessingQueries;

    public AutoReprocessingController(AutoReprocessingService autoReprocessingService,
                                      AutoReprocessingQueries autoReprocessingQueries) {
        this.autoReprocessingService = autoReprocessingService;
        this.autoReprocessingQueries = autoReprocessingQueries;
    }

    @GetMapping
    public ResponseEntity<List<AutoReprocessingResponseDto>> findAll() {
        var autoReprocessingList = autoReprocessingQueries.findAll(Sort.by(Sort.Direction.ASC, "name"));

        return ResponseEntity.ok(autoReprocessingList);
    }

    @GetMapping("{id}")
    public ResponseEntity<AutoReprocessingResponseDto> findById(@PathVariable("id") final long id) {
        var dto = autoReprocessingQueries.findById(IntegrationId.is(id));

        return ResponseEntity.ok(dto);
    }

    @PostMapping
    public ResponseEntity<String> create(@RequestBody AutoReprocessingRequestDto autoReprocessing, UriComponentsBuilder uriComponentsBuilder) {

        var saved = autoReprocessingService.create(autoReprocessing);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .location(uriComponentsBuilder.path("/integrations/{id}").buildAndExpand(saved.getId()).toUri())
                .build();
    }

    @PutMapping("{id}")
    public ResponseEntity<String> update(@PathVariable("id") final long id, @RequestBody AutoReprocessingRequestDto autoReprocessing) {
        autoReprocessingService.update(IntegrationId.is(id), autoReprocessing);

        return ResponseEntity.ok().build();
    }
}
