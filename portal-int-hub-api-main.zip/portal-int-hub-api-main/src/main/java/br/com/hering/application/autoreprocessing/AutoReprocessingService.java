package br.com.hering.application.autoreprocessing;


import br.com.hering.domain.model.autoreprocessing.AutoReprocessing;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingRequestDto;

import java.time.LocalDateTime;

public interface AutoReprocessingService {
    AutoReprocessing create(AutoReprocessingRequestDto autoReprocessingRequestDto);
    AutoReprocessing update(IntegrationId integrationId, AutoReprocessingRequestDto autoReprocessingRequestDto);
    void reprocessAll(LocalDateTime baseDate);
}