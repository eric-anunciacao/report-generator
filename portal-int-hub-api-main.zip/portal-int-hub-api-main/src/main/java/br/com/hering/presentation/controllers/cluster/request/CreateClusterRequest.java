package br.com.hering.presentation.controllers.cluster.request;

import lombok.*;

import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateClusterRequest {
    @Id
    private Long id;
    @NotEmpty
    private String name;
    private String servers;
}