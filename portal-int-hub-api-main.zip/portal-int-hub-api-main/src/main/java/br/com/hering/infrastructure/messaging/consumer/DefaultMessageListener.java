package br.com.hering.infrastructure.messaging.consumer;

import br.com.hering.infrastructure.config.KafkaConfig;
import br.com.hering.infrastructure.http.NotFoundException;
import br.com.hering.infrastructure.messaging.consumer.dto.MessageDataDto;
import br.com.hering.application.queue.QueueService;
import br.com.hering.infrastructure.messaging.producer.events.DlqProducer;
import br.com.hering.infrastructure.utils.json.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.listener.AcknowledgingMessageListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@Profile({ "dev", "hom", "prod", "local"})
public class DefaultMessageListener implements AcknowledgingMessageListener<String, String> {

    private final QueueService queueService;
    private final DlqProducer dlqProducer;
    private final KafkaConfig config;

    private static final String HEADER_CLASS = "kafka_dlt-exception-fqcn";
    private static final String HEADER_CAUSE = "kafka_dlt-exception-cause-fqcn";
    private static final String HEADER_MESSAGE = "kafka_dlt-exception-message";
    private static final String HEADER_STACKTRACE = "kafka_dlt-exception-stacktrace";

    public DefaultMessageListener(QueueService queueService,
                                  KafkaConfig config,
                                  DlqProducer dlqProducer) {
        this.queueService = queueService;
        this.config = config;
        this.dlqProducer = dlqProducer;
    }

    @Override
    public void onMessage(ConsumerRecord<String, String> consumerRecord, Acknowledgment ack) {
        try {
            log.debug("######## MESSAGE RECEIVE BY TOPIC " + consumerRecord.topic());
            log.debug("Message received: " + consumerRecord);
            log.debug("Message value: " + consumerRecord.value());

            if (StringUtils.isBlank(consumerRecord.value())) {
                log.warn("empty message on topic {} partition {} offset {}", consumerRecord.topic(), consumerRecord.partition(), consumerRecord.offset());
                ack.acknowledge();
                return;
            }

            var messageData = extractData(consumerRecord);

            if (queueService.processEvent(messageData))
                ack.acknowledge();
        } catch (NotFoundException e) {
            log.error("######## ERROR HANDLER CONSUMER TOPIC NotFoundException " + consumerRecord.topic(), e);

            Map<String, String> headers = extractHeaders(consumerRecord);

            dlqProducer.sendToDlq(config.getCommandTopics().getProcessQueueDlq(),
                    consumerRecord.topic(),
                    consumerRecord.value(),
                    e.getMessage(),
                    headers,
                    consumerRecord.key());
            ack.acknowledge();
        } catch (Exception e) {
            log.error("######## ERROR HANDLER CONSUMER TOPIC EXCEPTION " + consumerRecord.topic(), e);
            ack.nack(Duration.ofMinutes(1));
        }
    }

    private MessageDataDto extractData(ConsumerRecord<String, String> consumerRecord) {
        var message = consumerRecord.value();

        var messageData = JsonUtils.getJsonIdentifier("originalPayload", message);

        String headersStr = null;
        String exceptionClass;
        String exceptionCause;
        String exceptionMessage;
        String exceptionStacktrace;
        String successPayload = null;

        if (messageData != null) {
            exceptionClass = JsonUtils.getJsonIdentifier("exceptionClass", message);
            exceptionCause = JsonUtils.getJsonIdentifier("exceptionCause", message);
            exceptionMessage = JsonUtils.getJsonIdentifier("exceptionMessage", message);
            exceptionStacktrace = JsonUtils.getJsonIdentifier("exceptionStacktrace", message);
            successPayload = JsonUtils.getJsonIdentifier("successPayload", message);
        } else {

            Map<String, String> headers = extractHeaders(consumerRecord);

            messageData = message;
            headersStr = JsonUtils.serialize(headers, false);
            exceptionClass = headers.get(HEADER_CLASS);
            exceptionCause = headers.get(HEADER_CAUSE);
            exceptionMessage = headers.get(HEADER_MESSAGE);
            exceptionStacktrace = headers.get(HEADER_STACKTRACE);
        }

        var key = consumerRecord.key();
        var partition = consumerRecord.partition();
        var messageOffset = consumerRecord.offset();

        return MessageDataDto.builder()
                .topic(consumerRecord.topic())
                .message(messageData)
                .headers(headersStr)
                .exceptionClass(exceptionClass)
                .exceptionCause(exceptionCause)
                .exceptionMessage(exceptionMessage)
                .exceptionStacktrace(exceptionStacktrace)
                .successPayload(successPayload)
                .key(key)
                .partition(partition)
                .messageOffset(messageOffset)
                .build();
    }

    private Map<String, String> extractHeaders(ConsumerRecord<String, String> consumerRecord) {
        Map<String, String> headers = new HashMap<>();

        for (Header header : consumerRecord.headers()) {
            headers.put(header.key(), new String(header.value(), StandardCharsets.UTF_8));
        }

        return headers;
    }
}
