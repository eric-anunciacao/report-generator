package br.com.hering.presentation.controllers.cluster;

import br.com.hering.application.cluster.ClusterService;
import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.presentation.controllers.cluster.dto.ClusterDto;
import br.com.hering.presentation.controllers.cluster.request.CreateClusterRequest;
import br.com.hering.presentation.controllers.cluster.request.UpdateClusterRequest;
import br.com.hering.domain.model.cluster.ClusterRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping({"/cluster-controller", "clusters"})
@RequiredArgsConstructor
public class ClusterController {
    static final Logger logger = LoggerFactory.getLogger(ClusterController.class);

    private final ClusterService clusterService;
    private final ClusterRepository clusterRepository;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<List<ClusterDto>> getAllCluster() {
        var clusters = this.clusterRepository.findAll(Sort.by(Sort.Direction.ASC, "name"));
        var clusterDtoList = Arrays.asList(modelMapper.map(clusters, ClusterDto[].class));

        return ResponseEntity.ok(clusterDtoList);
    }

    @GetMapping("{id}")
    public ResponseEntity<ClusterDto> getClusterById(@PathVariable long id) {
        var cluster = clusterRepository
                .findById(ClusterId.is(id))
                .orElseThrow(() ->
                        new ResponseStatusException(HttpStatus.NOT_FOUND,
                                String.format("Cluster with id (%d) could not be found", id))
                );

        var clusterDto = modelMapper.map(cluster, ClusterDto.class);

        return ResponseEntity.ok(clusterDto);
    }

    @PostMapping
    public ResponseEntity<ClusterDto> save(@RequestBody CreateClusterRequest createClusterRequest, UriComponentsBuilder uriComponentsBuilder) {

        var saved = clusterService.execute(createClusterRequest);

        var savedDto = modelMapper.map(saved, ClusterDto.class);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .location(uriComponentsBuilder.path("/api/v1/cluster/{id}").buildAndExpand(savedDto.getId()).toUri())
                .body(savedDto);
    }

    @PutMapping
    public ResponseEntity<ClusterDto> update(@RequestBody UpdateClusterRequest request) {
        var saved = clusterService.execute(request);
        var savedDto =  modelMapper.map(saved, ClusterDto.class);

        return ResponseEntity.ok(savedDto);
    }

    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteClusterById(@PathVariable long id) {
        this.clusterRepository.deleteById(ClusterId.is(id));
    }
}