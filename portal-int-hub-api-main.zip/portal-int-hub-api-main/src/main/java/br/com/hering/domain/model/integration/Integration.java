package br.com.hering.domain.model.integration;

import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.domain.model.integration.events.IntegrationCreated;
import br.com.hering.domain.model.integration.events.IntegrationUpdated;
import br.com.hering.domain.model.integration.events.TopicConsumerChanged;
import br.com.hering.domain.shared.AggregateRootBase;
import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import lombok.Getter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "integration",
        schema = "public",
        indexes = {
                @Index(name = "integration_idx_active", columnList = "active"),
                @Index(name = "integration_idx_cluster_id", columnList = "cluster_id")
        }
)
@Getter
@ToString
public class Integration extends AggregateRootBase<Integration> {
    public static final String TOPIC_STARTED_MESSAGE = "Consumo de tópico iniciado";
    public static final String TOPIC_STOPPED_MESSAGE = "Consumo de tópico interrompido";
    public static final String TOPIC_NOT_FOUND_MESSAGE = "Consumo não iniciado - tópico não cadastrado";
    public static final String STARTING_TOPIC_ERROR_MESSAGE = "Erro ao iniciar consumo de tópico %s Mensagem: %s";
    public static final String STOPPING_TOPIC_ERROR_MESSAGE = "Erro ao interromper consumo de tópico %s Mensagem: %s";
    public static final String INACTIVE_INTEGRATION_MESSAGE = "Consumer não iniciado: integração inativa";

    @EmbeddedId
    @AttributeOverride(name = "value", column = @Column(name = "id", nullable = false))
    private IntegrationId id;

    @Column(name = "dlq_topic")
    private String dlqTopic;

    @Column(name = "dlq_topic_consumer_status", length = 1000)
    private String dlqTopicConsumerStatus;

    @Column(name = "dt_create")
    @CreationTimestamp
    private LocalDateTime dtCreate;

    @Column(name = "dt_update")
    @UpdateTimestamp
    private LocalDateTime dtUpdate;

    @Column(name = "identifier1")
    private String identifier1;

    @Column(name = "identifier2")
    private String identifier2;

    @Column(name = "identifier3")
    private String identifier3;

    @Column(name = "identifier4")
    private String identifier4;

    @Column(name = "name")
    private String name;

    @Column(name = "reprocess_topic")
    private String reprocessTopic;

    @Column(name = "success_topic")
    private String successTopic;

    @Column(name = "success_topic_consumer_status", length = 1000)
    private String successTopicConsumerStatus;

    @Embedded
    @NotNull(message = "clusterId is required")
    private ClusterId clusterId;

    @Column(name = "correlation_id")
    private String correlationId;

    @Column(name = "name_identifier1")
    private String nameIdentifier1;

    @Column(name = "name_identifier2")
    private String nameIdentifier2;

    @Column(name = "name_identifier3")
    private String nameIdentifier3;

    @Column(name = "name_identifier4")
    private String nameIdentifier4;

    @Column(columnDefinition = "boolean default true", name = "active", nullable = false)
    private boolean active;

    protected Integration() {
    }

    private Integration(IntegrationId id,
                        String name,
                        String identifier1,
                        String identifier2,
                        String identifier3,
                        String identifier4,
                        String reprocessTopic,
                        String successTopic,
                        String dlqTopic,
                        ClusterId clusterId,
                        String correlationId,
                        String nameIdentifier1,
                        String nameIdentifier2,
                        String nameIdentifier3,
                        String nameIdentifier4,
                        boolean active) {

        this.id = id;
        this.name = name;
        this.identifier1 = identifier1;
        this.identifier2 = identifier2;
        this.identifier3 = identifier3;
        this.identifier4 = identifier4;
        this.reprocessTopic = reprocessTopic;
        this.successTopic = successTopic;
        this.dlqTopic = dlqTopic;
        this.clusterId = clusterId;
        this.correlationId = correlationId;
        this.nameIdentifier1 = nameIdentifier1;
        this.nameIdentifier2 = nameIdentifier2;
        this.nameIdentifier3 = nameIdentifier3;
        this.nameIdentifier4 = nameIdentifier4;
        this.active = active;

        registerEvent(new IntegrationCreated(this));
    }

    public static Builder newIntegration(IntegrationId id, String name) {
        return new Builder(id, name);
    }

    public boolean successTopicExists() {
        return successTopic != null && !successTopic.isEmpty();
    }

    public boolean dlqTopicExists() {
        return dlqTopic != null && !dlqTopic.isEmpty();
    }

    public void startSuccessTopic() {
        successTopicConsumerStatus = TOPIC_STARTED_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.START,
                TOPIC_STARTED_MESSAGE));
    }

    public void startDlqTopic() {
        dlqTopicConsumerStatus = TOPIC_STARTED_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.ERROR,
                ConsumerEventType.START,
                TOPIC_STARTED_MESSAGE));
    }

    public void stopSuccessTopic() {
        successTopicConsumerStatus = TOPIC_STOPPED_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.STOP,
                TOPIC_STOPPED_MESSAGE));
    }

    public void stopDlqTopic() {
        dlqTopicConsumerStatus = TOPIC_STOPPED_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.ERROR,
                ConsumerEventType.STOP,
                TOPIC_STOPPED_MESSAGE));
    }

    public void successTopicNotFound() {
        successTopicConsumerStatus = TOPIC_NOT_FOUND_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.NOT_FOUND_ERROR,
                TOPIC_NOT_FOUND_MESSAGE));
    }

    public void dlqTopicNotFound() {
        dlqTopicConsumerStatus = TOPIC_NOT_FOUND_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.ERROR,
                ConsumerEventType.NOT_FOUND_ERROR,
                TOPIC_NOT_FOUND_MESSAGE));
    }

    public void errorStartingSuccessTopic(String errorMessage) {
        successTopicConsumerStatus = String.format(STARTING_TOPIC_ERROR_MESSAGE, successTopic, errorMessage);
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.START_ERROR,
                successTopicConsumerStatus));
    }

    public void errorStartingDlqTopic(String errorMessage) {
        dlqTopicConsumerStatus = String.format(STARTING_TOPIC_ERROR_MESSAGE, dlqTopic, errorMessage);
        registerEvent(new TopicConsumerChanged(this,
                TopicType.ERROR,
                ConsumerEventType.START_ERROR,
                dlqTopicConsumerStatus));
    }

    public void errorStoppingSuccessTopic(String errorMessage) {
        successTopicConsumerStatus = String.format(STOPPING_TOPIC_ERROR_MESSAGE, successTopic, errorMessage);
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.STOP_ERROR,
                successTopicConsumerStatus));
    }

    public void errorStoppingDlqTopic(String errorMessage) {
        dlqTopicConsumerStatus = String.format(STOPPING_TOPIC_ERROR_MESSAGE, dlqTopic, errorMessage);
        registerEvent(new TopicConsumerChanged(this,
                TopicType.ERROR,
                ConsumerEventType.STOP_ERROR,
                dlqTopicConsumerStatus));
    }

    public void deactivateSuccessTopic() {
        successTopicConsumerStatus = INACTIVE_INTEGRATION_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.INACTIVE_INTEGRATION,
                INACTIVE_INTEGRATION_MESSAGE));
    }

    public void deactivateDlqTopic() {
        dlqTopicConsumerStatus = INACTIVE_INTEGRATION_MESSAGE;
        registerEvent(new TopicConsumerChanged(this,
                TopicType.SUCCESS,
                ConsumerEventType.INACTIVE_INTEGRATION,
                INACTIVE_INTEGRATION_MESSAGE));
    }

    public void update(IntegrationDto integrationDto) {
        dtUpdate = integrationDto.getDtUpdate();
        active = integrationDto.isActive();
        clusterId = ClusterId.is(integrationDto.getCluster().getId());
        reprocessTopic = integrationDto.getReprocessTopic();
        successTopic = integrationDto.getSuccessTopic();
        dlqTopic = integrationDto.getDlqTopic();
        correlationId = integrationDto.getCorrelationId();
        name = integrationDto.getName();
        identifier1 = integrationDto.getIdentifier1();
        identifier2 = integrationDto.getIdentifier2();
        identifier3 = integrationDto.getIdentifier3();
        identifier4 = integrationDto.getIdentifier4();
        nameIdentifier1 = integrationDto.getNameIdentifier1();
        nameIdentifier2 = integrationDto.getNameIdentifier2();
        nameIdentifier3 = integrationDto.getNameIdentifier3();
        nameIdentifier4 = integrationDto.getNameIdentifier4();

        registerEvent(new IntegrationUpdated(this));
    }

    public void deactivate() {
        active = false;
    }

    public boolean isActive() {
        return active;
    }

    @Override
    public boolean sameIdentityAs(Integration other) {
        return other != null && other.id.equals(this.id);
    }

    public static class Builder {

        private final String name;
        private final IntegrationId id;
        private String identifier1;
        private String identifier2;
        private String identifier3;
        private String identifier4;
        private String reprocessTopic;
        private String successTopic;
        private String dlqTopic;
        private ClusterId clusterId;
        private String correlationId;
        private String nameIdentifier1;
        private String nameIdentifier2;
        private String nameIdentifier3;
        private String nameIdentifier4;
        private boolean active;

        public Builder(IntegrationId id, String name) {
            this.id = id;
            this.name = name;
        }

        public Builder identifier1(String identifier1) {
            this.identifier1 = identifier1;
            return this;
        }

        public Builder identifier2(String identifier2) {
            this.identifier2 = identifier2;
            return this;
        }

        public Builder identifier3(String identifier3) {
            this.identifier3 = identifier3;
            return this;
        }

        public Builder identifier4(String identifier4) {
            this.identifier4 = identifier4;
            return this;
        }

        public Builder reprocessTopic(String reprocessTopic) {
            this.reprocessTopic = reprocessTopic;
            return this;
        }

        public Builder successTopic(String successTopic) {
            this.successTopic = successTopic;
            return this;
        }

        public Builder dlqTopic(String dlqTopic) {
            this.dlqTopic = dlqTopic;
            return this;
        }

        public Builder clusterId(ClusterId clusterId) {
            this.clusterId = clusterId;
            return this;
        }

        public Builder correlationId(String correlationId) {
            this.correlationId = correlationId;
            return this;
        }

        public Builder nameIdentifier1(String nameIdentifier1) {
            this.nameIdentifier1 = nameIdentifier1;
            return this;
        }

        public Builder nameIdentifier2(String nameIdentifier2) {
            this.nameIdentifier2 = nameIdentifier2;
            return this;
        }

        public Builder nameIdentifier3(String nameIdentifier3) {
            this.nameIdentifier3 = nameIdentifier3;
            return this;
        }

        public Builder nameIdentifier4(String nameIdentifier4) {
            this.nameIdentifier4 = nameIdentifier4;
            return this;
        }

        public Builder active(boolean active) {
            this.active = active;
            return this;
        }

        public Integration build() {

            return new Integration(
                    id,
                    name,
                    identifier1,
                    identifier2,
                    identifier3,
                    identifier4,
                    reprocessTopic,
                    successTopic,
                    dlqTopic,
                    clusterId,
                    correlationId,
                    nameIdentifier1,
                    nameIdentifier2,
                    nameIdentifier3,
                    nameIdentifier4,
                    active);
        }
    }

    public enum TopicType {
        SUCCESS,
        ERROR,
        REPROCESSING
    }

    public enum ConsumerEventType {
        START,
        STOP,
        START_ERROR,
        STOP_ERROR,
        NOT_FOUND_ERROR,
        INACTIVE_INTEGRATION
    }
}