package br.com.hering.presentation.controllers.reprocessing.dto;


import br.com.hering.domain.model.autoreprocessing.AutoReprocessing;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AutoReprocessingUpdateRequestDto {
    int retries;
    int ignoreAfterDays;
    private AutoReprocessing.Strategy strategy;
    private List<LocalTime> schedule;
    private int minutesToReprocess;
    private boolean active;
}