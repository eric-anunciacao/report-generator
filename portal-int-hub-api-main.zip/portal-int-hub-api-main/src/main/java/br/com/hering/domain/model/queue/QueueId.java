package br.com.hering.domain.model.queue;

import br.com.hering.domain.shared.ValueObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode
@Embeddable
@Getter
public class QueueId implements ValueObject<QueueId> {
    @NotNull(message="value is required")
    @Column(name = "queue_id", nullable = false)
    private long value;

    protected QueueId() {}

    private QueueId(long value) {
        this.value = value;
    }

    public static QueueId is(long value) {
        return new QueueId(value);
    }

    @Override
    public boolean sameValueAs(QueueId other) {
        return other != null && other.equals(this);
    }

    @Override
    public String toString() {
        return Long.toString(value);
    }
}
