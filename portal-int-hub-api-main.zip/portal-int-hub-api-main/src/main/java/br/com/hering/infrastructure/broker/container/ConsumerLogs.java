package br.com.hering.infrastructure.broker.container;

import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationId;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "consumer_logs",
        schema = "public",
        indexes = {
                @Index(name = "consumer_logs_idx_integration_id", columnList = "integration_id")
        }
)
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsumerLogs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message="dtEvent is required")
    @Column(name = "dt_event", nullable = false)
    private LocalDateTime dtEvent;

    @NotNull(message="topicType is required")
    @Column(name = "topic_type", nullable = false, length = 50)
    @Enumerated(EnumType.STRING)
    private Integration.TopicType topicType;

    @NotNull(message="eventType is required")
    @Column(name = "event_type", nullable = false, length = 50)
    @Enumerated(EnumType.STRING)
    private Integration.ConsumerEventType eventType;

    @Embedded
    @NotNull(message = "integrationId is required")
    private IntegrationId integrationId;

    @NotNull(message = "message is required")
    @Column(name = "message", length = 1000)
    private String message;
}