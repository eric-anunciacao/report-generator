package br.com.hering.domain.model.queue.events;


import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.shared.DomainEvent;
import lombok.Getter;

@Getter
public class QueueReprocessingRequested extends DomainEvent {
    private final transient Queue queue;
    private final transient boolean automatic;

    public QueueReprocessingRequested(Queue queue, boolean automatic) {
        super(queue);
        this.queue = queue;
        this.automatic = automatic;
    }
}
