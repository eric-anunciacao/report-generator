package br.com.hering.infrastructure.utils.json;

import lombok.Getter;

@Getter
public class AsJson<T> {

    private T object;
    private String json;

    private AsJson(T body, String json) {
        this.object = body;
        this.json = json;
    }

    public static<T> AsJson<T> create(T body, String json) {
        return new AsJson<>(body, json);
    }
}
