package br.com.hering.domain.model.queue.events;


import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.shared.DomainEvent;
import lombok.Getter;

@Getter
public class QueueReprocessingFailed extends DomainEvent {
    private final transient Queue queue;

    private final String message;

    public QueueReprocessingFailed(Queue queue, String message) {
        super(queue);
        this.queue = queue;
        this.message = message;
    }
}
