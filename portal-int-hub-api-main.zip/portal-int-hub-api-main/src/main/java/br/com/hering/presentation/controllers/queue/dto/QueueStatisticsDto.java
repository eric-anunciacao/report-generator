package br.com.hering.presentation.controllers.queue.dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueueStatisticsDto {
    private IntegrationDto integration;
    private long error;
    private long success;
    private long reprocessed;
    private long waitingReprocessing;
    private long failedReprocessing;

    @Data
    @Builder
    public static class IntegrationDto {
        private long id;
        private String name;
        private ClusterDto cluster;

        @Data
        @Builder
        public static class ClusterDto {
            private long id;
            private String name;
        }
    }
}