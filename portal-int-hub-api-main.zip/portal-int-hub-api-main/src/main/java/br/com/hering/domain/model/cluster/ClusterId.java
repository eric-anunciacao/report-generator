package br.com.hering.domain.model.cluster;

import br.com.hering.domain.shared.ValueObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode
@Embeddable
@Getter
public class ClusterId implements ValueObject<ClusterId> {
    @NotNull(message="value is required")
    @Column(name = "cluster_id", nullable = false)
    private long value;

    protected ClusterId() {}

    private ClusterId(long value) {
        this.value = value;
    }

    public static ClusterId is(long value) {
        return new ClusterId(value);
    }

    @Override
    public boolean sameValueAs(ClusterId other) {
        return other != null && other.equals(this);
    }

    @Override
    public String toString() {
        return Long.toString(value);
    }
}
