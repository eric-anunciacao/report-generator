package br.com.hering.domain.model.queue;


import br.com.hering.domain.shared.AbstractIdProvider;
import org.springframework.stereotype.Component;

@Component
public class QueueIdProviderImpl extends AbstractIdProvider implements QueueIdProvider {

    private static final String SEQUENCE = "queue_id_seq";

    @Override
    public QueueId nextId() {
        return QueueId.is(super.nextLongId(SEQUENCE));
    }
}
