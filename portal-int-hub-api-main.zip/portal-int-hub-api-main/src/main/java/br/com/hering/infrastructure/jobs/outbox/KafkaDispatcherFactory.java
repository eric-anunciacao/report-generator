package br.com.hering.infrastructure.jobs.outbox;

import br.com.hering.infrastructure.jobs.outbox.dispatcher.QueueKafkaDispatcher;
import br.com.hering.infrastructure.outbox.QueueAggregate;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.stereotype.Service;

@Service
public class KafkaDispatcherFactory {
    private final BeanFactory beanFactory;

    public KafkaDispatcherFactory(BeanFactory beanFactory) {
        this.beanFactory = beanFactory;
    }

    public KafkaDispatcher dispatcherFor(String aggregate) {
        if (aggregate.equals(QueueAggregate.AGGREGATE_NAME)) {
            return beanFactory.getBean(QueueKafkaDispatcher.class);
        }

        throw new IllegalArgumentException("dispatcher not found for aggregate: " + aggregate);
    }
}
