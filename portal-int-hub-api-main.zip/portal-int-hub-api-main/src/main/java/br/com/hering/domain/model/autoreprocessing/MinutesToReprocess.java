package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.shared.ValueObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@EqualsAndHashCode
@Embeddable
@Getter
public class MinutesToReprocess implements ValueObject<MinutesToReprocess> {
    @NotNull(message="value in minutes_to_reprocess is required")
    @Column(name = "minutes_to_reprocess")
    private int value;

    protected MinutesToReprocess() {}

    private MinutesToReprocess(int value) {
        this.value = value;
    }

    public static MinutesToReprocess is(int value) {

        if (value == 0)
            throw new IllegalArgumentException("MinutesToReprocess value should not be zero");

        if (value > 1440)
            throw new IllegalArgumentException("MinutesToReprocess value should not be more than 1440");

        return new MinutesToReprocess(value);
    }


    @Override
    public boolean sameValueAs(MinutesToReprocess other) {
        return other != null && other.equals(this);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
