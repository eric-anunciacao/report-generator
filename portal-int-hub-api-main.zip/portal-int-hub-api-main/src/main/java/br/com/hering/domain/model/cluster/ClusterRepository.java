package br.com.hering.domain.model.cluster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClusterRepository extends JpaRepository<Cluster, ClusterId>, ClusterIdProvider {
    
}
