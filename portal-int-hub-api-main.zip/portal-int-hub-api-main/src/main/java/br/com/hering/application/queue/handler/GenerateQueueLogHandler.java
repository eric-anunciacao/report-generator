package br.com.hering.application.queue.handler;

import br.com.hering.domain.model.queue.events.QueueStatusChanged;
import br.com.hering.domain.model.queuelog.QueueLogs;
import br.com.hering.domain.model.queuelog.QueueLogsRepository;
import br.com.hering.domain.shared.SubscribeTo;
import org.springframework.stereotype.Component;

@Component
public class GenerateQueueLogHandler implements SubscribeTo<QueueStatusChanged> {

    private final QueueLogsRepository queueLogsRepository;

    public GenerateQueueLogHandler(QueueLogsRepository queueLogsRepository) {
        this.queueLogsRepository = queueLogsRepository;
    }

    @Override
    public void handle(QueueStatusChanged event) {
        var log = QueueLogs.builder()
                .queueId(event.getQueue().getId())
                .dtEvent(event.getWhen())
                .status(event.getQueue().getStatus())
                .isAutomaticChange(event.getAutomaticChange())
                .message(event.getMessage())
                .build();

        queueLogsRepository.save(log);
    }
}
