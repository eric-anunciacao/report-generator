package br.com.hering.domain.model.integration;

import br.com.hering.presentation.controllers.integration.dto.IntegrationExportDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationSummaryDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IntegrationRepository extends JpaRepository<Integration, IntegrationId>, IntegrationIdProvider {
    Optional<Integration> findByDlqTopicOrSuccessTopic(String dlqTopic, String successTopic);

    @Query("SELECT new br.com.hering.presentation.controllers.integration.dto.IntegrationSummaryDto(i.id.value, i.name, i.identifier1, i.identifier2, " +
           "i.identifier3, i.identifier4, i.nameIdentifier1, i.nameIdentifier2, " +
           "i.nameIdentifier3, i.nameIdentifier4) " +
           "FROM Integration i WHERE i.id = :#{#id}")
    Optional<IntegrationSummaryDto> findSummaryById(IntegrationId id);

    @Query("SELECT new br.com.hering.presentation.controllers.integration.dto.IntegrationExportDto(i.id.value, i.name, i.nameIdentifier1, " +
           "i.nameIdentifier2, i.nameIdentifier3, i.nameIdentifier4) " +
           "FROM Integration i WHERE i.id = :#{#id}")
    Optional<IntegrationExportDto> findByIdToExport(IntegrationId id);

    @Query("SELECT i.name FROM Integration i WHERE i.id = :#{#id}")
    String findNameById(IntegrationId id);
}