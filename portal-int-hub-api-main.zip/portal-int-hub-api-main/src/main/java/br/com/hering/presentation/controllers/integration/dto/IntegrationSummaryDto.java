package br.com.hering.presentation.controllers.integration.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;

import javax.persistence.Id;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class IntegrationSummaryDto {
    @Id
    Long id;
    String name;
    String identifier1;
    String identifier2;
    String identifier3;
    String identifier4;
    String nameIdentifier1;
    String nameIdentifier2;
    String nameIdentifier3;
    String nameIdentifier4;
}

