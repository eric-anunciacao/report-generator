package br.com.hering.domain.queries.queue.impl;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.queue.*;
import br.com.hering.domain.queries.integration.IntegrationQueries;
import br.com.hering.domain.queries.queue.QueueQueries;
import br.com.hering.domain.queries.queuelogs.QueueLogQueries;
import br.com.hering.infrastructure.http.NotFoundException;
import br.com.hering.presentation.controllers.integration.dto.IntegrationExportDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationSummaryDto;
import br.com.hering.presentation.controllers.queue.dto.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.Tuple;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static br.com.hering.infrastructure.utils.string.InternalStringUtils.getStringValue;

@Service
public class QueueQueriesImpl implements QueueQueries {

    @PersistenceContext
    private EntityManager em;

    private final IntegrationRepository integrationRepository;

    private final QueueRepository queueRepository;
    private final IntegrationQueries integrationQueries;
    private final QueueLogQueries queueLogQueries;

    private static final int EXCEPTION_MSG_ABBREVIATION_LENGTH = 150;
    private static final String INTEGRATION_NOT_FOUND = "integration %s not found.";

    public QueueQueriesImpl(IntegrationRepository integrationRepository,
                            QueueRepository queueRepository,
                            IntegrationQueries integrationQueries,
                            QueueLogQueries queueLogQueries) {
        this.integrationRepository = integrationRepository;
        this.queueRepository = queueRepository;
        this.integrationQueries = integrationQueries;
        this.queueLogQueries = queueLogQueries;
    }

    @Override
    public Page<QueueSummaryDto> findAll(QueueFilterDto filter, Pageable pageable) {

        var integrationSummary = integrationRepository.findSummaryById(IntegrationId.is(filter.getIntegrationId()))
                .orElseThrow(() -> new NotFoundException(String.format(INTEGRATION_NOT_FOUND, filter.getIntegrationId())));

        var countSql = countAllQuery(filter);
        var countQuery = em.createNativeQuery(countSql);
        setFindAllParams(filter, countQuery, pageable, true);
        var totalCount = ((Number) countQuery.getSingleResult()).intValue();

        var findAllSql = findAllQuery(filter, pageable);
        var findAllQuery = em.createNativeQuery(findAllSql, Tuple.class);
        setFindAllParams(filter, findAllQuery, pageable, false);
        var resultList = mapFindAll(findAllQuery.getResultList(), integrationSummary);

        return new PageImpl<>(
                resultList,
                pageable,
                totalCount
        );
    }

    private List<QueueSummaryDto> mapFindAll(List<Tuple> resultList, IntegrationSummaryDto integrationSummary) {
        List<QueueSummaryDto> list = new ArrayList<>(resultList.size());

        for (var tuple : resultList) {
            var identifier = getStringValue(tuple.get("identifier"));
            var identifier2 = getStringValue(tuple.get("identifier2"));
            var identifier3 = getStringValue(tuple.get("identifier3"));
            var identifier4 = getStringValue(tuple.get("identifier4"));
            var dtUpdate = tuple.get("dtUpdate");
            var status = tuple.get("status").toString();

            var exceptionMessageObject = tuple.get("exceptionMessage");
            var exceptionMessage = exceptionMessageObject == null ? "" : exceptionMessageObject.toString();
            var formattedExceptionMessage = exceptionMessage.length() == EXCEPTION_MSG_ABBREVIATION_LENGTH
                    ? exceptionMessage + "..."
                    : exceptionMessage;


            var dto = QueueSummaryDto.builder()
                    .id(((BigInteger) tuple.get("id")).longValue())
                    .identifier(identifier)
                    .identifier2(identifier2)
                    .identifier3(identifier3)
                    .identifier4(identifier4)
                    .dtEvent(((Timestamp) tuple.get("dtEvent")).toLocalDateTime())
                    .dtUpdate(dtUpdate == null ? null : ((Timestamp) dtUpdate).toLocalDateTime())
                    .exceptionMessage(StringUtils.isBlank(formattedExceptionMessage) ? null : formattedExceptionMessage)
                    .status(status)
                    .integration(integrationSummary)
                    .build();

            list.add(dto);
        }

        return list;
    }

    private void setFindAllParams(QueueFilterDto filter, Query query, Pageable pageable, boolean countQuery) {

        query.setParameter("integrationId", filter.getIntegrationId());

        if (filter.getStatus() != null && !filter.getStatus().isEmpty())
            query.setParameter("statusList", filter.getStatus());

        if (StringUtils.isNotBlank(filter.getIdentifier())) {
            var identifier = "%" + filter.getIdentifier() + "%";
            query.setParameter("identifier", identifier);
        }

        if (filter.getDtEventBegin() != null && filter.getDtEventEnd() != null) {
            query.setParameter("dtEventBegin", filter.getDtEventBegin());
            query.setParameter("dtEventEnd", filter.getDtEventEnd());
        }

        if (!countQuery) {
            query.setParameter("offset", pageable.getOffset());
            query.setParameter("limit", pageable.getPageSize());
        }
    }

    private String findAllQuery(QueueFilterDto filter, Pageable pageable) {
        var sb = new StringBuilder()
                .append("SELECT q.id, q.dt_event AS dtEvent, q.dt_update AS dtUpdate, q.identifier, \n")
                .append("q.identifier2, q.identifier3, q.identifier4,\n")
                .append("LEFT(q.exception_message, " + EXCEPTION_MSG_ABBREVIATION_LENGTH + ") AS exceptionMessage, q.status \n")
                .append("FROM queue q \n")
                .append("WHERE q.integration_id = :integrationId \n");

        if (filter.getStatus() != null && !filter.getStatus().isEmpty())
            sb.append(" AND q.status IN (:statusList) \n");

        if (StringUtils.isNotBlank(filter.getIdentifier()))
            sb
                    .append(" AND (\n")
                    .append("       q.identifier ILIKE :identifier\n")
                    .append("        OR q.identifier2 ILIKE :identifier\n")
                    .append("        OR q.identifier3 ILIKE :identifier\n")
                    .append("        OR q.identifier4 ILIKE :identifier\n")
                    .append("      ) \n");


        if (filter.getDtEventBegin() != null && filter.getDtEventEnd() != null)
            sb.append(" AND (q.dt_event BETWEEN :dtEventBegin AND :dtEventEnd)\n");

        var sort = pageable.getSort();
        if (!sort.isEmpty()) {
            var order = sort.get().findFirst().orElse(Sort.Order.desc("dtEvent"));
            sb.append("ORDER BY " + order.getProperty() + " " + order.getDirection().name() + " \n");
        }

        sb.append(" OFFSET :offset LIMIT :limit \n");

        return sb.toString();
    }

    private String countAllQuery(QueueFilterDto filter) {
        var sb = new StringBuilder()
                .append("SELECT COUNT(1) \n")
                .append("FROM queue q \n")
                .append("WHERE q.integration_id = :integrationId \n");

        if (filter.getStatus() != null && !filter.getStatus().isEmpty())
            sb.append(" AND q.status IN (:statusList) \n");

        if (StringUtils.isNotBlank(filter.getIdentifier()))
            sb
                    .append(" AND (\n")
                    .append("        q.identifier ILIKE :identifier\n")
                    .append("        OR q.identifier2 ILIKE :identifier\n")
                    .append("        OR q.identifier3 ILIKE :identifier\n")
                    .append("        OR q.identifier4 ILIKE :identifier\n")
                    .append("      ) ");


        if (filter.getDtEventBegin() != null && filter.getDtEventEnd() != null)
            sb.append(" AND (q.dt_event BETWEEN :dtEventBegin AND :dtEventEnd);\n");

        return sb.toString();
    }

    @Override
    public Page<QueueSummaryDto> findAllMass(FilterMassParam filter, Pageable pageable) {
        var integrationSummary = integrationRepository.findSummaryById(IntegrationId.is(filter.getIntegrationId()))
                .orElseThrow(() -> new NotFoundException(String.format(INTEGRATION_NOT_FOUND, filter.getIntegrationId())));

        var countSql = countAllMassQuery(filter);
        var countQuery = em.createNativeQuery(countSql);
        setFindAllMassParams(filter, countQuery, pageable, true);
        var totalCount = ((Number) countQuery.getSingleResult()).intValue();

        var findAllMassSql = findAllMassQuery(filter, pageable);
        var findAllMassQuery = em.createNativeQuery(findAllMassSql, Tuple.class);
        setFindAllMassParams(filter, findAllMassQuery, pageable, false);
        var resultList = mapFindAll(findAllMassQuery.getResultList(), integrationSummary);

        return new PageImpl<>(
                resultList,
                pageable,
                totalCount
        );
    }

    private String findAllMassQuery(FilterMassParam filter, Pageable pageable) {
        var sb = new StringBuilder()
                .append("SELECT q.id, q.dt_event AS dtEvent, q.dt_update AS dtUpdate, q.identifier, \n")
                .append("q.identifier2, q.identifier3, q.identifier4,\n")
                .append("LEFT(q.exception_message, " + EXCEPTION_MSG_ABBREVIATION_LENGTH + ") AS exceptionMessage, q.status \n")
                .append("FROM queue q \n")
                .append("WHERE q.integration_id = :integrationId \n");

        if (filter.getStatus() != null && !filter.getStatus().isEmpty())
            sb.append(" AND q.status IN (:statusList) \n");

        if (filter.getIdentifier() != null && !filter.getIdentifier().isEmpty())
            sb.append(" AND q.identifier IN (:identifiers)\n");

        if (filter.getIdentifier2() != null && !filter.getIdentifier2().isEmpty())
            sb.append(" AND q.identifier2 IN (:identifiers2)\n");

        if (filter.getIdentifier3() != null && !filter.getIdentifier3().isEmpty())
            sb.append(" AND q.identifier3 IN (:identifiers3)\n");

        if (filter.getIdentifier4() != null && !filter.getIdentifier4().isEmpty())
            sb.append(" AND q.identifier4 IN (:identifiers4)\n");

        if (filter.getDtEventBegin() != null && filter.getDtEventEnd() != null)
            sb.append(" AND (q.dt_event BETWEEN :dtEventBegin AND :dtEventEnd)\n");

        var sort = pageable.getSort();
        if (!sort.isEmpty()) {
            var order = sort.get().findFirst().orElse(Sort.Order.desc("dtEvent"));
            sb.append("ORDER BY " + order.getProperty() + " " + order.getDirection().name() + " \n");
        }

        sb.append(" OFFSET :offset LIMIT :limit \n");

        return sb.toString();
    }

    private void setFindAllMassParams(FilterMassParam filter, Query query, Pageable pageable, boolean countQuery) {

        query.setParameter("integrationId", filter.getIntegrationId());

        if (filter.getStatus() != null && !filter.getStatus().isEmpty())
            query.setParameter("statusList", filter.getStatus());

        if (filter.getIdentifier() != null && !filter.getIdentifier().isEmpty())
            query.setParameter("identifiers", filter.getIdentifier());

        if (filter.getIdentifier2() != null && !filter.getIdentifier2().isEmpty())
            query.setParameter("identifiers2", filter.getIdentifier2());

        if (filter.getIdentifier3() != null && !filter.getIdentifier3().isEmpty())
            query.setParameter("identifiers3", filter.getIdentifier3());

        if (filter.getIdentifier4() != null && !filter.getIdentifier4().isEmpty())
            query.setParameter("identifiers4", filter.getIdentifier4());

        if (filter.getDtEventBegin() != null && filter.getDtEventEnd() != null) {
            query.setParameter("dtEventBegin", filter.getDtEventBegin());
            query.setParameter("dtEventEnd", filter.getDtEventEnd());
        }

        if (!countQuery) {
            query.setParameter("offset", pageable.getOffset());
            query.setParameter("limit", pageable.getPageSize());
        }
    }

    private String countAllMassQuery(FilterMassParam filter) {

        var sb = new StringBuilder()
                .append("SELECT COUNT(1) \n")
                .append("FROM queue q \n")
                .append("WHERE q.integration_id = :integrationId \n");

        if (filter.getStatus() != null && !filter.getStatus().isEmpty())
            sb.append(" AND q.status IN (:statusList) \n");

        if (filter.getIdentifier() != null && !filter.getIdentifier().isEmpty())
            sb.append(" AND q.identifier IN (:identifiers)\n");

        if (filter.getIdentifier2() != null && !filter.getIdentifier2().isEmpty())
            sb.append(" AND q.identifier2 IN (:identifiers2)\n");

        if (filter.getIdentifier3() != null && !filter.getIdentifier3().isEmpty())
            sb.append(" AND q.identifier3 IN (:identifiers3)\n");

        if (filter.getIdentifier4() != null && !filter.getIdentifier4().isEmpty())
            sb.append(" AND q.identifier4 IN (:identifiers4)\n");

        if (filter.getDtEventBegin() != null && filter.getDtEventEnd() != null)
            sb.append(" AND (q.dt_event BETWEEN :dtEventBegin AND :dtEventEnd);\n");

        return sb.toString();
    }

    @Override
    public List<QueueExportDto> findAllToExport(IntegrationId integrationId, LocalDateTime dtEventBegin, LocalDateTime dtEventEnd) {
        var integrationToExport = integrationRepository.findByIdToExport(integrationId)
                .orElseThrow(() -> new NotFoundException(String.format(INTEGRATION_NOT_FOUND, integrationId)));

        var sql = findAllToExportQuery();
        var query = em.createNativeQuery(sql, Tuple.class);
        setFindAllToExportParams(integrationId, dtEventBegin, dtEventEnd, query);

        return mapFindAllToExport(query.getResultList(), integrationToExport);
    }

    private List<QueueExportDto> mapFindAllToExport(List<Tuple> resultList, IntegrationExportDto integrationToExport) {
        List<QueueExportDto> list = new ArrayList<>(resultList.size());
        for (var tuple : resultList) {
            var id = tuple.get("id");
            var identifier = getStringValue(tuple.get("identifier"));
            var identifier2 = getStringValue(tuple.get("identifier2"));
            var identifier3 = getStringValue(tuple.get("identifier3"));
            var identifier4 = getStringValue(tuple.get("identifier4"));
            var dtEvent = tuple.get("dtEvent");
            var dtUpdate = tuple.get("dtUpdate");
            var exceptionMessage = getStringValue(tuple.get("exceptionMessage"));
            var exceptionCause = getStringValue(tuple.get("exceptionCause"));
            var message = getStringValue(tuple.get("message"));
            var status = getStringValue(tuple.get("status"));
            var lastReprocessing = getStringValue(tuple.get("last_reprocessing"));

            var dto = QueueExportDto.builder()
                    .id(((BigInteger) id).longValue())
                    .identifier(identifier)
                    .identifier2(identifier2)
                    .identifier3(identifier3)
                    .identifier4(identifier4)
                    .dtEvent(((Timestamp) dtEvent).toLocalDateTime())
                    .dtUpdate(dtUpdate == null ? null : ((Timestamp) dtUpdate).toLocalDateTime())
                    .exceptionMessage(exceptionMessage)
                    .exceptionCause(exceptionCause)
                    .message(message)
                    .status(status)
                    .integration(integrationToExport)
                    .lastReprocessing(lastReprocessing)
                    .build();

            list.add(dto);
        }

        return list;
    }

    private void setFindAllToExportParams(IntegrationId integrationId,
                                          LocalDateTime dtEventBegin,
                                          LocalDateTime dtEventEnd,
                                          Query query) {
        query.setParameter("integrationId", integrationId.getValue());
        query.setParameter("dtEventBegin", dtEventBegin);
        query.setParameter("dtEventEnd", dtEventEnd);
    }

    private String findAllToExportQuery() {

        return "SELECT q.id, q.dt_event AS dtEvent, q.dt_update AS dtUpdate, q.identifier,\n " +
               "q.identifier2, q.identifier3, q.identifier4, q.exception_cause AS exceptionCause,\n " +
               "q.exception_message AS exceptionMessage, q.message, q.status,\n " +
               "CASE\n" +
               "    WHEN q.first_auto_reprocessing_retry_date IS NULL THEN 'Manual'\n " +
               "    ELSE 'Automático'\n " +
               "END AS last_reprocessing\n " +
               "FROM queue q\n " +
               "WHERE q.integration_id = :integrationId\n " +
               "AND (q.dt_event BETWEEN :dtEventBegin AND :dtEventEnd); ";
    }

    @Override
    public List<QueueStatisticsDto> getQueueStatistics(LocalDateTime dtEventBegin, LocalDateTime dtEventEnd) {
        var sql = getQueueStatisticsQuery();
        var query = em.createNativeQuery(sql, Tuple.class);
        setQueueStatisticsQueryParams(query, dtEventBegin, dtEventEnd);
        return mapStatistics(query.getResultList());
    }

    private String getQueueStatisticsQuery() {
        return "SELECT c.id as clusterId, c.name as clusterName, i.id as integrationId, " +
               "i.name as integrationName, q.status, COUNT(1) as status_count \n" +
               "FROM queue q \n" +
               "INNER JOIN integration i ON i.id = q.integration_id \n" +
               "INNER JOIN cluster c ON c.id = i.cluster_id \n" +
               "WHERE (i.active = true) \n" +
               "AND q.dt_event BETWEEN :dtEventBegin AND :dtEventEnd \n" +
               "GROUP BY c.id, c.name, i.id, i.name, q.status \n" +
               "ORDER BY i.name";
    }

    private void setQueueStatisticsQueryParams(Query query, LocalDateTime dtEventBegin, LocalDateTime dtEventEnd) {
        query.setParameter("dtEventBegin", dtEventBegin);
        query.setParameter("dtEventEnd", dtEventEnd);
    }

    private List<QueueStatisticsDto> mapStatistics(List<Tuple> resultList) {
        List<QueueStatisticsDto> list = new ArrayList<>();

        for (var tuple : resultList) {
            var clusterId = ((BigInteger) tuple.get("clusterId")).longValue();
            var clusterName = tuple.get("clusterName").toString();

            var integrationId = ((BigInteger) tuple.get("integrationId")).longValue();
            var integrationName = tuple.get("integrationName").toString();

            var status = tuple.get("status").toString();
            var statusCount = ((BigInteger) tuple.get("status_count")).longValue();

            var itemExists = list.stream().filter(i -> i.getIntegration().getId() == integrationId).findFirst();

            QueueStatisticsDto item;

            if (itemExists.isEmpty()) {
                item = QueueStatisticsDto.builder()
                        .integration(QueueStatisticsDto.IntegrationDto.builder()
                                .cluster(QueueStatisticsDto.IntegrationDto.ClusterDto.builder()
                                        .id(clusterId)
                                        .name(clusterName)
                                        .build())
                                .id(integrationId)
                                .name(integrationName)
                                .build())
                        .build();
                setStatusCount(status, statusCount, item);

                list.add(item);
            } else {
                item = itemExists.get();

                setStatusCount(status, statusCount, item);
            }
        }

        return list;
    }

    private static void setStatusCount(String status, long statusCount, QueueStatisticsDto item) {
        if (StatusEnum.ERRO.getDescription().equals(status))
            item.setError(statusCount);
        else if (StatusEnum.SUCESSO.getDescription().equals(status))
            item.setSuccess(statusCount);
        else if (StatusEnum.REPROCESSADO.getDescription().equals(status))
            item.setReprocessed(statusCount);
        else if (StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription().equals(status))
            item.setWaitingReprocessing(statusCount);
        else if (StatusEnum.FALHA_NO_REPROCESSAMENTO.getDescription().equals(status))
            item.setFailedReprocessing(statusCount);
    }


    @Override
    public QueueDto findById(QueueId id) {
        var queue = queueRepository.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Queue with id (%s) could not be found", id)));

        var queueLogsDto = queueLogQueries.findAllByQueueId(queue.getId());

        return mapFindById(queue, queueLogsDto);
    }

    private QueueDto mapFindById(Queue queue, List<QueueLogsDto> queueLogsDto) {
        var queueDtoBuilder = QueueDto.builder()
                .id(queue.getId().getValue())
                .correlationId(queue.getCorrelationId())
                .dtEvent(queue.getDtEvent())
                .dtUpdate(queue.getDtUpdate())
                .key(queue.getKey())
                .message(queue.getMessage())
                .identifier(queue.getIdentifier())
                .identifier2(queue.getIdentifier2())
                .identifier3(queue.getIdentifier3())
                .identifier4(queue.getIdentifier4())
                .headers(queue.getHeaders())
                .messageOffset(queue.getMessageOffset())
                .correlationId(queue.getCorrelationId())
                .partition(queue.getPartition())
                .status(queue.getStatus())
                .exceptionMessage(queue.getExceptionMessage())
                .exceptionClass(queue.getExceptionClass())
                .exceptionCause(queue.getExceptionCause())
                .exceptionStacktrace(queue.getExceptionStacktrace())
                .successPayload(queue.getSuccessPayload())
                .queueLogs(queueLogsDto);

        var integrationDto = integrationQueries.findById(queue.getIntegrationId());

        queueDtoBuilder.integration(integrationDto);

        return queueDtoBuilder.build();
    }
}