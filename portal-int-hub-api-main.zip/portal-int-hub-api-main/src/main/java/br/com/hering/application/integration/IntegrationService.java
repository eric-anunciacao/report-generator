package br.com.hering.application.integration;

import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import br.com.hering.domain.model.integration.Integration;

public interface IntegrationService {

    Integration save(IntegrationDto integrationDto);

    Integration update(IntegrationDto integrationDto);

    void deleteById(long id);

    void startSuccessTopicConsumer(Integration integration);

    void startDlqTopicConsumer(Integration integration);

    void stopSuccessTopicConsumer(Integration integration);

    void stopDlqTopicConsumer(Integration integration);

    void startAllIntegrationsContainers();
}