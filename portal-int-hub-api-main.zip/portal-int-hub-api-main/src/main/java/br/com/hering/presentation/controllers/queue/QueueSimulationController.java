package br.com.hering.presentation.controllers.queue;

import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.queue.StatusEnum;
import br.com.hering.domain.queries.integration.IntegrationQueries;
import br.com.hering.infrastructure.http.NotFoundException;
import br.com.hering.infrastructure.jobs.queue.SanitizeOldQueuesScheduling;
import br.com.hering.infrastructure.messaging.producer.MultiBrokerProducer;
import br.com.hering.presentation.controllers.queue.request.SimulateNewQueuesRequest;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.UUID;

@RestController
@RequestMapping({"queues/simulate"})
@Profile({ "dev", "hom", "local"})
public class QueueSimulationController {

    private final IntegrationQueries integrationQueries;
    private final MultiBrokerProducer producer;
    private final SanitizeOldQueuesScheduling sanitizeOldQueuesScheduling;
    private final ClusterRepository clusterRepository;

    public QueueSimulationController(IntegrationQueries integrationQueries, MultiBrokerProducer producer, SanitizeOldQueuesScheduling sanitizeOldQueuesScheduling, ClusterRepository clusterRepository) {
        this.integrationQueries = integrationQueries;
        this.producer = producer;
        this.sanitizeOldQueuesScheduling = sanitizeOldQueuesScheduling;
        this.clusterRepository = clusterRepository;
    }

    @PostMapping
    public void simulateNewQueues(@RequestBody SimulateNewQueuesRequest request) {
        var integration = integrationQueries.findById(IntegrationId.is(request.getIntegrationId()));

        if (!integration.getName().equals("INTEGRAÇÃO TESTE") && !integration.getName().equals("INTEGRACAO TESTE"))
            throw new NotImplementedException("only INTEGRAÇÃO TESTE is accepted for simulation.");

        var cluster = clusterRepository.findById(ClusterId.is(integration.getCluster().getId())).orElseThrow(() -> new NotFoundException("cluster not found"));

        for (var i = 0; i < request.getQuantity(); i++) {
            var jsonString = " { \"Invoice\": { \"id\": \"{ID}\", \"nfe_key\": \"{NFE_KEY}\", \"nfe_type\": \"inbound\", \"nfe_date\": \"{NFE_DATE}\",  \"nfe_serie\": \"190\" } } ";

            var nfeKey = UUID.randomUUID().toString().toUpperCase();
            var nfeDate = LocalDateTime.now().minusHours(5).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"));

            jsonString = jsonString.replace("{NFE_KEY}", nfeKey).replace("{ID}", nfeKey).replace("{NFE_DATE}", nfeDate);

            if (request.getStatus() == StatusEnum.SUCESSO) {
                producer.produceMessage(cluster.getServers(), integration.getSuccessTopic(), nfeKey, jsonString, null);
            } else if (request.getStatus() == StatusEnum.ERRO) {

                var headers = new HashMap<String, String>();
                headers.put("kafka_dlt-exception-fqcn", "exception teste nfe " + nfeKey);
                headers.put("kafka_dlt-exception-cause-fqcn", "cause teste nfe " + nfeKey);
                headers.put("kafka_dlt-exception-message", "message teste nfe " + nfeKey);
                headers.put("kafka_dlt-exception-stacktrace", "stacktrace teste nfe " + nfeKey);

                producer.produceMessage(cluster.getServers(), integration.getDlqTopic(), nfeKey, jsonString, headers);
            } else
                throw new NotImplementedException("only ERRO and SUCESSO are accepted for simulation.");
        }
    }

    @DeleteMapping("deleteOld")
    public void deleteOld() {
        sanitizeOldQueuesScheduling.execute();
    }
}
