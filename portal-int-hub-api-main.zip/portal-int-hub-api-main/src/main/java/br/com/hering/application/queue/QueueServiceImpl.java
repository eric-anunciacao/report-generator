package br.com.hering.application.queue;

import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.queue.*;
import br.com.hering.infrastructure.http.NotFoundException;
import br.com.hering.infrastructure.messaging.consumer.dto.MessageDataDto;
import br.com.hering.infrastructure.messaging.producer.MultiBrokerProducer;
import br.com.hering.infrastructure.utils.json.JsonUtils;
import br.com.hering.presentation.controllers.queue.request.UpdateQueueRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class QueueServiceImpl implements QueueService {

    public static final String QUEUE_DOES_NOT_EXIST = "queue with id %s does not exist";
    public static final String INTEGRATION_DOES_NOT_EXIST = "integration with id %s does not exist";
    public static final String CLUSTER_DOES_NOT_EXIST = "cluster with id %s does not exist";

    private final QueueRepository queueRepository;
    private final IntegrationRepository integrationRepository;
    private final MultiBrokerProducer producer;
    private final ClusterRepository clusterRepository;

    @Override
    @Transactional
    public boolean processEvent(MessageDataDto messageData) {
        var integration = integrationRepository.findByDlqTopicOrSuccessTopic(messageData.getTopic(), messageData.getTopic()).orElseThrow(() ->
                new NotFoundException(String.format("Integration with topic (%s) could not be found", messageData.getTopic())));

        if (!integration.isActive())
            return false;

        log.info("PROCESSEVENT IN QueueServiceImpl. Integration: " + integration.getName() + "Record: " + messageData.getMessage());

        var correlationId = JsonUtils.getJsonIdentifier(integration.getCorrelationId(), messageData.getMessage()) + "_" + integration.getId();
        var status = messageData.getTopic().equals(integration.getDlqTopic()) ? StatusEnum.ERRO.getDescription() : StatusEnum.SUCESSO.getDescription();
        var identifier = JsonUtils.getJsonIdentifier(integration.getIdentifier1(), messageData.getMessage());
        var identifier2 = JsonUtils.getJsonIdentifier(integration.getIdentifier2(), messageData.getMessage());
        var identifier3 = JsonUtils.getJsonIdentifier(integration.getIdentifier3(), messageData.getMessage());
        var identifier4 = JsonUtils.getJsonIdentifier(integration.getIdentifier4(), messageData.getMessage());
        var now = LocalDateTime.now(ZoneId.systemDefault());

        var queueExist = this.queueRepository.findByCorrelationId(correlationId).orElse(null);

        //postgres não permite esse texto em campos de string
        var exceptionStacktrace = messageData.getExceptionStacktrace() == null ? null : messageData.getExceptionMessage().replaceAll("\u0000", "nulll");

        if (queueExist != null) {

            log.info("queue status: " +  queueExist.getStatus() + " last update: " + queueExist.getDtUpdate());

            queueExist.setIdentifier(identifier);
            queueExist.setIdentifier2(identifier2);
            queueExist.setIdentifier3(identifier3);
            queueExist.setIdentifier4(identifier4);
            queueExist.setKey(messageData.getKey());
            queueExist.setMessage(messageData.getMessage());
            queueExist.setPartition(messageData.getPartition());
            queueExist.setMessageOffset(messageData.getMessageOffset());
            queueExist.setExceptionClass(messageData.getExceptionClass());
            queueExist.setExceptionCause(messageData.getExceptionCause());
            queueExist.setExceptionMessage(messageData.getExceptionMessage());
            queueExist.setExceptionStacktrace(exceptionStacktrace);
            queueExist.setHeaders(messageData.getHeaders());
            queueExist.setSuccessPayload(messageData.getSuccessPayload());
            queueExist.setDtUpdate(now);

            queueExist.changeStatus(status);

            queueRepository.save(queueExist);

            return true;
        }

        var queueId = queueRepository.nextId();

        var newQueue = Queue.newQueue(queueId, correlationId, integration.getId())
                .exceptionCause(messageData.getExceptionCause())
                .exceptionClass(messageData.getExceptionClass())
                .exceptionMessage(messageData.getExceptionMessage())
                .exceptionStacktrace(exceptionStacktrace)
                .identifier(identifier)
                .identifier2(identifier2)
                .identifier3(identifier3)
                .identifier4(identifier4)
                .key(messageData.getKey())
                .message(messageData.getMessage())
                .messageOffset(messageData.getMessageOffset())
                .partition(messageData.getPartition())
                .status(status)
                .headers(messageData.getHeaders())
                .successPayload(messageData.getSuccessPayload())
                .build();

        queueRepository.save(newQueue);

        return true;
    }

    @Override
    @Transactional
    public Queue execute(UpdateQueueRequest request) {
        var queue = this.queueRepository.findById(QueueId.is(request.getId())).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("Queue with id (%d) could not be found", request.getId())));

        if (StringUtils.isBlank(request.getMessage()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "message cannot be empty");

        var now = LocalDateTime.now(ZoneId.systemDefault());

        queue.setExceptionCause(request.getExceptionCause());
        queue.setExceptionClass(request.getExceptionClass());
        queue.setExceptionMessage(request.getExceptionMessage());
        queue.setExceptionStacktrace(request.getExceptionStacktrace());
        queue.setIdentifier(request.getIdentifier());
        queue.setIdentifier2(request.getIdentifier2());
        queue.setIdentifier3(request.getIdentifier3());
        queue.setIdentifier4(request.getIdentifier4());
        queue.setKey(request.getKey());
        queue.setMessageOffset(request.getMessageOffset());
        queue.setPartition(request.getPartition());
        queue.setHeaders(request.getHeaders());
        queue.setMessage(request.getMessage());
        queue.setDtUpdate(now);

        queue.requestManualReprocessing();

        queue = this.queueRepository.save(queue);

        return queue;
    }

    @Override
    @Transactional
    public void reprocess(List<QueueId> ids) {

        List<Queue> queues = queueRepository.findByIdIn(ids);

        queues.forEach(q -> {
            var now = LocalDateTime.now(ZoneId.systemDefault());
            q.setDtUpdate(now);

            q.requestManualReprocessing();
        });

        this.queueRepository.saveAll(queues);
    }

    @Override
    @Transactional
    public void reprocess(QueueId queueId) {
        var queue = queueRepository.findById(queueId)
                .orElseThrow(() -> new CantReprocessQueueException(String.format(QUEUE_DOES_NOT_EXIST, queueId)));

        var integration = integrationRepository.findById(queue.getIntegrationId())
                .orElseThrow(() -> new CantReprocessQueueException(String.format(INTEGRATION_DOES_NOT_EXIST, queue.getIntegrationId())));

        var cluster = clusterRepository.findById(integration.getClusterId())
                .orElseThrow(() -> new CantReprocessQueueException(String.format(CLUSTER_DOES_NOT_EXIST, queue.getIntegrationId())));

        if (!queue.isReprocessingRequested())
            throw new CantReprocessQueueException(String.format("queue with id %s is not in correct status. Expected: %s Actual: %s",
                    queueId, StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription(), queue.getStatus()));

        queue.reprocess();
        queueRepository.save(queue);

        producer.produceMessage(cluster.getServers(), integration.getReprocessTopic(), queue.getKey(), queue.getMessage(), queue.getHeadersAsHashmap());
    }

    @Override
    public void informFailedReprocessing(QueueId queueId, String message) {
        var queue = queueRepository.findById(queueId)
                .orElseThrow(() -> new CantReprocessQueueException(String.format(QUEUE_DOES_NOT_EXIST, queueId)));

        queue.informFailedReprocessing(message);
        queueRepository.save(queue);
    }
}