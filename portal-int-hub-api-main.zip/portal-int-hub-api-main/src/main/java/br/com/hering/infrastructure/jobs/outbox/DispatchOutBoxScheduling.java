package br.com.hering.infrastructure.jobs.outbox;

import br.com.hering.infrastructure.outbox.OutBoxRepository;
import lombok.extern.log4j.Log4j2;
import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.spring.annotations.Recurring;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Log4j2
@Service
@Profile({"dev", "hom", "prod", "local"})
public class DispatchOutBoxScheduling {
	private final OutBoxRepository outBoxRepository;
	private final KafkaDispatcherFactory kafkaDispatcherFactory;

	public DispatchOutBoxScheduling(OutBoxRepository outBoxRepository,
									KafkaDispatcherFactory kafkaDispatcherFactory) {
		this.outBoxRepository = outBoxRepository;
		this.kafkaDispatcherFactory = kafkaDispatcherFactory;
	}

	@Job(name = "Dispatch outbox notifications")
	@Recurring(id = "dispatch-outbox-recurring-job", cron = "*/30 * * * * *")
	@Transactional
	public void execute() {

		var outBoxes = outBoxRepository.findTop2000ByDispatchedFalseOrderByCreatedAt();

		if (outBoxes.isEmpty() || outBoxes.get().isEmpty())
			return;

		for (var outBox : outBoxes.get()){
			log.debug("Sending outbox {} to queue.", outBox);

			try{
				outBox.dispatch();
				outBoxRepository.save(outBox);

				var dispatcher = kafkaDispatcherFactory.dispatcherFor(outBox.getAggregate());
				dispatcher.dispatch(outBox);

			} catch (InterruptedException e) {
				log.warn(String.format("Error on sending %s to queue. Interrupted!", outBox), e);
				Thread.currentThread().interrupt();
			} catch(Exception e){
				log.warn(String.format("Error on sending %s to queue.", outBox), e);
				continue;
			}

			log.info("Success on send {} to queue.", outBox);
		}
	}
}
