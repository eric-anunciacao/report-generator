package br.com.hering.infrastructure.messaging.consumer.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MessageDataDto {

    private String headers;

    private String key;

    private int partition;

    private long messageOffset;

    private String message;

    private String topic;

    private String exceptionClass;

    private String exceptionCause;

    private String exceptionMessage;

    private String exceptionStacktrace;

    private String successPayload;
}
