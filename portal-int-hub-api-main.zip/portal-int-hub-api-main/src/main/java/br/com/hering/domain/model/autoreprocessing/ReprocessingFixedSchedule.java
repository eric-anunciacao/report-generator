package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.model.integration.IntegrationId;
import lombok.Getter;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Entity(name = "ReprocessingFixedSchedule")
@DiscriminatorValue("FIXED_SCHEDULE")
public class ReprocessingFixedSchedule extends AutoReprocessing {

    @Getter
    @Embedded
    private ReprocessSchedule schedule;

    protected ReprocessingFixedSchedule() { }

    private ReprocessingFixedSchedule(IntegrationId integrationId,
                                      RetryCount retries,
                                      IgnoreAfterDays ignoreAfterDays,
                                      List<LocalTime> schedule) {
        super(integrationId, retries, ignoreAfterDays);

        this.schedule = ReprocessSchedule.from(schedule);
    }

    public static ReprocessingFixedSchedule register(IntegrationId integrationId,
                                                     RetryCount retries,
                                                     IgnoreAfterDays ignoreAfterDays,
                                                     List<LocalTime> schedule) {

        return new ReprocessingFixedSchedule(integrationId, retries, ignoreAfterDays, schedule);
    }

    @Override
    public Strategy getStrategy() {
        return Strategy.FIXED_SCHEDULE;
    }



    @Override
    public String configurationLabel() {
        var items = schedule.getItems();

        return getConfigurationLabel(items);
    }

    public static String getConfigurationLabel(List<LocalTime> items) {
        var sb = new StringBuilder();

        for (int i = 0; i < items.size(); i++) {
            var item = items.get(i);
            sb.append(" Horário ").append(i + 1).append(": ").append(item.format(DateTimeFormatter.ofPattern("HH:mm"))).append("\n");
        }

        return String.format("Reprocessar em horários fixos:\n %s", sb.toString().trim());
    }

    public Optional<LocalTime> getNearestTimeBeforeIfExists(LocalTime timeToCompare) {

        Optional<LocalTime> nearest = Optional.empty();

        for (var item : schedule.getItems()) {
            if (timeToCompare.isBefore(item))
                break;

            nearest = Optional.of(item);
        }

        return nearest;
    }
}
