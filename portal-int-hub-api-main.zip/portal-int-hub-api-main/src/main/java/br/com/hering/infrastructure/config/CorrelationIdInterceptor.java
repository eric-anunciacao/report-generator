package br.com.hering.infrastructure.config;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

@Component
public class CorrelationIdInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        MDC.put("correlationId", retrieveCorrelationId(request));
        return true;
    }

    private String retrieveCorrelationId(HttpServletRequest request) {
        var correlationId = request.getHeader("correlationId");
        if(StringUtils.isNotBlank(correlationId)) {
            return correlationId;
        }

        return UUID.randomUUID().toString();
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) {
        MDC.clear();
    }
}

