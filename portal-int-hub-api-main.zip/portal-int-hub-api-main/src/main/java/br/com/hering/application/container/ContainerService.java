package br.com.hering.application.container;

public interface ContainerService {

    void createContainer(String topic, String bootstrapServers);

    void stopContainer(String topic);
}