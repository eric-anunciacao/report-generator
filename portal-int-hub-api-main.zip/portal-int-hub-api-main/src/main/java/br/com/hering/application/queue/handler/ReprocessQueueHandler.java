package br.com.hering.application.queue.handler;

import br.com.hering.domain.model.queue.events.QueueReprocessingRequested;
import br.com.hering.domain.shared.SubscribeTo;
import br.com.hering.infrastructure.outbox.OutBoxMessages;
import br.com.hering.infrastructure.outbox.QueueAggregate;
import org.springframework.stereotype.Component;

@Component
public class ReprocessQueueHandler implements SubscribeTo<QueueReprocessingRequested> {
    private final OutBoxMessages outBoxMessages;

    public ReprocessQueueHandler(OutBoxMessages outBoxMessages) {
        this.outBoxMessages = outBoxMessages;
    }

    @Override
    public void handle(QueueReprocessingRequested event) {
        var aggregateId = event.getQueue().getId().toString();

        var message = outBoxMessages.toReprocessQueue(event.getQueue().getId());

        outBoxMessages.save(
                QueueAggregate.REPROCESSING_REQUESTED,
                aggregateId,
                message
        );
    }
}
