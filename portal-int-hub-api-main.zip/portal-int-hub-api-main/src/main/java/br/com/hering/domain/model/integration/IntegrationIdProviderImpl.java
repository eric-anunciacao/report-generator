package br.com.hering.domain.model.integration;


import br.com.hering.domain.shared.AbstractIdProvider;
import org.springframework.stereotype.Component;

@Component
public class IntegrationIdProviderImpl extends AbstractIdProvider implements IntegrationIdProvider {

    private static final String SEQUENCE = "integration_id_seq";

    @Override
    public IntegrationId nextId() {
        return IntegrationId.is(super.nextLongId(SEQUENCE));
    }
}
