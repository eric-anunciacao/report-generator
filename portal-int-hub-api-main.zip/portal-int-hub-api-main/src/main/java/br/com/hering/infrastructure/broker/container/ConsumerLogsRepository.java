package br.com.hering.infrastructure.broker.container;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConsumerLogsRepository extends JpaRepository<ConsumerLogs, Long> {

}
