package br.com.hering.domain.model.autoreprocessing;


import br.com.hering.domain.model.autoreprocessing.events.AutoReprocessingConfigurationCreated;
import br.com.hering.domain.model.autoreprocessing.events.AutoReprocessingConfigurationInactivated;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.shared.AggregateRootBase;
import lombok.Getter;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name = "auto_reprocessing",
        schema = "public")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "strategy", discriminatorType = DiscriminatorType.STRING)
public abstract class AutoReprocessing extends AggregateRootBase<AutoReprocessing> {

    @Getter
    @EmbeddedId
    private IntegrationId id;

    @Getter
    @Column(name = "created_at", nullable = false)
    @CreationTimestamp
    private LocalDateTime createdAt;

    @Getter
    @Embedded
    @NotNull(message = "retries is required")
    private RetryCount retries;

    @Getter
    @Embedded
    @NotNull(message = "ignoreAfterDays is required")
    private IgnoreAfterDays ignoreAfterDays;

    @Getter
    @Column(name = "active", nullable = false)
    @NotNull(message = "active is required")
    private boolean active;

    @Column(name = "strategy", length = 50, nullable = false, updatable = false, insertable = false)
    private String strategy; //campo @DiscriminatorColumn hibernate

    protected AutoReprocessing() {
    }

    protected AutoReprocessing(IntegrationId integrationId,
                               RetryCount retries,
                               IgnoreAfterDays ignoreAfterDays) {

        this.id = integrationId;
        this.retries = retries;
        this.ignoreAfterDays = ignoreAfterDays;
        this.active = true;

        registerEvent(new AutoReprocessingConfigurationCreated(this));
    }

    @Override
    public boolean sameIdentityAs(AutoReprocessing other) {
        return other != null && other.id.equals(this.id);
    }

    public void inactivate() {
        this.active = false;
        registerEvent(new AutoReprocessingConfigurationInactivated(this));
    }

    public abstract Strategy getStrategy();

    public abstract String configurationLabel();

    public enum Strategy {

        AFTER_MINUTES("Minutos após o erro"),
        FIXED_SCHEDULE("Horários fixos");

        @Getter
        private final String label;

        Strategy(String label) {
            this.label = label;
        }
    }
}
