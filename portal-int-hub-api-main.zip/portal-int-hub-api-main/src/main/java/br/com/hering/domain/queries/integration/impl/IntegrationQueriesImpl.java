package br.com.hering.domain.queries.integration.impl;

import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.queries.integration.IntegrationQueries;
import br.com.hering.presentation.controllers.cluster.dto.ClusterDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationShortenedDto;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static br.com.hering.infrastructure.utils.string.InternalStringUtils.getStringValue;

@Service
public class IntegrationQueriesImpl implements IntegrationQueries {

    @PersistenceContext
    private EntityManager em;
    private final IntegrationRepository integrationRepository;
    private static final String INTEGRATION_NOT_FOUND = "integration %s not found.";
    private static final String CLUSTER_NOT_FOUND = "cluster %s not found.";
    private final ClusterRepository clusterRepository;

    public IntegrationQueriesImpl(IntegrationRepository integrationRepository,
                                  ClusterRepository clusterRepository) {
        this.integrationRepository = integrationRepository;
        this.clusterRepository = clusterRepository;
    }

    @Override
    public List<IntegrationDto> findAll(Sort sort) {
        var findAllSql = findAllQuery(sort);
        var findAllQuery = em.createNativeQuery(findAllSql, Tuple.class);

        return mapIntegrationList(findAllQuery.getResultList());
    }



    private String findAllQuery(Sort sort) {
        var query = "SELECT i.id, dlq_topic, dt_create, dt_update, identifier1, identifier2, \n" +
                    "       identifier3, identifier4, i.name, reprocess_topic, success_topic, \n" +
                    "       correlation_id, name_identifier1, name_identifier2, name_identifier3, \n" +
                    "       name_identifier4, active, dlq_topic_consumer_status, \n" +
                    "       success_topic_consumer_status, c.id as cluster_id, c.name as cluster_name\n" +
                    "FROM integration i\n" +
                    "INNER JOIN cluster c on c.id = i.cluster_id\n";

        if (!sort.isEmpty()) {
            var order = sort.get().findFirst().orElse(Sort.Order.desc("name"));
            query += "ORDER BY " + order.getProperty() + " " + order.getDirection().name() + " \n";
        }

        return query;
    }


    private List<IntegrationDto> mapIntegrationList(List<Tuple> resultList) {
        List<IntegrationDto> list = new ArrayList<>(resultList.size());

        for (var tuple : resultList) {
            var id = ((BigInteger) tuple.get("id")).longValue();
            var dlqTopic = getStringValue(tuple.get("dlq_topic"));
            var dtCreate = ((Timestamp) tuple.get("dt_create")).toLocalDateTime();
            var dtUpdate = tuple.get("dt_update") == null ? null : ((Timestamp) tuple.get("dt_update")).toLocalDateTime();
            var identifier1 = getStringValue(tuple.get("identifier1"));
            var identifier2 = getStringValue(tuple.get("identifier2"));
            var identifier3 = getStringValue(tuple.get("identifier3"));
            var identifier4 = getStringValue(tuple.get("identifier4"));
            var name = getStringValue(tuple.get("name"));
            var reprocessTopic = getStringValue(tuple.get("reprocess_topic"));
            var successTopic = getStringValue(tuple.get("success_topic"));
            var correlationId = getStringValue(tuple.get("correlation_id"));
            var nameIdentifier1 = getStringValue(tuple.get("name_identifier1"));
            var nameIdentifier2 = getStringValue(tuple.get("name_identifier2"));
            var nameIdentifier3 = getStringValue(tuple.get("name_identifier3"));
            var nameIdentifier4 = getStringValue(tuple.get("name_identifier4"));
            var active = (Boolean) tuple.get("active");
            var dlqTopicConsumerStatus = getStringValue(tuple.get("dlq_topic_consumer_status"));
            var successTopicConsumerStatus = getStringValue(tuple.get("success_topic_consumer_status"));
            var clusterId = ((BigInteger) tuple.get("cluster_id")).longValue();
            var clusterName = getStringValue(tuple.get("cluster_name"));

            var dto = IntegrationDto.builder()
                        .id(id)
                        .dlqTopic(dlqTopic)
                        .dtCreate(dtCreate)
                        .dtUpdate(dtUpdate)
                        .identifier1(identifier1)
                        .identifier2(identifier2)
                        .identifier3(identifier3)
                        .identifier4(identifier4)
                        .name(name)
                        .reprocessTopic(reprocessTopic)
                        .successTopic(successTopic)
                        .correlationId(correlationId)
                        .nameIdentifier1(nameIdentifier1)
                        .nameIdentifier2(nameIdentifier2)
                        .nameIdentifier3(nameIdentifier3)
                        .nameIdentifier4(nameIdentifier4)
                        .active(active)
                        .dlqTopicConsumerStatus(dlqTopicConsumerStatus)
                        .successTopicConsumerStatus(successTopicConsumerStatus)
                        .cluster(ClusterDto.builder()
                                .id(clusterId)
                                .name(clusterName)
                                .build())
                        .build();

            list.add(dto);
        }

        return list;
    }

    @Override
    public List<IntegrationShortenedDto> findAllShortened(Sort sort) {
        var findAllShortenedSql = findAllShortenedQuery(sort);
        var findAllShortenedQuery = em.createNativeQuery(findAllShortenedSql, Tuple.class);

        return mapIntegrationShortenedList(findAllShortenedQuery.getResultList());
    }

    private String findAllShortenedQuery(Sort sort) {
        var query = "SELECT i.id, i.cluster_id, i.name, i.active\n" +
                    "FROM integration i\n";

        if (!sort.isEmpty()) {
            var order = sort.get().findFirst().orElse(Sort.Order.desc("name"));
            query += "ORDER BY " + order.getProperty() + " " + order.getDirection().name() + " \n";
        }

        return query;
    }

    private List<IntegrationShortenedDto> mapIntegrationShortenedList(List<Tuple> resultList) {
        List<IntegrationShortenedDto> list = new ArrayList<>(resultList.size());

        for (var tuple : resultList) {
            var id = ((BigInteger) tuple.get("id")).longValue();
            var name = getStringValue(tuple.get("name"));
            var active = (Boolean) tuple.get("active");

            var dto = IntegrationShortenedDto.builder()
                    .id(id)
                    .name(name)
                    .active(active)
                    .build();

            list.add(dto);
        }

        return list;
    }

    @Override
    public IntegrationDto findById(IntegrationId id) {
        var integration = integrationRepository.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(INTEGRATION_NOT_FOUND, id)));

        var cluster = clusterRepository.findById(integration.getClusterId()).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, String.format(CLUSTER_NOT_FOUND, id)));

        return mapIntegration(integration, cluster);
    }

    private IntegrationDto mapIntegration(Integration integration, Cluster cluster) {
        return IntegrationDto.builder()
                .id(integration.getId().getValue())
                .dlqTopic(integration.getDlqTopic())
                .dtCreate(integration.getDtCreate())
                .dtUpdate(integration.getDtUpdate())
                .identifier1(integration.getIdentifier1())
                .identifier2(integration.getIdentifier2())
                .identifier3(integration.getIdentifier3())
                .identifier4(integration.getIdentifier4())
                .name(integration.getName())
                .reprocessTopic(integration.getReprocessTopic())
                .successTopic(integration.getSuccessTopic())
                .correlationId(integration.getCorrelationId())
                .nameIdentifier1(integration.getNameIdentifier1())
                .nameIdentifier2(integration.getNameIdentifier2())
                .nameIdentifier3(integration.getNameIdentifier3())
                .nameIdentifier4(integration.getNameIdentifier4())
                .active(integration.isActive())
                .dlqTopicConsumerStatus(integration.getDlqTopicConsumerStatus())
                .successTopicConsumerStatus(integration.getSuccessTopicConsumerStatus())
                .cluster(ClusterDto.builder()
                        .id(cluster.getId().getValue())
                        .name(cluster.getName())
                        .build())
                .build();
    }
}