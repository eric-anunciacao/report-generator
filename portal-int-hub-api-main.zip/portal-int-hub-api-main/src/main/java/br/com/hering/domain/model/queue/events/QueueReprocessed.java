package br.com.hering.domain.model.queue.events;


import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.shared.DomainEvent;
import lombok.Getter;

@Getter
public class QueueReprocessed extends DomainEvent {
    private final transient Queue queue;

    public QueueReprocessed(Queue queue) {
        super(queue);
        this.queue = queue;
    }
}
