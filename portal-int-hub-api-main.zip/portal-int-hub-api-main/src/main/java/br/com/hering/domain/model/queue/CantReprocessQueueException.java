package br.com.hering.domain.model.queue;


public class CantReprocessQueueException extends RuntimeException {
    public CantReprocessQueueException(String message) {
        super(message);
    }
}
