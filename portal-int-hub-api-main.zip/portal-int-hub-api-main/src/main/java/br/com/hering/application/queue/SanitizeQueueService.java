package br.com.hering.application.queue;

import java.time.LocalDate;

public interface SanitizeQueueService {
    void clearOldQueuesAndLogsBefore(LocalDate date);
}
