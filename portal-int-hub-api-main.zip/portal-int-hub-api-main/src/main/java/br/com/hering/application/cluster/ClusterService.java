package br.com.hering.application.cluster;

import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.presentation.controllers.cluster.request.CreateClusterRequest;
import br.com.hering.presentation.controllers.cluster.request.UpdateClusterRequest;

public interface ClusterService {
    Cluster execute(CreateClusterRequest request);
    Cluster execute(UpdateClusterRequest request);
}