package br.com.hering.infrastructure.config;

import br.com.hering.application.integration.IntegrationService;
import lombok.Data;
import lombok.Getter;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.event.EventListener;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

@Profile({ "dev", "hom", "prod", "local"})
@Data
@EnableKafka
@Configuration
@ConfigurationProperties(prefix = "spring.kafka")
public class KafkaConfig {

    private Topics commandTopics;

    private String brokerBlu;
    private String brokerGcp;
    private String brokerGcpUs;

    private static final Logger log = LoggerFactory.getLogger(KafkaConfig.class);

    @Getter
    protected static final Map<String, KafkaMessageListenerContainer<String, String>> consumersMap = new HashMap<>();

    private final IntegrationService integrationService;

    public KafkaConfig(IntegrationService integrationService) {
        this.integrationService = integrationService;
    }

    /**
     * Set up test properties for an {@code <Integer, String>} consumer.
     *
     * @param brokersCommaSep the bootstrapServers property (comma separated
     * servers).
     * @param group the group id.
     * @param autoCommit the auto commit.
     * @return the properties.
     */
    public static Map<String, Object> consumerProps(String brokersCommaSep, String group, String autoCommit, String clientPrefix) {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, brokersCommaSep);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, group);
        try {
            props.put(ConsumerConfig.CLIENT_ID_CONFIG, InetAddress.getLocalHost().getHostName() + clientPrefix);
        } catch (UnknownHostException ex) {
            log.error("Error setting properties.", ex);
        }
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "10");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 60000);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.ALLOW_AUTO_CREATE_TOPICS_CONFIG, false);
        return props;
    }

    public static Map<String, Object> producerProps(String brokersCommaSep) {
        Map<String, Object> props = new HashMap<>();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, brokersCommaSep);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

        return props;
    }

    @EventListener(classes = ApplicationStartedEvent.class)
    public void startKafkaContainer() {
        integrationService.startAllIntegrationsContainers();
    }

    @Data
    public static class Topics {
        private String reprocessQueue;
        private String reprocessQueueDlq;
        private String processQueueDlq;
    }
}
