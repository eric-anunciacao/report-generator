package br.com.hering.infrastructure.utils.json;

import com.google.gson.Gson;
import org.springframework.stereotype.Service;

@Service
public class InternalJsonSerializer {

    private final Gson gson;

    public InternalJsonSerializer(Gson gson) {
        this.gson = gson;
    }

    public String toJson(Object body) {
        return gson.toJson(body);
    }

    public <T> AsJson<T> asJson(T body) {
        var json = gson.toJson(body);
        return AsJson.create(body, json);
    }

    public <T> AsJson<T> asJson(T body, Class<T> classOfT) {
        var json = gson.toJson(body, classOfT);
        return AsJson.create(body, json);
    }

    public <T> T fromJson(String message, Class<T> classOfT){
        return gson.fromJson(message, classOfT);
    }
}
