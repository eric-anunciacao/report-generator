package br.com.hering.application.autoreprocessing;

import br.com.hering.domain.model.autoreprocessing.AutoReprocessing;
import br.com.hering.domain.model.autoreprocessing.AutoReprocessingRepository;
import br.com.hering.domain.model.autoreprocessing.TestAutoReprocessing;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.domain.model.queue.TestQueue;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingRequestDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AutoReprocessingServiceImplTest {

    @Mock
    AutoReprocessingRepository autoReprocessingRepository;

    @Mock
    QueueRepository queueRepository;

    @InjectMocks
    AutoReprocessingServiceImpl autoReprocessingService;

    @Test
    void create_auto_reprocessing_fixed_schedule_should_be_successful() {

        when(autoReprocessingRepository.existsById(any(IntegrationId.class))).thenReturn(false);
        when(autoReprocessingRepository.save(any(AutoReprocessing.class))).thenReturn(TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig());

        autoReprocessingService.create(TestAutoReprocessing.anAutoReprocessingFixedScheduleConfigDto());

        verify(autoReprocessingRepository).existsById(any(IntegrationId.class));
        verify(autoReprocessingRepository).save(any(AutoReprocessing.class));
    }

    @Test
    void create_existing_auto_reprocessing_fixed_schedule_should_return_conflict() {

        when(autoReprocessingRepository.existsById(any(IntegrationId.class))).thenReturn(true);

        assertThrows(ResponseStatusException.class, () -> autoReprocessingService.create(TestAutoReprocessing.anAutoReprocessingFixedScheduleConfigDto()));

        verify(autoReprocessingRepository).existsById(any(IntegrationId.class));
    }

    @Test
    void create_auto_reprocessing_no_strategy_should_return_bad_request() {
        var dto = AutoReprocessingRequestDto.builder()
                .active(true)
                .ignoreAfterDays(2)
                .integrationId(1234)
                .retries(3)
                .build();

        assertThrows(ResponseStatusException.class, () -> autoReprocessingService.create(dto));

        verify(autoReprocessingRepository).existsById(any(IntegrationId.class));
    }

    @Test
    void update_auto_reprocessing_fixed_schedule_should_be_successful() {

        when(autoReprocessingRepository.existsById(any(IntegrationId.class))).thenReturn(true);
        when(autoReprocessingRepository.save(any(AutoReprocessing.class))).thenReturn(TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig());

        var dto = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfigDto();
        var id = IntegrationId.is(dto.getIntegrationId());
        autoReprocessingService.update(id, dto);

        verify(autoReprocessingRepository).existsById(any(IntegrationId.class));
        verify(autoReprocessingRepository).save(any(AutoReprocessing.class));
    }

    @Test
    void update_non_existing_auto_reprocessing_fixed_schedule_should_return_not_found() {

        when(autoReprocessingRepository.existsById(any(IntegrationId.class))).thenReturn(false);

        var dto = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfigDto();
        var id = IntegrationId.is(dto.getIntegrationId());
        assertThrows(ResponseStatusException.class, () -> autoReprocessingService.update(id, dto));

        verify(autoReprocessingRepository).existsById(any(IntegrationId.class));
    }

    @Test
    void reprocess_all_should_save_auto_reprocessing_after_minutes_config() {
        var afterMinutes = TestAutoReprocessing.anAutoReprocessingAfterMinutesConfig();

        when(autoReprocessingRepository.findAllByActiveIsTrue()).thenReturn(List.of(afterMinutes));
        when(queueRepository.findForReprocessing(
                anyInt(), any(LocalDateTime.class), any(LocalDateTime.class), anyString(), any(IntegrationId.class), any(Pageable.class)))
                .thenReturn(List.of(TestQueue.aQueue()));

        autoReprocessingService.reprocessAll(LocalDateTime.now());

        verify(autoReprocessingRepository).findAllByActiveIsTrue();
    }

    @Test
    void reprocess_all_should_save_auto_reprocessing_fixed_schedule_config() {
        var scheduled = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig();

        when(autoReprocessingRepository.findAllByActiveIsTrue()).thenReturn(List.of(scheduled));
        when(queueRepository.findForReprocessing(
                anyInt(), any(LocalDateTime.class), any(LocalDateTime.class), anyString(), any(IntegrationId.class), any(Pageable.class)))
                .thenReturn(List.of(TestQueue.aQueue()));

        autoReprocessingService.reprocessAll(LocalDateTime.now());

        verify(autoReprocessingRepository).findAllByActiveIsTrue();
    }
}
