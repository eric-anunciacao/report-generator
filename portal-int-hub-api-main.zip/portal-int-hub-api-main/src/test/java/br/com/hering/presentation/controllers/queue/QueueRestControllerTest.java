package br.com.hering.presentation.controllers.queue;

import br.com.hering.application.queue.QueueService;
import br.com.hering.domain.model.queue.*;
import br.com.hering.domain.queries.queuelogs.QueueLogQueries;
import br.com.hering.presentation.controllers.queue.dto.*;
import br.com.hering.presentation.controllers.queue.request.UpdateQueueRequest;
import br.com.hering.domain.queries.queue.QueueQueries;
import br.com.hering.infrastructure.modelmapper.ModelMapperConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(QueueController.class)
@ContextConfiguration(classes = {ModelMapperConfig.class})
@Import(QueueController.class)
@AutoConfigureMockMvc(addFilters = false)
class QueueRestControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private QueueService queueService;

    @MockBean
    private QueueRepository queueRepository;

    @MockBean
    private QueueLogQueries queueLogQueries;

    @MockBean
    private QueueQueries queueQueries;

    @MockBean
    private ModelMapper modelMapper;

    private static final String PREFIX = "/queues";

    @Test
    void findAll_queue_without_period_returns_400() throws Exception {
        this.mockMvc.perform(get(PREFIX).contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isBadRequest());
    }

    @Test
    void findAll_queue_with_period_returns_200() throws Exception {
        var queues = new PageImpl<>(Collections.singletonList(TestQueue.aQueueSummaryDto()));
        var now = LocalDateTime.now();

        when(this.queueQueries.findAll(any(QueueFilterDto.class), any(Pageable.class))).thenReturn(queues);

        var formattedDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.mockMvc.perform(get(PREFIX + "?dtEventBegin=" + formattedDate + "&dtEventEnd=" + formattedDate).contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void filterMass_with_period_returns_200() throws Exception {
        var queues = new PageImpl<>(Collections.singletonList(TestQueue.aQueueSummaryDto()));
        var now = LocalDateTime.now();

        var formattedDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        var filter = QueueFilterMassDto
                .builder()
                .integrationId(1L)
                .dtEventBegin(formattedDate)
                .dtEventEnd(formattedDate)
                .pageSize(10)
                .pageNumber(0)
                .identifiers(List.of(QueueFilterIdentifierDto
                        .builder()
                        .type("description")
                        .values(List.of("test"))
                        .build()))
                .build();

        when(queueQueries.findAllMass(any(FilterMassParam.class), any(Pageable.class))).thenReturn(queues);
        when(modelMapper.map(any(Queue.class), eq(QueueSummaryDto.class))).thenReturn(TestQueue.aQueueSummaryDto());

        this.mockMvc.perform(post(PREFIX + "/filterMass")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(filter))
                        .characterEncoding(StandardCharsets.UTF_8))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void getAllQueueDashboard_queue_returns_200() throws Exception {
        var toBeReturned = List.of(TestQueue.queueDashboardDto());

        doReturn(toBeReturned).when(this.queueQueries).getQueueStatistics(any(), any());

        this.mockMvc.perform(get(PREFIX + "/getAllQueueDashboard").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].integration.id").value(1L))
                .andExpect(jsonPath("$[0].integration.name").value("test integration"))
                .andExpect(jsonPath("$[0].success").value(10L))
                .andExpect(jsonPath("$[0].error").value(5L))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(content().json(this.objectMapper.writeValueAsString(toBeReturned)));

        verify(this.queueQueries).getQueueStatistics(any(), any());
    }

    @Test
    void findById_queue_returns_200() throws Exception {
        doReturn(TestQueue.aQueueDto()).when(this.queueQueries).findById(QueueId.is(1L));

        this.mockMvc.perform(get(PREFIX + "/1").contentType(MediaType.APPLICATION_JSON).characterEncoding(StandardCharsets.UTF_8))

                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.correlationId").value("6386539ba07ad291f815f3ac_1"))
                .andExpect(jsonPath("$.identifier").value("35221178876950006889551900000097551446160927"))
                .andExpect(jsonPath("$.key").value("300d4033-7d2d-4d07-bbd6-5e397c050dec"))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON));

        verify(this.queueQueries).findById(QueueId.is(1L));
    }

    @Test
    void update_queue_returns_200() throws Exception {
        doReturn(TestQueue.aQueue()).when(this.queueService).execute(any(UpdateQueueRequest.class));

        this.mockMvc.perform(put(PREFIX).contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(TestQueue.aQueueDto())))
                .andDo(print())
                .andExpect(status().isOk());

        verify(this.queueService).execute(any(UpdateQueueRequest.class));
    }

    @Test
    void reprocess_returns_200() throws Exception {
        this.mockMvc.perform(put(PREFIX + "/update-queues")
                        .characterEncoding("utf-8")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(List.of(1L))))

                .andDo(print())
                .andExpect(status().isOk());
    }
}