package br.com.hering.infrastructure.cleanup;

import br.com.hering.application.queue.SanitizeQueueService;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import br.com.hering.utils.database.TableNamesUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.jdbc.JdbcTestUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDate;

import static br.com.hering.domain.model.queue.TestQueue.aQueueWithSpecificEventDate;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class SanitizeQueueServiceImplITTest {
    @PersistenceContext
    private EntityManager em;

    @Autowired
    private DatabasePopulator databasePopulator;

    @Autowired
    private IntegrationRepository integrationRepository;

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired
    private QueueRepository queueRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private Integration integration;

    @Autowired
    private SanitizeQueueService target;

    @BeforeEach
    public void setUp() {
        databasePopulator.cleanTables();

        var cluster = this.clusterRepository.save(TestCluster.aCluster());
        this.integration = integrationRepository.save(TestIntegration.anIntegration(cluster));
    }

    @Test
    void should_cleanup_old_queues() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();

        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(3).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(4).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(5).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(6).plusDays(1).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(6).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(6).minusDays(1).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(7).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(8).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(9).atStartOfDay()));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), LocalDate.now().minusMonths(10).atStartOfDay()));

        target.clearOldQueuesAndLogsBefore(LocalDate.now().minusMonths(6));

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isEqualTo(4);

        databasePopulator.cleanTables();

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();
    }



}
