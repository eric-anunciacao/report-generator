package br.com.hering.application.queue;

import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.domain.model.queue.TestQueue;
import br.com.hering.infrastructure.http.NotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QueueServiceImplTest {
    @Mock
    QueueRepository queueRepository;

    @Mock
    IntegrationRepository integrationRepository;

    @Mock
    ModelMapper modelMapper;

    @InjectMocks
    QueueServiceImpl queueService;

    @Test
    void update() {
        var aQueue = TestQueue.aQueue();
        var anUpdateQueueRequest = TestQueue.anUpdateQueueRequest();

        when(queueRepository.findById(any(QueueId.class))).thenReturn(Optional.of(aQueue));
        when(queueRepository.save(any(Queue.class))).thenReturn(aQueue);

        var queue = queueService.execute(anUpdateQueueRequest);
        assertNotNull(queue);

        verify(queueRepository).findById(any(QueueId.class));
        verify(queueRepository).save(any(Queue.class));
    }

    @Test
    void updateQueues() {
        var queues = List.of(TestQueue.aQueue());

        when(queueRepository.findByIdIn(anyList())).thenReturn(queues);
        when(queueRepository.saveAll(anyList())).thenReturn(queues);

        queueService.reprocess(anyList());

        verify(queueRepository).findByIdIn(anyList());
        verify(queueRepository).saveAll(queues);
    }

    @Test
    void processEvent_new_queue_should_return_true() {
        var aMessageDataDto = TestQueue.aMessageDataDto();

        when(integrationRepository.findByDlqTopicOrSuccessTopic(anyString(), anyString())).thenReturn(Optional.of(TestIntegration.aSecondIntegration()));
        when(queueRepository.findByCorrelationId(anyString())).thenReturn(Optional.empty());
        when(queueRepository.save(any(Queue.class))).thenReturn(TestQueue.aQueue());

        var result = queueService.processEvent(aMessageDataDto);

        assertTrue(result);
        verify(integrationRepository).findByDlqTopicOrSuccessTopic(anyString(), anyString());
        verify(queueRepository).findByCorrelationId(anyString());
        verify(queueRepository).save(any(Queue.class));
    }

    @Test
    void processEvent_existing_queue_should_return_true() {
        var aMessageDataDto = TestQueue.aMessageDataDto();

        when(integrationRepository.findByDlqTopicOrSuccessTopic(anyString(), anyString())).thenReturn(Optional.of(TestIntegration.aSecondIntegration()));
        when(queueRepository.findByCorrelationId(anyString())).thenReturn(Optional.of(TestQueue.aQueue()));
        when(queueRepository.save(any(Queue.class))).thenReturn(TestQueue.aQueue());

        var result = queueService.processEvent(aMessageDataDto);

        assertTrue(result);
        verify(integrationRepository).findByDlqTopicOrSuccessTopic(anyString(), anyString());
        verify(queueRepository).findByCorrelationId(anyString());
        verify(queueRepository).save(any(Queue.class));
    }

    @Test
    void processEvent_with_inactive_integration_should_return_false() {
        var aMessageDataDto = TestQueue.aMessageDataDto();

        when(integrationRepository.findByDlqTopicOrSuccessTopic(anyString(), anyString())).thenReturn(Optional.of(TestIntegration.anInactiveIntegration()));

        var result = queueService.processEvent(aMessageDataDto);

        assertFalse(result);
        verify(integrationRepository).findByDlqTopicOrSuccessTopic(anyString(), anyString());
    }

    @Test
    void processEvent_with_no_integration_should_throw() {
        var aMessageDataDto = TestQueue.aMessageDataDto();

        when(integrationRepository.findByDlqTopicOrSuccessTopic(anyString(), anyString())).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> queueService.processEvent(aMessageDataDto));

        verify(integrationRepository).findByDlqTopicOrSuccessTopic(anyString(), anyString());
    }
}