package br.com.hering.domain.model.queue;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.TestIntegration;
import org.junit.jupiter.api.Test;

import static br.com.hering.domain.model.queue.TestQueue.aQueue;
import static org.junit.jupiter.api.Assertions.*;

class QueueTest {

    @Test
    void should_create_new_queue() {

        var correlationId = "123_1";
        var statusError = StatusEnum.ERRO.name();
        var exceptionCause = "test exception cause";
        var exceptionClass = "test exception class";
        var exceptionStacktrace = "test exception stacktrace";
        var exceptionMessage = "test exception message";
        var identifier = "test.identifier";
        var identifier2 = "test.identifier2";
        var identifier3 = "test.identifier3";
        var identifier4 = "test.identifier4";
        var headers = "test headers";
        var key = "test key";
        var messageOffset = 1L;
        var message = "{ \"value\": \"test message\", \"test\": { \"identifier\": \"123\", \"identifier2\": \"1234\", \"identifier3\": \"12345\", \"identifier4\": \"123456\" } }";
        var partition = 1;
        var integration = TestIntegration.anIntegration();

        var queue = Queue.newQueue(QueueId.is(1L), correlationId, integration.getId())
                .status(statusError)
                .exceptionCause(exceptionCause)
                .exceptionClass(exceptionClass)
                .exceptionStacktrace(exceptionStacktrace)
                .exceptionMessage(exceptionMessage)
                .identifier(identifier)
                .identifier2(identifier2)
                .identifier3(identifier3)
                .identifier4(identifier4)
                .headers(headers)
                .key(key)
                .messageOffset(messageOffset)
                .message(message)
                .partition(partition)
                .build();


        assertEquals(correlationId, queue.getCorrelationId());
        assertEquals(integration.getId(), queue.getIntegrationId());
        assertEquals(statusError, queue.getStatus());
        assertEquals(exceptionCause, queue.getExceptionCause());
        assertEquals(exceptionClass, queue.getExceptionClass());
        assertEquals(exceptionStacktrace, queue.getExceptionStacktrace());
        assertEquals(exceptionMessage, queue.getExceptionMessage());
        assertEquals(identifier, queue.getIdentifier());
        assertEquals(identifier2, queue.getIdentifier2());
        assertEquals(identifier3, queue.getIdentifier3());
        assertEquals(identifier4, queue.getIdentifier4());
        assertEquals(headers, queue.getHeaders());
        assertEquals(key, queue.getKey());
        assertEquals(messageOffset, queue.getMessageOffset());
        assertEquals(message, queue.getMessage());
        assertEquals(partition, queue.getPartition());
    }

    @Test
    void should_auto_reprocess_queue() {

        var queue = aQueue(QueueId.is(123), IntegrationId.is(1));

        queue.requestAutomaticReprocessing();

        assertEquals(StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription(), queue.getStatus());
        assertEquals(1, queue.getAutoReprocessingRetries());
        assertNotNull(queue.getFirstAutoReprocessingRetryDate());
        assertTrue(queue.isInAutomaticReprocessingFlow());
    }

    @Test
    void should_clear_auto_reprocess_from_queue() {

        var queue = aQueue(QueueId.is(123), IntegrationId.is(1));
        queue.requestManualReprocessing();

        assertEquals(StatusEnum.AGUARDANDO_REPROCESSAMENTO.getDescription(), queue.getStatus());
        assertNull(queue.getAutoReprocessingRetries());
        assertNull(queue.getFirstAutoReprocessingRetryDate());
        assertFalse(queue.isInAutomaticReprocessingFlow());
    }
}
