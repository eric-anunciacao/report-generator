package br.com.hering.domain.model.queue;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.infrastructure.messaging.consumer.dto.MessageDataDto;
import br.com.hering.presentation.controllers.queue.dto.QueueStatisticsDto;
import br.com.hering.presentation.controllers.queue.dto.QueueDto;
import br.com.hering.presentation.controllers.queue.dto.QueueSummaryDto;
import br.com.hering.presentation.controllers.queue.request.UpdateQueueRequest;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.domain.model.queue.logs.TestQueueLogs;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Random;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TestQueue {

    private static final Random random = new Random();
    public static final String EXAMPLE_MESSAGE = "{\n" +
                                                 "  \"Invoice\": {\n" +
                                                 "    \"files\": [\n" +
                                                 "      {\n" +
                                                 "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                                                 "        \"type\": \"xml_authorization\",\n" +
                                                 "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                                                 "      },\n" +
                                                 "      {\n" +
                                                 "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                                                 "        \"type\": \"danfe_authorization\",\n" +
                                                 "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                                                 "      }\n" +
                                                 "    ],\n" +
                                                 "    \"log_history\": [],\n" +
                                                 "    \"user_id\": \"7924\",\n" +
                                                 "    \"number\": \"9755\",\n" +
                                                 "    \"nfe_serie\": \"190\",\n" +
                                                 "    \"xml_version\": \"4.00\",\n" +
                                                 "    \"app_origin\": \"mercadolivre\",\n" +
                                                 "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                                                 "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                                                 "    \"nfe_type\": \"sale\",\n" +
                                                 "    \"nfe_key\": \"35221178876950006889551900000097551446160927\",\n" +
                                                 "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                                                 "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                                                 "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                                                 "    \"nfe_receipt\": \"351010205638523\",\n" +
                                                 "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                                                 "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                                                 "    \"nfe_status\": \"authorized\",\n" +
                                                 "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                                                 "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                                                 "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                                                 "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                                                 "    \"id\": \"6386539ba07ad291f815f3ac\"\n" +
                                                 "  }\n" +
                                                 "}";

    public static Queue aQueue(long id) {
        return aQueue(QueueId.is(id), TestIntegration.anIntegration().getId());
    }

    public static Queue aQueue() {
        return aQueue(QueueId.is(random.nextLong()), TestIntegration.anIntegration().getId());
    }

    public static Queue aQueueWithSpecificEventDate(IntegrationId integrationId, LocalDateTime dtEvent) {
        var queue = Queue.newQueue(QueueId.is(random.nextLong()), "6386539ba07ad291f815f3ac_1", integrationId, dtEvent)
                .exceptionCause("br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException")
                .exceptionClass("org.springframework.kafka.listener.ListenerExecutionFailedException")
                .exceptionMessage("SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}")
                .exceptionStacktrace("org.springframework.kafka.listener.ListenerExecutionFailedException: Listener method 'public void br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(org.apache.kafka.clients.consumer.ConsumerRecord<java.lang.String, java.lang.String>,org.springframework.kafka.support.Acknowledgment)' threw exception; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.decorateException(KafkaMessageListenerContainer.java:2713)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2683)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeOnMessage(KafkaMessageListenerContainer.java:2643)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeRecordListener(KafkaMessageListenerContainer.java:2570)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeWithRecords(KafkaMessageListenerContainer.java:2451)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeRecordListener(KafkaMessageListenerContainer.java:2329)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeListener(KafkaMessageListenerContainer.java:2000)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeIfHaveRecords(KafkaMessageListenerContainer.java:1373)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.pollAndInvoke(KafkaMessageListenerContainer.java:1364)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.run(KafkaMessageListenerContainer.java:1255)\n" +
                                     "\tat java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)\n" +
                                     "\tat java.util.concurrent.FutureTask.run(FutureTask.java:266)\n" +
                                     "\tat java.lang.Thread.run(Thread.java:748)\n" +
                                     "\tSuppressed: org.springframework.kafka.listener.ListenerExecutionFailedException: Restored Stack Trace\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:363)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\t\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "Caused by: br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat br.com.hering.b2c.integration.domain.service.SAPService.sendSupply(SAPService.java:42)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.processEvent(MeliIntegrationConsumer.java:77)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(MeliIntegrationConsumer.java:46)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\n" +
                                     "\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\n" +
                                     "\tat java.lang.reflect.Method.invoke(Method.java:498)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:169)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.invoke(InvocableHandlerMethod.java:119)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.HandlerAdapter.invoke(HandlerAdapter.java:56)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:347)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "\t... 11 more\n")
                .identifier("35221178876950006889551900000097551446160927")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9755")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050dec")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160927\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3ac\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(89L)
                .partition(1)
                .status("Erro")
                .build();

        queue.setDtUpdate(dtEvent);

        return queue;
    }

    public static Queue aQueue(QueueId id, IntegrationId integrationId) {
        var queue = Queue.newQueue(id, "6386539ba07ad291f815f3ac_1", integrationId)
                .exceptionCause("br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException")
                .exceptionClass("org.springframework.kafka.listener.ListenerExecutionFailedException")
                .exceptionMessage("SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}")
                .exceptionStacktrace("org.springframework.kafka.listener.ListenerExecutionFailedException: Listener method 'public void br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(org.apache.kafka.clients.consumer.ConsumerRecord<java.lang.String, java.lang.String>,org.springframework.kafka.support.Acknowledgment)' threw exception; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.decorateException(KafkaMessageListenerContainer.java:2713)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2683)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeOnMessage(KafkaMessageListenerContainer.java:2643)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeRecordListener(KafkaMessageListenerContainer.java:2570)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeWithRecords(KafkaMessageListenerContainer.java:2451)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeRecordListener(KafkaMessageListenerContainer.java:2329)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeListener(KafkaMessageListenerContainer.java:2000)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeIfHaveRecords(KafkaMessageListenerContainer.java:1373)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.pollAndInvoke(KafkaMessageListenerContainer.java:1364)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.run(KafkaMessageListenerContainer.java:1255)\n" +
                                     "\tat java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)\n" +
                                     "\tat java.util.concurrent.FutureTask.run(FutureTask.java:266)\n" +
                                     "\tat java.lang.Thread.run(Thread.java:748)\n" +
                                     "\tSuppressed: org.springframework.kafka.listener.ListenerExecutionFailedException: Restored Stack Trace\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:363)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\t\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "Caused by: br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat br.com.hering.b2c.integration.domain.service.SAPService.sendSupply(SAPService.java:42)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.processEvent(MeliIntegrationConsumer.java:77)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(MeliIntegrationConsumer.java:46)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\n" +
                                     "\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\n" +
                                     "\tat java.lang.reflect.Method.invoke(Method.java:498)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:169)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.invoke(InvocableHandlerMethod.java:119)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.HandlerAdapter.invoke(HandlerAdapter.java:56)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:347)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "\t... 11 more\n")
                .identifier("35221178876950006889551900000097551446160927")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9755")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050dec")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160927\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3ac\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(89L)
                .partition(1)
                .status("Erro")
                .build();

        return queue;
    }

    public static Queue aSuccessQueue(QueueId id, IntegrationId integrationId) {
        var queue = Queue.newQueue(id, "6386539ba07ad291f815f3a2_1", integrationId)
                .identifier("35221178876950006889551900000097551446160928")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9756")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050ded")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160928\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3ad\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(90L)
                .partition(2)
                .status("Sucesso")
                .build();

        return queue;
    }

    public static Queue aReprocessedQueue(QueueId id, IntegrationId integrationId) {
        var queue = Queue.newQueue(id, "6386539ba07ad291f815f3a1_1", integrationId)
                .identifier("35221178876950006889551900000097551446160929")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9757")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050dee")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160929\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3ae\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(91L)
                .partition(2)
                .status("Reprocessado")
                .build();

        return queue;
    }

    public static Queue aWaitingReprocessingQueue(QueueId id, IntegrationId integrationId) {
        var queue = Queue.newQueue(id, "6386539ba07ad291f815f3a0_1", integrationId)
                .identifier("35221178876950006889551900000097551446160930")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9757")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050def")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160930\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3ae\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(92L)
                .partition(1)
                .status("Aguardando reprocessamento")
                .build();

        return queue;
    }

    public static Queue aFailedReprocessingQueue(QueueId id, IntegrationId integrationId) {
        var queue = Queue.newQueue(id, "6386539ba07ad291f815f3af_1", integrationId)
                .identifier("35221178876950006889551900000097551446160931")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9757")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050deg")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160931\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3af\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(92L)
                .partition(1)
                .status("Falha no reprocessamento")
                .build();

        return queue;
    }

    public static QueueDto aQueueDto() {
        return QueueDto.builder()
                .id(1L)
                .correlationId("6386539ba07ad291f815f3ac_1")
                .dtEvent(LocalDateTime.now())
                .dtUpdate(LocalDateTime.now())
                .exceptionCause("br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException")
                .exceptionClass("org.springframework.kafka.listener.ListenerExecutionFailedException")
                .exceptionMessage("SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}")
                .exceptionStacktrace("org.springframework.kafka.listener.ListenerExecutionFailedException: Listener method 'public void br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(org.apache.kafka.clients.consumer.ConsumerRecord<java.lang.String, java.lang.String>,org.springframework.kafka.support.Acknowledgment)' threw exception; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.decorateException(KafkaMessageListenerContainer.java:2713)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2683)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeOnMessage(KafkaMessageListenerContainer.java:2643)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeRecordListener(KafkaMessageListenerContainer.java:2570)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeWithRecords(KafkaMessageListenerContainer.java:2451)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeRecordListener(KafkaMessageListenerContainer.java:2329)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeListener(KafkaMessageListenerContainer.java:2000)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeIfHaveRecords(KafkaMessageListenerContainer.java:1373)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.pollAndInvoke(KafkaMessageListenerContainer.java:1364)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.run(KafkaMessageListenerContainer.java:1255)\n" +
                                     "\tat java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)\n" +
                                     "\tat java.util.concurrent.FutureTask.run(FutureTask.java:266)\n" +
                                     "\tat java.lang.Thread.run(Thread.java:748)\n" +
                                     "\tSuppressed: org.springframework.kafka.listener.ListenerExecutionFailedException: Restored Stack Trace\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:363)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\t\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "Caused by: br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat br.com.hering.b2c.integration.domain.service.SAPService.sendSupply(SAPService.java:42)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.processEvent(MeliIntegrationConsumer.java:77)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(MeliIntegrationConsumer.java:46)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\n" +
                                     "\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\n" +
                                     "\tat java.lang.reflect.Method.invoke(Method.java:498)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:169)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.invoke(InvocableHandlerMethod.java:119)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.HandlerAdapter.invoke(HandlerAdapter.java:56)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:347)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "\t... 11 more\n")
                .identifier("35221178876950006889551900000097551446160927")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9755")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050dec")
                .message("{\n" +
                         "  \"Invoice\": {\n" +
                         "    \"files\": [\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747618.xml\",\n" +
                         "        \"type\": \"xml_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3ce\"\n" +
                         "      },\n" +
                         "      {\n" +
                         "        \"url\": \"https://pluggto-xmlnf.s3.sa-east-1.amazonaws.com/invoices_405865659_35221178876950006889551900000097551446160927_1669747619.pdf\",\n" +
                         "        \"type\": \"danfe_authorization\",\n" +
                         "        \"id\": \"6386539da07ad291f815f3cf\"\n" +
                         "      }\n" +
                         "    ],\n" +
                         "    \"log_history\": [],\n" +
                         "    \"user_id\": \"7924\",\n" +
                         "    \"number\": \"9755\",\n" +
                         "    \"nfe_serie\": \"190\",\n" +
                         "    \"xml_version\": \"4.00\",\n" +
                         "    \"app_origin\": \"mercadolivre\",\n" +
                         "    \"app_sub_origin\": \"HERING_OFICIAL\",\n" +
                         "    \"reference_order\": \"6386533bddea489371c53372\",\n" +
                         "    \"nfe_type\": \"sale\",\n" +
                         "    \"nfe_key\": \"35221178876950006889551900000097551446160927\",\n" +
                         "    \"nfe_date\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_creation_date\": \"2022-11-29T21:45:11.000Z\",\n" +
                         "    \"nfe_protocol\": \"2022-11-29T18:45:11.517Z\",\n" +
                         "    \"nfe_receipt\": \"351010205638523\",\n" +
                         "    \"nfe_receipt_date\": \"2022-11-29T21:45:13.000Z\",\n" +
                         "    \"nfe_authorization_date\": \"2022-11-29T21:45:16.000Z\",\n" +
                         "    \"nfe_status\": \"authorized\",\n" +
                         "    \"modified\": \"2022-11-29T18:47:00.387Z\",\n" +
                         "    \"modified_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"created\": \"2022-11-29T18:46:51.898Z\",\n" +
                         "    \"created_by\": \"db88c2ffe78f0992c1d7d7371f58ca47\",\n" +
                         "    \"id\": \"6386539ba07ad291f815f3ac\"\n" +
                         "  }\n" +
                         "}")
                .messageOffset(89L)
                .partition(1)
                .status("Erro")
                .integration(TestIntegration.anIntegrationDto())
                .queueLogs(TestQueueLogs.aQueueLogsDto())
                .headers("{\"causa\":\"classe service\",\"mensagem\":\"error na integração\",\"correlationID\":\"12545\"}")
                .build();
    }

    public static UpdateQueueRequest anUpdateQueueRequest() {
        return UpdateQueueRequest.builder()
                .id(1L)
                .correlationId("6386539ba07ad291f815f3ac_1")
                .dtEvent(LocalDateTime.now())
                .dtUpdate(LocalDateTime.now())
                .exceptionCause("br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException")
                .exceptionClass("org.springframework.kafka.listener.ListenerExecutionFailedException")
                .exceptionMessage("SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}")
                .exceptionStacktrace("org.springframework.kafka.listener.ListenerExecutionFailedException: Listener method 'public void br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(org.apache.kafka.clients.consumer.ConsumerRecord<java.lang.String, java.lang.String>,org.springframework.kafka.support.Acknowledgment)' threw exception; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}; nested exception is br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.decorateException(KafkaMessageListenerContainer.java:2713)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2683)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeOnMessage(KafkaMessageListenerContainer.java:2643)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeRecordListener(KafkaMessageListenerContainer.java:2570)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeWithRecords(KafkaMessageListenerContainer.java:2451)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeRecordListener(KafkaMessageListenerContainer.java:2329)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeListener(KafkaMessageListenerContainer.java:2000)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.invokeIfHaveRecords(KafkaMessageListenerContainer.java:1373)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.pollAndInvoke(KafkaMessageListenerContainer.java:1364)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.run(KafkaMessageListenerContainer.java:1255)\n" +
                                     "\tat java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)\n" +
                                     "\tat java.util.concurrent.FutureTask.run(FutureTask.java:266)\n" +
                                     "\tat java.lang.Thread.run(Thread.java:748)\n" +
                                     "\tSuppressed: org.springframework.kafka.listener.ListenerExecutionFailedException: Restored Stack Trace\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:363)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\t\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\t\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "Caused by: br.com.hering.b2c.integration.infrastructure.exception.SapRetornoErrorException: SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}\n" +
                                     "\tat br.com.hering.b2c.integration.domain.service.SAPService.sendSupply(SAPService.java:42)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.processEvent(MeliIntegrationConsumer.java:77)\n" +
                                     "\tat br.com.hering.b2c.integration.application.messaging.consumer.MeliIntegrationConsumer.receive(MeliIntegrationConsumer.java:46)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\n" +
                                     "\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\n" +
                                     "\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\n" +
                                     "\tat java.lang.reflect.Method.invoke(Method.java:498)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:169)\n" +
                                     "\tat org.springframework.messaging.handler.invocation.InvocableHandlerMethod.invoke(InvocableHandlerMethod.java:119)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.HandlerAdapter.invoke(HandlerAdapter.java:56)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.MessagingMessageListenerAdapter.invokeHandler(MessagingMessageListenerAdapter.java:347)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:92)\n" +
                                     "\tat org.springframework.kafka.listener.adapter.RecordMessagingMessageListenerAdapter.onMessage(RecordMessagingMessageListenerAdapter.java:53)\n" +
                                     "\tat org.springframework.kafka.listener.KafkaMessageListenerContainer$ListenerConsumer.doInvokeOnMessage(KafkaMessageListenerContainer.java:2663)\n" +
                                     "\t... 11 more\n")
                .identifier("35221178876950006889551900000097551446160927")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9755")
                .key("300d4033-7d2d-4d07-bbd6-5e397c050dec")
                .message(EXAMPLE_MESSAGE)
                .messageOffset(89L)
                .partition(1)
                .status("Erro")
                .integration(TestIntegration.anIntegrationDto())
                .queueLogs(TestQueueLogs.aQueueLogsDto())
                .headers("{\"causa\":\"classe service\",\"mensagem\":\"error na integração\",\"correlationID\":\"12545\"}")
                .build();
    }

    public static QueueSummaryDto aQueueSummaryDto() {
        return QueueSummaryDto.builder()
                .id(1L)
                .dtEvent(LocalDateTime.now())
                .dtUpdate(LocalDateTime.now())
                .exceptionMessage("SAP RFC Retornou um erro: {\"estatus\":\"E\",\"eretorno\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}],\"E_STATUS\":\"E\",\"E_RETORNO\":[{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"Todos os materiais inseridos não contêm estoque.\"},{\"ID\":\"6386539ba07ad291f815f3ac\",\"MBLNR\":\"\",\"MJAHR\":\"\",\"BELNR\":\"\",\"GJAHR\":\"\",\"J_1BDOCNUM\":\"\",\"DSMENSAG\":\"4FAD1CEN / M com quantidade inferior no depósito da loja. 2- Quantidade disponível para baixa 0,000 peças.\"}]}")
                .identifier("35221178876950006889551900000097551446160927")
                .identifier2("sale")
                .identifier3("190")
                .identifier4("9755")
                .status("Erro")
                .integration(TestIntegration.aIntegrationSummaryDto())
                .build();
    }

    public static MessageDataDto aMessageDataDto() {
        return MessageDataDto.builder()
                .topic("blu-inthub-dev.success-soma-inthub-dev.supply")
                .exceptionClass("exception class test")
                .exceptionMessage("exception message test")
                .exceptionCause("exception cause test")
                .exceptionStacktrace("exception stacktrace test")
                .key("123456")
                .messageOffset(1)
                .message(EXAMPLE_MESSAGE)
                .headers("{\"causa\":\"classe service\",\"mensagem\":\"error na integração\",\"correlationID\":\"125456\"}")
                .partition(0)
                .build();
    }

    public static QueueStatisticsDto queueDashboardDto() {
        return QueueStatisticsDto.builder()
                .integration(QueueStatisticsDto.IntegrationDto.builder()
                        .name("test integration")
                        .id(1L)
                        .cluster(QueueStatisticsDto.IntegrationDto.ClusterDto.builder()
                                .name("test cluster")
                                .id(1L)
                                .build())
                        .build())
                .success(10)
                .error(5)
                .reprocessed(4)
                .failedReprocessing(1)
                .waitingReprocessing(2)
                .build();
    }
}