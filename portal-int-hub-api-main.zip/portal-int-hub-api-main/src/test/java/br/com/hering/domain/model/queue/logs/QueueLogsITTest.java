package br.com.hering.domain.model.queue.logs;

import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.domain.model.queue.TestQueue;
import br.com.hering.domain.model.queuelog.QueueLogs;
import br.com.hering.domain.model.queuelog.QueueLogsRepository;
import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import br.com.hering.utils.database.TableNamesUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.jdbc.JdbcTestUtils;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class QueueLogsITTest {
    @Autowired
    private QueueLogsRepository queueLogsRepository;

    @Autowired
    private QueueRepository queueRepository;

    @Autowired
    private IntegrationRepository integrationRepository;

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private Queue queue;

    @Autowired
    private DatabasePopulator databasePopulator;

    @BeforeEach
    public void setUp() {
        databasePopulator.cleanTables();

        var cluster = this.clusterRepository.save(TestCluster.aCluster());
        var integration = integrationRepository.save(TestIntegration.anIntegration(cluster));
        var queueId = queueRepository.nextId();
        this.queue = queueRepository.save(TestQueue.aQueue(queueId, integration.getId()));
    }

    @Test
    void should_save_queueLogs() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(QueueLogs.class));
        assertThat(found).isEqualTo(1);

        queueLogsRepository.save(TestQueueLogs.aQueueLogs(this.queue));

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(QueueLogs.class));
        assertThat(found).isEqualTo(2);
    }
}