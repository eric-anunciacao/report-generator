package br.com.hering.presentation.controllers.integration;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.queries.integration.IntegrationQueries;
import br.com.hering.infrastructure.modelmapper.ModelMapperConfig;
import br.com.hering.application.integration.IntegrationService;
import br.com.hering.domain.model.integration.TestIntegration;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(IntegrationController.class)
@ContextConfiguration(classes = {ModelMapperConfig.class})
@Import(IntegrationController.class)
@AutoConfigureMockMvc(addFilters = false)
class IntegrationRestControllerTest {
    public static final String DLQ_TOPIC_NAME = "blu-inthub-dev.dlq-soma-inthub-dev.supply";
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IntegrationService integrationService;

    @MockBean
    private IntegrationRepository integrationRepository;

    @MockBean
    private IntegrationQueries integrationQueries;

    private static final String PREFIX = "/integrations";

    @Test
    void findAll_integration_returns_200() throws Exception {
        var integrations = Arrays.asList(TestIntegration.aSecondIntegrationDto(), TestIntegration.aThirdIntegrationDto());

        doReturn(integrations).when(this.integrationQueries).findAll(any(Sort.class));

        this.mockMvc.perform(get(PREFIX).contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].dlqTopic").value(DLQ_TOPIC_NAME))
                .andExpect(jsonPath("$[0].identifier1").value("Invoice.nfe_key"))
                .andExpect(jsonPath("$[0].name").value("MELI_SAP"))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$[1].dlqTopic").value("dlq-soma-inthub-dev.guepardo.supply"))
                .andExpect(jsonPath("$[1].identifier1").value("Invoice.nfe_key"))
                .andExpect(jsonPath("$[1].name").value("MELI_GUEPARDO"))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(content().json(this.objectMapper.writeValueAsString(integrations)));

        verify(this.integrationQueries).findAll(any(Sort.class));
    }

    @Test
    void findById_integration_returns_200() throws Exception {
        doReturn(TestIntegration.aSecondIntegrationDto()).when(integrationQueries).findById(Mockito.any(IntegrationId.class));

        this.mockMvc.perform(get(PREFIX + "/1").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.dlqTopic").value(DLQ_TOPIC_NAME))
                .andExpect(jsonPath("$.identifier1").value("Invoice.nfe_key"))
                .andExpect(jsonPath("$.name").value("MELI_SAP"));

        verify(integrationQueries).findById(IntegrationId.is(1L));
    }

    @Test
    void create_integration_returns_201() throws Exception {
        var integrationDto = TestIntegration.anIntegrationDto();
        var integration = TestIntegration.aSecondIntegration();
        integrationDto.setId(null);

        when(this.integrationService.save(any())).thenReturn(integration);

        this.mockMvc.perform(post(PREFIX).contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(integrationDto)))
                .andDo(print())
                .andExpect(status().isCreated());

        verify(this.integrationService).save(any());
    }

    @Test
    void update_integration_returns_200() throws Exception {
        this.mockMvc.perform(put(PREFIX).contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(TestIntegration.anIntegrationDto())))
                .andDo(print());
    }

    @Test
    void deleteById_integration_returns_204() throws Exception {
        doNothing().when(this.integrationService).deleteById(Mockito.anyLong());

        this.mockMvc.perform(delete(PREFIX + "/1").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNoContent())
                .andExpect(jsonPath("$").doesNotExist());

        verify(this.integrationService).deleteById(1L);
    }
}