package br.com.hering.domain.model.queue;

import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import br.com.hering.utils.database.TableNamesUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.jdbc.JdbcTestUtils;

import java.util.Random;

import static br.com.hering.domain.model.queue.TestQueue.aQueue;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class QueueITTest {
    @Autowired
    private QueueRepository queueRepository;

    @Autowired
    private IntegrationRepository integrationRepository;

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private Integration integration;

    @Autowired
    private DatabasePopulator databasePopulator;

    private static final Random random = new Random();

    @BeforeEach
    public void setUp() {
        databasePopulator.cleanTables();

        var cluster = this.clusterRepository.save(TestCluster.aCluster());
        this.integration = integrationRepository.save(TestIntegration.anIntegration(cluster));
    }

    @Test
    void should_save_queue() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();

        queueRepository.save(aQueue(QueueId.is(random.nextLong()), this.integration.getId()));

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isEqualTo(1);
    }

    @Test
    void should_findById_queue() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();

        var queue = queueRepository.save(aQueue(QueueId.is(random.nextLong()), this.integration.getId()));
        var queueFound = queueRepository.findById(queue.getId());

        assertNotNull(queueFound);
        assertTrue(queueFound.isPresent());
    }

    @Test
    void should_findAll_queue() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();

        queueRepository.save(aQueue(QueueId.is(random.nextLong()), this.integration.getId()));

        var queues = integrationRepository.findAll();
        assertFalse(queues.isEmpty());
        assertEquals(1, queues.size());
    }

    @Test
    void should_delete_integration() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();

        var queue = queueRepository.save(aQueue(QueueId.is(random.nextLong()), this.integration.getId()));
        queueRepository.deleteById(queue.getId());

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Queue.class));
        assertThat(found).isZero();
    }
}