package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingRequestDto;
import br.com.hering.presentation.controllers.reprocessing.dto.AutoReprocessingResponseDto;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class TestAutoReprocessing {
    public static ReprocessingFixedSchedule anAutoReprocessingFixedScheduleConfig() {
        var integrationId = TestIntegration.anIntegration().getId();
        return anAutoReprocessingFixedScheduleConfig(integrationId);
    }

    public static ReprocessingFixedSchedule anAutoReprocessingFixedScheduleConfig(IntegrationId id) {
        List<LocalTime> schedule = new ArrayList<>();

        schedule.add(LocalTime.of(9, 0));
        schedule.add(LocalTime.of(13, 0));
        schedule.add(LocalTime.of(18, 0));

        return anAutoReprocessingFixedScheduleConfig(id, schedule);
    }

    public static ReprocessingFixedSchedule anAutoReprocessingFixedScheduleConfig(IntegrationId id, List<LocalTime> schedule) {

        var retries = RetryCount.is(3);
        var ignoreAfterDays = IgnoreAfterDays.is(2);

        return ReprocessingFixedSchedule.register(id, retries, ignoreAfterDays, schedule);
    }

    public static AutoReprocessingRequestDto anAutoReprocessingFixedScheduleConfigDto() {
        List<LocalTime> schedule = new ArrayList<>();
        schedule.add(LocalTime.of(9, 0));
        schedule.add(LocalTime.of(13, 0));
        schedule.add(LocalTime.of(18, 0));

        return AutoReprocessingRequestDto.builder()
                .schedule(schedule)
                .active(true)
                .ignoreAfterDays(2)
                .integrationId(1234)
                .retries(3)
                .strategy(AutoReprocessing.Strategy.FIXED_SCHEDULE)
                .build();
    }

    public static AutoReprocessingResponseDto anAutoReprocessingResponseDtoWithFixedSchedule() {
        List<LocalTime> schedule = new ArrayList<>();
        schedule.add(LocalTime.of(9, 0));
        schedule.add(LocalTime.of(13, 0));
        schedule.add(LocalTime.of(18, 0));

        return AutoReprocessingResponseDto.builder()
                .id(1234)
                .integrationName("Integracao Teste")
                .schedule(schedule)
                .active(true)
                .ignoreAfterDays(2)
                .integrationId(1234)
                .retries(3)
                .strategy(AutoReprocessing.Strategy.FIXED_SCHEDULE.name())
                .strategyDescription(AutoReprocessing.Strategy.FIXED_SCHEDULE.getLabel())

                .build();
    }

    public static AutoReprocessingResponseDto anAutoReprocessingResponseDtoWithAfterMinutes() {
        return AutoReprocessingResponseDto.builder()
                .id(1235)
                .integrationName("Integracao Teste 2")
                .active(true)
                .ignoreAfterDays(1)
                .integrationId(1235)
                .retries(5)
                .minutesToReprocess(5)
                .strategy(AutoReprocessing.Strategy.AFTER_MINUTES.name())
                .strategyDescription(AutoReprocessing.Strategy.AFTER_MINUTES.getLabel())
                .build();
    }


    public static ReprocessingAfterMinutes anAutoReprocessingAfterMinutesConfig() {
        var integrationId = TestIntegration.anIntegration().getId();
        return anAutoReprocessingAfterMinutesConfig(integrationId);
    }

    public static ReprocessingAfterMinutes anAutoReprocessingAfterMinutesConfig(IntegrationId id) {
        return anAutoReprocessingAfterMinutesConfig(id, MinutesToReprocess.is(30));
    }

    public static ReprocessingAfterMinutes anAutoReprocessingAfterMinutesConfig(IntegrationId id, MinutesToReprocess minutesToReprocess) {
        var retries = RetryCount.is(3);
        var ignoreAfterDays = IgnoreAfterDays.is(2);

        return ReprocessingAfterMinutes.register(id, retries, ignoreAfterDays, minutesToReprocess);
    }
}
