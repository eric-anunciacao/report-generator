package br.com.hering.domain.model.cluster;

import br.com.hering.presentation.controllers.cluster.dto.ClusterDto;
import br.com.hering.presentation.controllers.cluster.request.CreateClusterRequest;
import br.com.hering.presentation.controllers.cluster.request.UpdateClusterRequest;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Random;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TestCluster {

    private static final Random random = new Random();
    private static final String KAFKA_CLUSTER_TESTE = "kafka cluster teste";
    private static final String KAFKA_SERVER_TESTE = "kafka server teste";

    public static Cluster aCluster() {
        return aCluster(random.nextLong());
    }

    public static ClusterId aClusterId() {
        return ClusterId.is(random.nextLong());
    }

    public static Cluster aSecondCluster() {
        return aCluster(1L);
    }

    public static Cluster aCluster(Long id) {
        return Cluster.newCluster(ClusterId.is(id), KAFKA_CLUSTER_TESTE, KAFKA_SERVER_TESTE);
    }

    public static Cluster aCluster(String name) {
        return Cluster.newCluster(ClusterId.is(1L), name, KAFKA_SERVER_TESTE);
    }

    public static ClusterDto aClusterDto() {
        return ClusterDto.builder()
                .id(1L)
                .name(KAFKA_CLUSTER_TESTE)
                .build();
    }

    public static CreateClusterRequest aCreateClusterRequest() {
        return aCreateClusterRequest("kafka cluster teste");
    }

    public static CreateClusterRequest aCreateClusterRequest(String name) {
        return CreateClusterRequest.builder()
                .id(1L)
                .name(name)
                .build();
    }


    public static UpdateClusterRequest anUpdateClusterRequest() {
        return UpdateClusterRequest.builder()
                .id(1L)
                .name(KAFKA_CLUSTER_TESTE)
                .build();
    }

    public static ClusterDto bClusterDto() {
        return ClusterDto.builder()
                .id(2L)
                .name("GCP")
                .build();
    }
}