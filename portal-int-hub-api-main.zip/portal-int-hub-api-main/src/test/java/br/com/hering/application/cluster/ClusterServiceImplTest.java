package br.com.hering.application.cluster;

import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.presentation.controllers.cluster.dto.ClusterDto;
import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClusterServiceImplTest {
    public static final String KAFKA_CLUSTER_TESTE = "kafka cluster teste";

    @Mock
    ClusterRepository clusterRepository;

    @InjectMocks
    ClusterServiceImpl clusterService;

    @Test
    void save() {
        var aCluster = TestCluster.aCluster();
        var aCreateClusterRequest = TestCluster.aCreateClusterRequest();

        when(clusterRepository.save(any(Cluster.class))).thenReturn(aCluster);

        var cluster = clusterService.execute(aCreateClusterRequest);
        assertNotNull(cluster);
        assertEquals(KAFKA_CLUSTER_TESTE, cluster.getName());

        verify(clusterRepository).save(any(Cluster.class));
    }

    @Test
    void update() {
        var aCluster = TestCluster.aCluster();
        var anUpdateClusterRequest = TestCluster.anUpdateClusterRequest();

        when(clusterRepository.findById(any(ClusterId.class))).thenReturn(Optional.of(aCluster));
        when(clusterRepository.save(any(Cluster.class))).thenReturn(aCluster);

        var cluster = clusterService.execute(anUpdateClusterRequest);
        assertNotNull(cluster);
        assertEquals(KAFKA_CLUSTER_TESTE, cluster.getName());

        verify(clusterRepository).findById(any(ClusterId.class));
        verify(clusterRepository).save(any(Cluster.class));
    }
}