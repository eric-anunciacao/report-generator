package br.com.hering.domain.queries.queue;

import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.domain.model.queue.FilterMassParam;
import br.com.hering.domain.model.queue.QueueId;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.presentation.controllers.queue.dto.QueueFilterDto;
import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;

import static br.com.hering.domain.model.queue.TestQueue.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class QueueQueriesITTest {
    @Autowired
    private QueueRepository queueRepository;

    @Autowired
    private IntegrationRepository integrationRepository;

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired()
    private QueueQueries queueQueries;

    private Integration integration;

    @Autowired
    private DatabasePopulator databasePopulator;

    @BeforeEach
    public void setUp() {

        databasePopulator.cleanTables();

        var cluster = this.clusterRepository.save(TestCluster.aCluster());
        this.integration = integrationRepository.save(TestIntegration.anIntegration(cluster));

        var aQueue = aQueue(QueueId.is(1L), this.integration.getId());
        var aSecondQueue = aQueue(QueueId.is(3L), this.integration.getId());
        var aThirdQueue = aSuccessQueue(QueueId.is(5L), this.integration.getId());
        var aFourthQueue = aReprocessedQueue(QueueId.is(7L), this.integration.getId());
        var aFifthQueue = aWaitingReprocessingQueue(QueueId.is(9L), this.integration.getId());
        var aSixthQueue = aFailedReprocessingQueue(QueueId.is(11L), this.integration.getId());

        queueRepository.saveAll(List.of(aQueue, aSecondQueue, aThirdQueue, aFourthQueue, aFifthQueue, aSixthQueue));
    }

    @Test
    void should_find_by_id() {
        var queue = queueQueries.findById(QueueId.is(1L));

        assertNotNull(queue);
        assertEquals(1L, queue.getId());
    }

    @Test
    void should_find_by_id_throw_not_found() {
        var id = QueueId.is(2L);

        assertThrows(ResponseStatusException.class, () -> queueQueries.findById(id));
    }

    @Test
    void should_find_all_filter_by_date() {

        var filter = QueueFilterDto.builder()
                .integrationId(integration.getId().getValue())
                .dtEventBegin(LocalDateTime.now().minusDays(1))
                .dtEventEnd(LocalDateTime.now())
                .build();

        var pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "dtEvent"));

        var pagedQueues = queueQueries.findAll(filter, pageable);

        assertEquals(6, pagedQueues.get().count());
    }

    @Test
    void should_find_all_return_nothing_filter_by_date() {
        var filter = QueueFilterDto.builder()
                .integrationId(integration.getId().getValue())
                .dtEventBegin(LocalDateTime.now().plusDays(1))
                .dtEventEnd(LocalDateTime.now().plusDays(2))
                .build();

        var pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "dtEvent"));

        var pagedQueues = queueQueries.findAll(filter, pageable);

        assertThat(pagedQueues.get().count()).isZero();
    }

    @Test
    void should_find_all_with_all_filters() {
        var filter = QueueFilterDto.builder()
                .integrationId(integration.getId().getValue())
                .identifier("35221178876950006889551900000097551446160927")
                .status("Erro")
                .integrationId(integration.getId().getValue())
                .dtEventBegin(LocalDateTime.now().minusDays(1))
                .dtEventEnd(LocalDateTime.now())
                .build();

        var pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "dtEvent"));

        var pagedQueues = queueQueries.findAll(filter, pageable);

        assertEquals(2, pagedQueues.get().count());
    }

    @Test
    void should_find_all_mass_with_all_filters() {
        var filter = FilterMassParam.builder()
                .integrationId(integration.getId().getValue())
                .identifier(List.of("35221178876950006889551900000097551446160927"))
                .identifier2(List.of("sale"))
                .identifier3(List.of("190"))
                .identifier4(List.of("9755"))
                .status(List.of("Erro", "Sucesso"))
                .integrationId(integration.getId().getValue())
                .dtEventBegin(LocalDateTime.now().minusDays(1))
                .dtEventEnd(LocalDateTime.now())
                .build();

        var pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "dtEvent"));

        var pagedQueues = queueQueries.findAllMass(filter, pageable);

        assertEquals(2, pagedQueues.get().count());
    }


    @Test
    void should_get_statistics() {

        var statisticsDtoList = queueQueries.getQueueStatistics(LocalDateTime.now().minusDays(1), LocalDateTime.now());

        assertEquals(1, statisticsDtoList.size());

        var statisticsDto = statisticsDtoList.get(0);

        assertEquals(integration.getId().getValue(), statisticsDto.getIntegration().getId());
        assertEquals(2, statisticsDto.getError());
        assertEquals(1, statisticsDto.getSuccess());
        assertEquals(1, statisticsDto.getReprocessed());
        assertEquals(1, statisticsDto.getWaitingReprocessing());
        assertEquals(1, statisticsDto.getFailedReprocessing());
    }

    @Test
    void should_find_all_to_export_with_all_filters() {
        var queues = queueQueries
                .findAllToExport(integration.getId(),
                        LocalDateTime.now().minusDays(1),
                        LocalDateTime.now());

        assertEquals(6, queues.size());
    }
}