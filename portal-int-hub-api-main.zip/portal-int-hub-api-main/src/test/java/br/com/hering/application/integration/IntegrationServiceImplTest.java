package br.com.hering.application.integration;

import br.com.hering.application.container.ContainerService;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IntegrationServiceImplTest {

    public static final String DLQ_TOPIC_NAME = "blu-inthub-dev.dlq-soma-inthub-dev.supply";
    public static final String IDENTIFIER1 = "Invoice.nfe_key";
    public static final String INTEGRATION_NAME = "MELI_SAP";
    @Mock
    IntegrationRepository integrationRepository;

    @Mock
    ModelMapper modelMapper;

    @Mock
    ContainerService containerService;

    @InjectMocks
    IntegrationServiceImpl integrationService;

    @Test
    void save() {
        var aIntegration = TestIntegration.anIntegration();
        var aIntegrationDto = TestIntegration.anIntegrationDto();

        when(integrationRepository.save(any(Integration.class))).thenReturn(aIntegration);

        var integration = integrationService.save(aIntegrationDto);
        assertNotNull(integration);
        assertEquals(DLQ_TOPIC_NAME, integration.getDlqTopic());
        assertEquals(IDENTIFIER1, integration.getIdentifier1());
        assertEquals(INTEGRATION_NAME, integration.getName());

        verify(integrationRepository, times(3)).save(any(Integration.class));
    }

    @Test
    void update() {
        var aIntegration = TestIntegration.anIntegration();
        var aIntegrationDto = TestIntegration.anIntegrationDto();

        when(integrationRepository.findById(any(IntegrationId.class))).thenReturn(Optional.of(aIntegration));
        when(integrationRepository.save(any(Integration.class))).thenReturn(aIntegration);

        var integration = integrationService.update(aIntegrationDto);
        assertNotNull(integration);
        assertEquals(DLQ_TOPIC_NAME, integration.getDlqTopic());
        assertEquals(IDENTIFIER1, integration.getIdentifier1());
        assertEquals(INTEGRATION_NAME, integration.getName());

        verify(integrationRepository).findById(any(IntegrationId.class));
        verify(integrationRepository, times(3)).save(any(Integration.class));
    }

    @Test
    void deleteById() {
        var integration = TestIntegration.anIntegration();
        when(integrationRepository.findById(any(IntegrationId.class))).thenReturn(Optional.of(integration));
        when(integrationRepository.save(any(Integration.class))).thenReturn(integration);

        integrationService.deleteById(1L);

        verify(integrationRepository).findById(any(IntegrationId.class));
        verify(integrationRepository, times(3)).save(any(Integration.class));
    }
}