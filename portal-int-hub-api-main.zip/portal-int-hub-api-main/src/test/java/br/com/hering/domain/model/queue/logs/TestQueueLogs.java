package br.com.hering.domain.model.queue.logs;

import br.com.hering.domain.model.queuelog.QueueLogs;
import br.com.hering.presentation.controllers.queue.dto.QueueLogsDto;
import br.com.hering.domain.model.queue.Queue;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TestQueueLogs {

    public static QueueLogs aQueueLogs(Queue queue) {
        var queueLogs = new QueueLogs();
        queueLogs.setDtEvent(LocalDateTime.now());
        queueLogs.setStatus("Sucesso");
        queueLogs.setQueueId(queue.getId());
        return queueLogs;
    }

    public static List<QueueLogsDto> aQueueLogsDto() {
        return Arrays.asList(QueueLogsDto.builder()
                .id(1L)
                .dtEvent(LocalDateTime.now())
                .status("Sucesso")
                .build());
    }
}