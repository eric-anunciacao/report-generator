package br.com.hering.application.autoreprocessing;

import br.com.hering.application.queue.SanitizeQueueService;
import br.com.hering.domain.model.autoreprocessing.*;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.integration.IntegrationRepository;
import br.com.hering.domain.model.integration.TestIntegration;
import br.com.hering.domain.model.queue.QueueRepository;
import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.*;
import java.util.ArrayList;
import java.util.List;

import static br.com.hering.domain.model.queue.TestQueue.aQueueWithSpecificEventDate;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class AutoReprocessingImplITTest {

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private DatabasePopulator databasePopulator;

    @Autowired
    private AutoReprocessingRepository autoReprocessingRepository;

    @Autowired
    private QueueRepository queueRepository;

    @Autowired
    private IntegrationRepository integrationRepository;

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private AutoReprocessingService target;

    private Integration integration;
    private Integration secondIntegration;

    @BeforeEach
    public void setUp() {
        databasePopulator.cleanTables();

        var today = LocalDate.now();

        var cluster = this.clusterRepository.save(TestCluster.aCluster());
        this.integration = integrationRepository.save(TestIntegration.anIntegration(cluster));
        this.secondIntegration = integrationRepository.save(TestIntegration.anIntegration(cluster));

        List<LocalTime> schedule = new ArrayList<>();

        schedule.add(LocalTime.of(9, 0));
        schedule.add(LocalTime.of(10, 0));
        schedule.add(LocalTime.of(13, 0));
        schedule.add(LocalTime.of(18, 0));

        autoReprocessingRepository
                .save(TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig(integration.getId(), schedule));

        var minutesToReprocess = MinutesToReprocess.is(20);

        autoReprocessingRepository
                .save(TestAutoReprocessing.anAutoReprocessingAfterMinutesConfig(secondIntegration.getId(), minutesToReprocess));

        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(8, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(10, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(11, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(12, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(13, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(14, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(15, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(16, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(17, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(18, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.integration.getId(), today.atTime(19, 0)));

        queueRepository.save(aQueueWithSpecificEventDate(this.secondIntegration.getId(), today.atTime(10, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.secondIntegration.getId(), today.atTime(13, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.secondIntegration.getId(), today.atTime(15, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.secondIntegration.getId(), today.atTime(19, 0)));
        queueRepository.save(aQueueWithSpecificEventDate(this.secondIntegration.getId(), today.atTime(21, 0)));
    }

    @Test
    void should_reprocess_16_queues_at_09_21_pm() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(21, 21));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(11, reprocessedFromFirstIntegration.size());
        assertEquals(5, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_7_queues_at_01_21_pm() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(13, 21));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(5, reprocessedFromFirstIntegration.size());
        assertEquals(2, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_5_queues_at_01_pm() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(13, 1));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(4, reprocessedFromFirstIntegration.size());
        assertEquals(1, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_3_queues_at_10_21_am() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(10, 21));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(2, reprocessedFromFirstIntegration.size());
        assertEquals(1, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_1_queue_at_10_20_am() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(10, 20));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(1, reprocessedFromFirstIntegration.size());
        assertEquals(0, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_1_queue_at_10_am() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(10, 0));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(1, reprocessedFromFirstIntegration.size());
        assertEquals(0, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_1_queue_at_9_am() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(9, 0));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(1, reprocessedFromFirstIntegration.size());
        assertEquals(0, reprocessedFromSecondIntegration.size());
    }

    @Test
    void should_reprocess_no_queues_at_7_am() {
        var today = LocalDate.now();

        target.reprocessAll(today.atTime(7, 0));

        var reprocessedFromFirstIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(integration.getId());
        var reprocessedFromSecondIntegration = queueRepository
                .findByIntegrationIdAndAutoReprocessingRetriesNotNull(secondIntegration.getId());

        assertEquals(0, reprocessedFromFirstIntegration.size());
        assertEquals(0, reprocessedFromSecondIntegration.size());
    }
}
