package br.com.hering.presentation.controllers.cluster;

import br.com.hering.application.cluster.ClusterService;
import br.com.hering.domain.model.cluster.ClusterId;
import br.com.hering.presentation.controllers.cluster.dto.ClusterDto;
import br.com.hering.presentation.controllers.cluster.request.CreateClusterRequest;
import br.com.hering.presentation.controllers.cluster.request.UpdateClusterRequest;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.infrastructure.modelmapper.ModelMapperConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ClusterController.class)
@ContextConfiguration(classes = {ModelMapperConfig.class})
@Import(ClusterController.class)
@AutoConfigureMockMvc(addFilters = false)
class ClusterRestControllerTest {

    public static final String INTEGRATION_NAME = "kafka cluster teste";

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ClusterService clusterService;

    @MockBean
    private ClusterRepository clusterRepository;

    private static final String prefix = "/clusters";

    @Test
    void findAll_cluster_returns_200() throws Exception {
        List<ClusterDto> clusters = Arrays.asList(TestCluster.aClusterDto(), TestCluster.bClusterDto());

        doReturn(clusters).when(this.clusterRepository).findAll(Sort.by(Sort.Direction.ASC, "name"));

        this.mockMvc.perform(get(prefix).contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].name").value(INTEGRATION_NAME))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$[1].name").value("GCP"))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(content().json(this.objectMapper.writeValueAsString(clusters)));

        verify(this.clusterRepository).findAll(Sort.by(Sort.Direction.ASC, "name"));
    }

    @Test
    void findById_cluster_returns_200() throws Exception {
        doReturn(Optional.of(TestCluster.aCluster(1L))).when(this.clusterRepository).findById(ClusterId.is(1L));

        this.mockMvc.perform(get(prefix+"/1").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.name").value(INTEGRATION_NAME));

        verify(this.clusterRepository).findById(ClusterId.is(1L));
    }

    @Test
    void findById_cluster_returns_404() throws Exception {
        this.mockMvc.perform(get(prefix+"/1").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound());
    }

    @Test
    void create_cluster_returns_201() throws Exception {
        var aCreateClusterRequest = TestCluster.aCreateClusterRequest("Blumenau DEV");
        var aCluster = TestCluster.aCluster("Blumenau DEV");
        when(this.clusterService.execute(any(CreateClusterRequest.class))).thenReturn(aCluster);

        mockMvc.perform(post(prefix).contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(aCreateClusterRequest)))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is("Blumenau DEV")));

        verify(this.clusterService).execute(any(CreateClusterRequest.class));
    }

    @Test
     void update_cluster_returns_200() throws Exception {
        doReturn(TestCluster.aSecondCluster()).when(this.clusterService).execute(any(UpdateClusterRequest.class));

        this.mockMvc.perform(put(prefix).contentType(MediaType.APPLICATION_JSON)
                        .content(this.objectMapper.writeValueAsString(TestCluster.aClusterDto())))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.name", is(INTEGRATION_NAME)));

        verify(this.clusterService).execute(any(UpdateClusterRequest.class));
    }

    @Test
    void deleteById_cluster_returns_204() throws Exception {
        doNothing().when(this.clusterRepository).deleteById(ClusterId.is(1L));

        this.mockMvc.perform(delete(prefix+"/1").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNoContent())
                .andExpect(jsonPath("$").doesNotExist());

        verify(this.clusterRepository).deleteById(ClusterId.is(1L));
    }
}