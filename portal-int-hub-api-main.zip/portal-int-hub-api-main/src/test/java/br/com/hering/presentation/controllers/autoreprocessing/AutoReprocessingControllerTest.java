package br.com.hering.presentation.controllers.autoreprocessing;

import br.com.hering.application.autoreprocessing.AutoReprocessingService;
import br.com.hering.domain.model.autoreprocessing.AutoReprocessing;
import br.com.hering.domain.model.autoreprocessing.AutoReprocessingRepository;
import br.com.hering.domain.model.autoreprocessing.TestAutoReprocessing;
import br.com.hering.domain.model.integration.IntegrationId;
import br.com.hering.domain.queries.autoreprocessing.AutoReprocessingQueries;
import br.com.hering.infrastructure.modelmapper.ModelMapperConfig;
import br.com.hering.presentation.controllers.reprocessing.AutoReprocessingController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AutoReprocessingController.class)
@ContextConfiguration(classes = {ModelMapperConfig.class})
@Import(AutoReprocessingController.class)
@AutoConfigureMockMvc(addFilters = false)
class AutoReprocessingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AutoReprocessingService autoReprocessingService;

    @MockBean
    private AutoReprocessingRepository autoReprocessingRepository;

    @MockBean
    private AutoReprocessingQueries autoReprocessingQueries;

    private static final String PREFIX = "/auto-reprocessing-configs";

    @Test
    void findAll_auto_reprocessing_configs_returns_200() throws Exception {
        var autoReprocessingConfigs = Arrays.asList(TestAutoReprocessing.anAutoReprocessingResponseDtoWithFixedSchedule(), TestAutoReprocessing.anAutoReprocessingResponseDtoWithAfterMinutes());

        doReturn(autoReprocessingConfigs).when(autoReprocessingQueries).findAll(any(Sort.class));

        this.mockMvc.perform(get(PREFIX).contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].id").value(1234L))
                .andExpect(jsonPath("$[0].integrationId").value(1234L))
                .andExpect(jsonPath("$[0].integrationName").value("Integracao Teste"))
                .andExpect(jsonPath("$[0].retries").value(3))
                .andExpect(jsonPath("$[0].schedule[0]").value("09:00:00"))
                .andExpect(jsonPath("$[0].schedule[1]").value("13:00:00"))
                .andExpect(jsonPath("$[0].schedule[2]").value("18:00:00"))
                .andExpect(jsonPath("$[0].schedule[3]").doesNotExist())
                .andExpect(jsonPath("$[0].minutesToReprocess").value(0))
                .andExpect(jsonPath("$[0].active").value(true))
                .andExpect(jsonPath("$[0].ignoreAfterDays").value(2))
                .andExpect(jsonPath("$[0].strategy").value(AutoReprocessing.Strategy.FIXED_SCHEDULE.name()))

                .andExpect(jsonPath("$[1].id").value(1235L))
                .andExpect(jsonPath("$[1].integrationId").value(1235L))
                .andExpect(jsonPath("$[1].integrationName").value("Integracao Teste 2"))
                .andExpect(jsonPath("$[1].retries").value(5))
                .andExpect(jsonPath("$[1].minutesToReprocess").value(5))
                .andExpect(jsonPath("$[1].active").value(true))
                .andExpect(jsonPath("$[1].ignoreAfterDays").value(1))
                .andExpect(jsonPath("$[1].strategy").value(AutoReprocessing.Strategy.AFTER_MINUTES.name()))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(content().json(objectMapper.writeValueAsString(autoReprocessingConfigs)));

        verify(autoReprocessingQueries).findAll(any(Sort.class));
    }

    @Test
    void findById_auto_reprocessing_config_returns_200() throws Exception {
        var autoReprocessingConfig = TestAutoReprocessing.anAutoReprocessingResponseDtoWithFixedSchedule();

        doReturn(autoReprocessingConfig).when(autoReprocessingQueries).findById(any(IntegrationId.class));

        this.mockMvc.perform(get(PREFIX+"/1").contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(1234L))
                .andExpect(jsonPath("$.integrationId").value(1234L))
                .andExpect(jsonPath("$.integrationName").value("Integracao Teste"))
                .andExpect(jsonPath("$.retries").value(3))
                .andExpect(jsonPath("$.schedule[0]").value("09:00:00"))
                .andExpect(jsonPath("$.schedule[1]").value("13:00:00"))
                .andExpect(jsonPath("$.schedule[2]").value("18:00:00"))
                .andExpect(jsonPath("$.schedule[3]").doesNotExist())
                .andExpect(jsonPath("$.minutesToReprocess").value(0))
                .andExpect(jsonPath("$.active").value(true))
                .andExpect(jsonPath("$.ignoreAfterDays").value(2))
                .andExpect(jsonPath("$.strategy").value(AutoReprocessing.Strategy.FIXED_SCHEDULE.name()));


        verify(autoReprocessingQueries).findById(any(IntegrationId.class));
    }

    @Test
    void create_auto_reprocessing_config_returns_201() throws Exception {
        var autoReprocessingDto = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfigDto();

        var autoReprocessing = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig();
        when(autoReprocessingService.create(any())).thenReturn(autoReprocessing);

        this.mockMvc.perform(post(PREFIX).contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(autoReprocessingDto)))
                .andDo(print())
                .andExpect(status().isCreated());

        verify(autoReprocessingService).create(any());
    }

    @Test
    void update_auto_reprocessing_config_returns_200() throws Exception {
        var autoReprocessingDto = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfigDto();

        var autoReprocessing = TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig();
        when(autoReprocessingService.update(any(IntegrationId.class), any())).thenReturn(autoReprocessing);

        this.mockMvc.perform(put(PREFIX + "/1234").contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(autoReprocessingDto)))
                .andDo(print())
                .andExpect(status().isOk());

        verify(autoReprocessingService).update(any(IntegrationId.class), any());
    }
}