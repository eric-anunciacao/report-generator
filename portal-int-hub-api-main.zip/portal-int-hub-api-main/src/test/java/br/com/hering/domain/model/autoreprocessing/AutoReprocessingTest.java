package br.com.hering.domain.model.autoreprocessing;

import br.com.hering.domain.model.integration.TestIntegration;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static br.com.hering.domain.model.autoreprocessing.TestAutoReprocessing.anAutoReprocessingFixedScheduleConfig;
import static org.junit.jupiter.api.Assertions.*;

class AutoReprocessingTest {

    @Test
    void should_create_new_auto_reprocessing_fixed_schedule() {

        List<LocalTime> schedule = new ArrayList<>();

        schedule.add(LocalTime.of(9, 0));
        schedule.add(LocalTime.of(13, 0));
        schedule.add(LocalTime.of(18, 0));

        var integrationId = TestIntegration.anIntegration().getId();
        var retries = RetryCount.is(3);
        var ignoreAfterDays = IgnoreAfterDays.is(2);

        var autoReprocessing = ReprocessingFixedSchedule.register(integrationId, retries, ignoreAfterDays, schedule);

        var configurationLabel = "Reprocessar em horários fixos:\n" +
                                 " Horário 1: 09:00\n" +
                                 " Horário 2: 13:00\n" +
                                 " Horário 3: 18:00";

        assertInstanceOf(AutoReprocessing.class, autoReprocessing);
        assertEquals(integrationId, autoReprocessing.getId());
        assertEquals(retries, autoReprocessing.getRetries());
        assertEquals(ignoreAfterDays, autoReprocessing.getIgnoreAfterDays());
        assertEquals(schedule, autoReprocessing.getSchedule().getItems());
        assertEquals(configurationLabel, autoReprocessing.configurationLabel());
        assertEquals(AutoReprocessing.Strategy.FIXED_SCHEDULE, autoReprocessing.getStrategy());
        assertTrue(autoReprocessing.isActive());
    }

    @Test
    void should_inactivate_auto_reprocessing_fixed_schedule() {
        var fixedScheduleAutoReprocessing = anAutoReprocessingFixedScheduleConfig();

        fixedScheduleAutoReprocessing.inactivate();

        assertFalse(fixedScheduleAutoReprocessing.isActive());
    }

    @Test
    void should_create_new_auto_reprocessing_after_minutes() {
        var integrationId = TestIntegration.anIntegration().getId();
        var retries = RetryCount.is(3);
        var ignoreAfterDays = IgnoreAfterDays.is(2);
        var minutesToReprocess = MinutesToReprocess.is(20);

        var autoReprocessing = ReprocessingAfterMinutes.register(integrationId, retries, ignoreAfterDays, minutesToReprocess);

        var configurationLabel = "Reprocessar após 20 minutos";

        assertInstanceOf(AutoReprocessing.class, autoReprocessing);
        assertEquals(integrationId, autoReprocessing.getId());
        assertEquals(retries, autoReprocessing.getRetries());
        assertEquals(ignoreAfterDays, autoReprocessing.getIgnoreAfterDays());
        assertEquals(minutesToReprocess, autoReprocessing.getMinutesToReprocess());
        assertEquals(configurationLabel, autoReprocessing.configurationLabel());
        assertEquals(AutoReprocessing.Strategy.AFTER_MINUTES, autoReprocessing.getStrategy());
        assertTrue(autoReprocessing.isActive());
    }


    @ParameterizedTest
    @MethodSource("nearestTimesBefore")
    void should_get_nearest_schedule_before(Pair<LocalTime, LocalTime> times) {
        var nearestSchedule = times.getKey();
        var timeToCompare = times.getValue();

        var autoReprocessing = anAutoReprocessingFixedScheduleConfig();

        var nearestBefore = autoReprocessing.getNearestTimeBeforeIfExists(timeToCompare);

        assertTrue(nearestBefore.isPresent());
        assertEquals(nearestSchedule, nearestBefore.get());
    }

    private static Stream<Pair<LocalTime, LocalTime>> nearestTimesBefore() {
        return Stream.of(
                Pair.of(LocalTime.of(9, 0), LocalTime.of(9, 2)),
                Pair.of(LocalTime.of(9, 0), LocalTime.of(10, 15)),
                Pair.of(LocalTime.of(9, 0), LocalTime.of(12, 59)),
                Pair.of(LocalTime.of(13, 0), LocalTime.of(13, 0)),
                Pair.of(LocalTime.of(13, 0), LocalTime.of(13, 58)),
                Pair.of(LocalTime.of(13, 0), LocalTime.of(17, 58)),
                Pair.of(LocalTime.of(18, 0), LocalTime.of(18, 5)),
                Pair.of(LocalTime.of(18, 0), LocalTime.of(20, 50)),
                Pair.of(LocalTime.of(18, 0), LocalTime.of(23, 30)),
                Pair.of(LocalTime.of(18, 0), LocalTime.of(20, 59))
        );
    }

    @Test
    void should_not_exist_nearest_schedule_before() {
        var timeToCompare = LocalTime.of(8, 59);

        var autoReprocessing = anAutoReprocessingFixedScheduleConfig();

        var nearestBefore = autoReprocessing.getNearestTimeBeforeIfExists(timeToCompare);

        assertFalse(nearestBefore.isPresent());
    }
}
