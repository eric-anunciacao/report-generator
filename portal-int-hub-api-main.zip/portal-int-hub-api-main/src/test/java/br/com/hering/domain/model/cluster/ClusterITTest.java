package br.com.hering.domain.model.cluster;

import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import br.com.hering.utils.database.TableNamesUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.jdbc.JdbcTestUtils;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class ClusterITTest {

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DatabasePopulator databasePopulator;

    @BeforeEach
    public void cleanTables() {
        databasePopulator.cleanTables();
    }

    @Test
    void should_save_cluster() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Cluster.class));
        assertThat(found).isZero();

        clusterRepository.save(TestCluster.aCluster());

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Cluster.class));
        assertThat(found).isEqualTo(1);
    }

    @Test
    void should_findById_cluster() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Cluster.class));
        assertThat(found).isZero();

        var cluster = clusterRepository.save(TestCluster.aCluster());
        var clusterFound = clusterRepository.findById(cluster.getId());

        assertNotNull(clusterFound);
        assertTrue(clusterFound.isPresent());
    }

    @Test
    void should_findAll_cluster() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Cluster.class));
        assertThat(found).isZero();

        clusterRepository.save(TestCluster.aCluster());

        var clusters = clusterRepository.findAll();
        assertTrue(!clusters.isEmpty());
        assertEquals(1, clusters.size());
    }

    @Test
    void should_delete_cluster() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Cluster.class));
        assertThat(found).isZero();

        var cluster = clusterRepository.save(TestCluster.aCluster());
        clusterRepository.deleteById(cluster.getId());

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Cluster.class));
        assertThat(found).isZero();
    }
}