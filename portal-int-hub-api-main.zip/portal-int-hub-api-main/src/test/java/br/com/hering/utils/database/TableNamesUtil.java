package br.com.hering.utils.database;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TableNamesUtil {
    public static String from(Class<?> aClass) {
        return aClass.getAnnotation(Table.class).schema() + "." + aClass.getAnnotation(Table.class).name();
    }
}
