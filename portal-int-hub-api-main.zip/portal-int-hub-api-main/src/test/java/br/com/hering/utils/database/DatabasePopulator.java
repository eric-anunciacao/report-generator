package br.com.hering.utils.database;

import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.domain.model.integration.Integration;
import br.com.hering.domain.model.queue.Queue;
import br.com.hering.domain.model.queuelog.QueueLogs;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.test.jdbc.JdbcTestUtils;

@Component
public class DatabasePopulator {

    private final JdbcTemplate jdbcTemplate;

    private final ClusterRepository clusterRepository;

    public DatabasePopulator(JdbcTemplate jdbcTemplate,
                             ClusterRepository clusterRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.clusterRepository = clusterRepository;
    }

    public DatabasePopulator addCluster(String name){
        clusterRepository.save(TestCluster.aCluster(1L));
        return this;
    }

    public DatabasePopulator cleanTables(){
        JdbcTestUtils.deleteFromTables(
                jdbcTemplate,
                TableNamesUtil.from(QueueLogs.class),
                TableNamesUtil.from(Queue.class),
                TableNamesUtil.from(Integration.class),
                TableNamesUtil.from(Cluster.class)
        );

        return this;
    }
}