package br.com.hering.utils.database;

import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.springframework.stereotype.Component;
import org.testcontainers.containers.PostgreSQLContainer;

public class PostgreSQLExtension implements BeforeAllCallback, AfterAllCallback {

    private PostgreSQLContainer<?> postgres;

    @Override
    public void beforeAll(ExtensionContext context) {
        postgres = new PostgreSQLContainer<>("postgres:13")
                .withDatabaseName("tst")
                .withUsername("postgres")
                .withPassword("postgres")
                .withExposedPorts(5432);

//        var host = "localhost";
        var host = "docker";

        postgres.start();
        String jdbcUrl = String.format("jdbc:postgresql://%s:%d/tst", host, postgres.getFirstMappedPort());
        System.setProperty("spring.datasource.url", jdbcUrl);
        System.setProperty("spring.datasource.username", "postgres");
        System.setProperty("spring.datasource.password", "postgres");
    }

    @Override
    public void afterAll(ExtensionContext context) {
        //postgres.stop();
    }
}
