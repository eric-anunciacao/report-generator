package br.com.hering.domain.model.integration;

import br.com.hering.presentation.controllers.integration.dto.IntegrationDto;
import br.com.hering.presentation.controllers.integration.dto.IntegrationSummaryDto;
import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.domain.model.cluster.TestCluster;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Random;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TestIntegration {
    private static final Random random = new Random();

    public static Integration.Builder anIntegrationBuilder() {
        return Integration.newIntegration(IntegrationId.is(random.nextLong()), "MELI_SAP")
                .dlqTopic("blu-inthub-dev.dlq-soma-inthub-dev.supply")
                .identifier1("Invoice.nfe_key")
                .reprocessTopic("rep-supply")
                .successTopic("blu-inthub-dev.success-soma-inthub-dev.supply")
                .clusterId(TestCluster.aClusterId())
                .correlationId("Invoice.id")
                .nameIdentifier1("Nº NF")
                .nameIdentifier2("Tipo NF")
                .nameIdentifier3("Serie NF")
                .nameIdentifier4("Número")
                .active(true);
    }

    public static Integration anIntegration() {
        return anIntegrationBuilder()
                .build();
    }

    public static Integration anInactiveIntegration() {
        return anIntegrationBuilder()
                .active(false)
                .build();
    }

    public static Integration anIntegration(Cluster cluster) {
        return anIntegrationBuilder()
                .clusterId(cluster.getId())
                .build();
    }

    public static Integration aSecondIntegration() {
        return Integration.newIntegration(IntegrationId.is(1L),"MELI_SAP")
                .dlqTopic("blu-inthub-dev.dlq-soma-inthub-dev.supply")
                .identifier1("Invoice.nfe_key")
                .reprocessTopic("rep-supply")
                .successTopic("blu-inthub-dev.success-soma-inthub-dev.supply")
                .clusterId(TestCluster.aSecondCluster().getId())
                .correlationId("Invoice.id")
                .nameIdentifier1("Nº NF")
                .nameIdentifier2("Tipo NF")
                .nameIdentifier3("Serie NF")
                .nameIdentifier4("Número")
                .active(true)
                .build();
    }

    public static Integration aThirdIntegration() {
        return Integration.newIntegration(IntegrationId.is(2L), "MELI_GUEPARDO")
                .dlqTopic("dlq-soma-inthub-dev.guepardo.supply")
                .identifier1("Invoice.nfe_key")
                .reprocessTopic("soma-inthub-dev.guepardo.rep-supply")
                .successTopic("success-soma-inthub-dev.guepardo.supply")
                .clusterId(TestCluster.aSecondCluster().getId())
                .correlationId("Invoice.id")
                .nameIdentifier1("Nº NF")
                .active(true)
                .build();
    }

    public static IntegrationDto anIntegrationDto() {
        return IntegrationDto.builder()
                .id(1L)
                .dlqTopic("blu-inthub-dev.dlq-soma-inthub-dev.supply")
                .dtCreate(LocalDateTime.now())
                .dtUpdate(LocalDateTime.now())
                .identifier1("Invoice.nfe_key")
                .name("MELI_SAP")
                .reprocessTopic("rep-supply")
                .successTopic("blu-inthub-dev.success-soma-inthub-dev.supply")
                .cluster(TestCluster.aClusterDto())
                .correlationId("Invoice.id")
                .nameIdentifier1("Nº NF")
                .nameIdentifier2("Tipo NF")
                .nameIdentifier3("Serie NF")
                .nameIdentifier4("Número")
                .active(true)
                .build();
    }

    public static IntegrationDto aSecondIntegrationDto() {
        return IntegrationDto.builder()
                .id(1L)
                .name("MELI_SAP")
                .dlqTopic("blu-inthub-dev.dlq-soma-inthub-dev.supply")
                .identifier1("Invoice.nfe_key")
                .reprocessTopic("rep-supply")
                .successTopic("blu-inthub-dev.success-soma-inthub-dev.supply")
                .cluster(TestCluster.aClusterDto())
                .correlationId("Invoice.id")
                .nameIdentifier1("Nº NF")
                .nameIdentifier2("Tipo NF")
                .nameIdentifier3("Serie NF")
                .nameIdentifier4("Número")
                .active(true)
                .build();
    }

    public static IntegrationDto aThirdIntegrationDto() {
        return IntegrationDto.builder()
                .id(2L)
                .name("MELI_GUEPARDO")
                .dlqTopic("dlq-soma-inthub-dev.guepardo.supply")
                .identifier1("Invoice.nfe_key")
                .reprocessTopic("soma-inthub-dev.guepardo.rep-supply")
                .successTopic("success-soma-inthub-dev.guepardo.supply")
                .cluster(TestCluster.aClusterDto())
                .correlationId("Invoice.id")
                .nameIdentifier1("Nº NF")
                .active(true)
                .build();
    }

    public static IntegrationSummaryDto aIntegrationSummaryDto() {
        return IntegrationSummaryDto.builder()
                .id(1L)
                .identifier1("Invoice.nfe_key")
                .name("MELI_SAP")
                .nameIdentifier1("Nº NF")
                .nameIdentifier2("Tipo NF")
                .nameIdentifier3("Serie NF")
                .nameIdentifier4("Número")
                .build();
    }
}