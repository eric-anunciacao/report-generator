package br.com.hering.domain.model.integration;

import br.com.hering.domain.model.cluster.Cluster;
import br.com.hering.domain.model.cluster.ClusterRepository;
import br.com.hering.domain.model.cluster.TestCluster;
import br.com.hering.utils.database.DatabasePopulator;
import br.com.hering.utils.database.PostgreSQLExtension;
import br.com.hering.utils.database.TableNamesUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.jdbc.JdbcTestUtils;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("itst")
@ExtendWith(PostgreSQLExtension.class)
class IntegrationITTest {

    @Autowired
    private ClusterRepository clusterRepository;

    @Autowired
    private IntegrationRepository integrationRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private Cluster cluster;

    @Autowired
    private DatabasePopulator databasePopulator;

    @BeforeEach
    public void cleanTables() {
        databasePopulator.cleanTables();

        this.cluster = clusterRepository.save(TestCluster.aCluster());
    }

    @Test
    void should_save_integration() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Integration.class));
        assertThat(found).isZero();

        integrationRepository.save(TestIntegration.anIntegration(this.cluster));

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Integration.class));
        assertThat(found).isEqualTo(1);
    }

    @Test
    void should_findById_integration() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Integration.class));
        assertThat(found).isZero();

        var integration = integrationRepository.save(TestIntegration.anIntegration(this.cluster));
        var integrationFound = integrationRepository.findById(integration.getId());

        assertNotNull(integrationFound);
        assertTrue(integrationFound.isPresent());
    }

    @Test
    void should_findAll_integration() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Integration.class));
        assertThat(found).isZero();

        integrationRepository.save(TestIntegration.anIntegration(this.cluster));

        var integrations = integrationRepository.findAll();
        assertTrue(!integrations.isEmpty());
        assertEquals(1, integrations.size());
    }

    @Test
    void should_delete_integration() {
        var found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Integration.class));
        assertThat(found).isZero();

        var integration = integrationRepository.save(TestIntegration.anIntegration(this.cluster));
        integrationRepository.deleteById(integration.getId());

        found = JdbcTestUtils.countRowsInTable(jdbcTemplate, TableNamesUtil.from(Integration.class));
        assertThat(found).isZero();
    }
}