package br.com.hering.domain.model.cluster;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClusterTest {

    @Test
    void should_create_new_cluster(){
        var id = ClusterId.is(1L);
        var name = "test cluster";
        var server = "test server";

        var cluster = Cluster.newCluster(id, name, server);
        var cluster2 = Cluster.newCluster(id, name, server);
        var cluster3 = Cluster.newCluster(ClusterId.is(2L), name, server);

        assertEquals(id, cluster.getId());
        assertEquals(name, cluster.getName());
        assertTrue(cluster.sameIdentityAs(cluster2));
        assertFalse(cluster.sameIdentityAs(cluster3));
    }
}
