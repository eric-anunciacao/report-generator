# Portal Int HUB - API

Projeto:   hering-integration-hub-prod
Projeto:   hering-integration-hub-hml
Tech lead: jaderson.linhares@ciahering.com.br
P.O:       leandro.macedo@ciahering.com.br

Getting started
Portal integration Hub ou Portal Int Hub, tem por funcionalidade conseguir identificar status das integrações da companhia. Trazendo para o usuário informações sobre a integração, se deu sucesso ou não e reenviar caso tenha dado erro. Construído pela área de arquitetura para facilitar a visualização das integrações. 

Requisitos que será disponibilizado
Instancia Linux e2-standard-2

Arquitetura sintetizada
O fluxo de trabalho do ambiente ocorrerá se guinte forma.

Documentação no Notion
https://www.notion.so/ciahering/Portal-Integration-Hub-0634892d172e4f03a3f1e1f421042a1f
